import { cp, mkdir, rm } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const root = process.cwd();
const output = `${root}/www`;
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
const excluded = new Set(['.git', '.github', 'android', 'android-template', 'node_modules', 'www', 'scripts']);
for (const entry of await (await import('node:fs/promises')).readdir(root, { withFileTypes: true })) {
  if (excluded.has(entry.name) || entry.name === 'package.json' || entry.name === 'package-lock.json' || entry.name === 'capacitor.config.json') continue;
  const source = `${root}/${entry.name}`;
  const target = `${output}/${entry.name}`;
  if (entry.isDirectory()) await cp(source, target, { recursive: true });
  else if (entry.isFile()) await cp(source, target);
}
if (!existsSync(`${output}/index.html`)) throw new Error('index.html tidak ditemukan pada root project.');
console.log('Web assets prepared in www/');
