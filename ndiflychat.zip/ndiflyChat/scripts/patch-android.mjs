import { cp, mkdir, readFile, writeFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';

const base = 'android/app/src/main';
const javaDir = `${base}/java/com/ndifly/chat`;
await mkdir(javaDir, { recursive: true });
await cp('android-template/app/src/main/java/com/ndifly/chat/MainActivity.java', `${javaDir}/MainActivity.java`);
await cp('android-template/app/src/main/java/com/ndifly/chat/MediaPermissionsPlugin.java', `${javaDir}/MediaPermissionsPlugin.java`);
const manifestPath = `${base}/AndroidManifest.xml`;
if (!existsSync(manifestPath)) throw new Error('AndroidManifest.xml tidak ditemukan setelah Capacitor Android dibuat.');
let xml = await readFile(manifestPath, 'utf8');
const permissions = [
  '  <uses-permission android:name="android.permission.INTERNET" />',
  '  <uses-permission android:name="android.permission.RECORD_AUDIO" />',
  '  <uses-permission android:name="android.permission.CAMERA" />',
  '  <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />',
  '  <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />',
  '  <uses-permission android:name="android.permission.VIBRATE" />'
];
const missing = permissions.filter(line => !xml.includes(line.match(/android:name="([^"]+)/)[1]));
if (missing.length) {
  const manifestOpen = xml.match(/<manifest\b[^>]*>/s);
  if (!manifestOpen) throw new Error('Tag manifest pembuka tidak ditemukan.');
  xml = xml.replace(manifestOpen[0], `${manifestOpen[0]}\n${missing.join('\n')}`);
}
if (!xml.includes('android:usesCleartextTraffic=')) {
  xml = xml.replace('<application', '<application android:usesCleartextTraffic="false"');
}
await writeFile(manifestPath, xml);
console.log('Native permissions and custom plugin installed.');
