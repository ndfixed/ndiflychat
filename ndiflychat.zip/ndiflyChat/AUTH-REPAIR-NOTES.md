# Perbaikan Auth Supabase

- Login dan daftar tetap memakai username + password; alamat email sintetis internal dipertahankan agar akun lama tetap kompatibel.
- Client Supabase memakai persistSession dan autoRefreshToken.
- Form menunggu pemeriksaan sesi selesai, mencegah redirect/login race.
- Penanganan error Edge Function membaca body Response dengan aman.
- Edge Function memakai `SUPABASE_SERVICE_ROLE_KEY` bawaan Supabase terlebih dahulu, dengan `APP_SERVICE_ROLE_KEY` sebagai fallback kompatibilitas.

## Wajib diperiksa di Supabase
1. Deploy ulang `supabase/functions/username-register`.
2. Pastikan secret `SUPABASE_SERVICE_ROLE_KEY` tersedia di Edge Functions (bawaan Supabase) atau set `APP_SERVICE_ROLE_KEY` bila memakai secret khusus. Jangan pernah memasukkan service-role key ke `js/config.js`.
3. Pastikan `supabase-setup.sql` sudah dijalankan dan tabel `public.profiles` memiliki kolom `id`, `username`, `display_name`.
4. Pastikan URL dan publishable/anon key pada `js/config.js` berasal dari project Supabase yang sama.
5. Uji daftar username baru, login akun lama, logout, refresh halaman chat, dan sesi yang kedaluwarsa.

Pengujian lokal hanya mencakup pemeriksaan sintaks. Koneksi ke project Supabase dan alur auth live tetap harus diuji pada deployment karena membutuhkan akses ke project tersebut.
