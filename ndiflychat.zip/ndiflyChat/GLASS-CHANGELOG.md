# Glass update
- Popup "Info pesan": pembungkus `.readers-modal` tidak lagi diberi gaya kartu (luxe.css) — panel besar di belakang popup hilang.
- "Obrolan dengan vano" → "Obrolan ndifly" (index.html, js/landing.js).
- css/glass.css + js/glass.js: efek kaca di panel, kartu, popup, notifikasi, telepon masuk, panggilan & video call; latar chat baru (terang/gelap).
- Settings → Efek kaca: slider Buram (0–40) dan Transparansi (0–100%), preset, atur ulang. Tersimpan per perangkat.
