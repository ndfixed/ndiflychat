/* Vercel Serverless Function: GET /api/turn
   Mengembalikan daftar ICE server (STUN + TURN) berumur pendek untuk panggilan suara/video.
   Hanya pengguna yang sudah login (token Supabase valid) yang boleh meminta.

   Pilih SALAH SATU penyedia lewat Environment Variables di Vercel (lihat TURN-SETUP.md):
   - Cloudflare Realtime TURN : CF_TURN_KEY_ID, CF_TURN_API_TOKEN
   - Metered.ca               : METERED_DOMAIN (mis. namaapp.metered.live), METERED_API_KEY
   - TURN sendiri (coturn)    : TURN_URLS (pisahkan koma), TURN_USERNAME, TURN_CREDENTIAL
   Opsional: SUPABASE_URL, SUPABASE_ANON_KEY (bila beda dari js/config.js). */

const DEFAULT_SUPABASE_URL = 'https://jueycexmxuetbdqdwrfv.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'sb_publishable_FKg5xu4pKtTH45HbGTe4bw_NKs85MLe';

const json = (res, status, body) => {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
};

async function verifyUser(token) {
  const base = (process.env.SUPABASE_URL || DEFAULT_SUPABASE_URL).replace(/\/+$/, '');
  const key = process.env.SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY;
  const r = await fetch(`${base}/auth/v1/user`, { headers: { apikey: key, Authorization: `Bearer ${token}` } });
  return r.ok;
}

const asArray = v => (Array.isArray(v) ? v : v ? [v] : []);
function normalize(list) {
  // Terima bentuk { urls, username, credential } atau array-nya; buang yang tidak lengkap.
  return asArray(list)
    .map(s => ({ urls: s.urls || s.url, username: s.username, credential: s.credential }))
    .filter(s => s.urls && (!/^turns?:/i.test([].concat(s.urls)[0]) || (s.username && s.credential)));
}

async function fromCloudflare() {
  const id = process.env.CF_TURN_KEY_ID, token = process.env.CF_TURN_API_TOKEN;
  if (!id || !token) return null;
  const r = await fetch(`https://rtc.live.cloudflare.com/v1/turn/keys/${id}/credentials/generate-ice-servers`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ ttl: 3600 }),
  });
  if (!r.ok) throw new Error(`Cloudflare TURN ${r.status}`);
  const j = await r.json();
  return normalize(j.iceServers);
}

async function fromMetered() {
  const domain = process.env.METERED_DOMAIN, key = process.env.METERED_API_KEY;
  if (!domain || !key) return null;
  const r = await fetch(`https://${domain}/api/v1/turn/credentials?apiKey=${encodeURIComponent(key)}`);
  if (!r.ok) throw new Error(`Metered TURN ${r.status}`);
  return normalize(await r.json());
}

function fromStatic() {
  const urls = (process.env.TURN_URLS || '').split(',').map(s => s.trim()).filter(Boolean);
  if (!urls.length) return null;
  return normalize([{ urls, username: process.env.TURN_USERNAME, credential: process.env.TURN_CREDENTIAL }]);
}

module.exports = async (req, res) => {
  try {
    if (req.method !== 'GET') return json(res, 405, { error: 'Method not allowed' });
    const auth = String(req.headers.authorization || '');
    const token = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
    if (!token) return json(res, 401, { error: 'Login diperlukan' });
    if (!(await verifyUser(token))) return json(res, 401, { error: 'Sesi tidak valid' });

    const servers = (await fromCloudflare()) || (await fromMetered()) || fromStatic();
    if (!servers || !servers.length) return json(res, 200, { iceServers: [], configured: false });
    return json(res, 200, { iceServers: servers, configured: true });
  } catch (err) {
    console.error('[api/turn]', err);
    return json(res, 502, { error: 'Penyedia TURN tidak merespons', iceServers: [], configured: false });
  }
};
