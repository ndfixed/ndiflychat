-- ndiflyChat Voice Note setup
-- Run once in Supabase SQL Editor.
alter table public.chat_messages add column if not exists audio_url text;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_or_image;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_image_or_audio;
alter table public.chat_messages add constraint chat_messages_need_content_image_or_audio
  check (char_length(trim(coalesce(content,''))) > 0 or image_url is not null or audio_url is not null);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-voice', 'chat-voice', true, 15728640,
  array['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav'])
on conflict (id) do update set public=true, file_size_limit=15728640,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "authenticated users upload voice notes" on storage.objects;
create policy "authenticated users upload voice notes" on storage.objects
for insert to authenticated with check (bucket_id='chat-voice' and (storage.foldername(name))[1]=auth.uid()::text);

drop policy if exists "authenticated users read voice notes" on storage.objects;
create policy "authenticated users read voice notes" on storage.objects
for select to authenticated using (bucket_id='chat-voice');

drop policy if exists "owners delete voice notes" on storage.objects;
create policy "owners delete voice notes" on storage.objects
for delete to authenticated using (bucket_id='chat-voice' and (storage.foldername(name))[1]=auth.uid()::text);
