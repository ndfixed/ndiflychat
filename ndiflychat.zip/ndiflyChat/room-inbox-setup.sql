-- ndiflyChat inbox: pesan terakhir dan jumlah pesan belum dibaca per room.
-- Jalankan sekali di Supabase SQL Editor setelah supabase-setup.sql, private-chat-setup.sql, dan read-receipts-setup.sql.

create index if not exists chat_messages_room_created_idx
  on public.chat_messages(room_id, created_at desc);

-- Output function diperluas; DROP diperlukan karena PostgreSQL tidak mengizinkan
-- CREATE OR REPLACE mengubah tipe/kolom hasil RETURNS TABLE yang sudah ada.
drop function if exists public.get_room_inbox_summaries();

create or replace function public.get_room_inbox_summaries()
returns table (
  room_id uuid,
  latest_message_id uuid,
  latest_sender_id uuid,
  latest_content text,
  latest_image_url text,
  latest_audio_url text,
  latest_image_path text,
  latest_audio_path text,
  latest_reply_to uuid,
  latest_created_at timestamptz,
  latest_sender_username text,
  latest_sender_display_name text,
  latest_sender_avatar_url text,
  unread_count bigint
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    r.id as room_id,
    latest.id as latest_message_id,
    latest.sender_id as latest_sender_id,
    latest.content as latest_content,
    latest.image_url as latest_image_url,
    latest.audio_url as latest_audio_url,
    latest.image_path as latest_image_path,
    latest.audio_path as latest_audio_path,
    latest.reply_to as latest_reply_to,
    latest.created_at as latest_created_at,
    latest_profile.username as latest_sender_username,
    latest_profile.display_name as latest_sender_display_name,
    latest_profile.avatar_url as latest_sender_avatar_url,
    count(m.id) filter (where m.sender_id <> auth.uid() and mr.message_id is null)::bigint as unread_count
  from public.rooms r
  left join lateral (
    select cm.id, cm.sender_id, cm.content, cm.image_url, cm.audio_url, cm.image_path, cm.audio_path, cm.reply_to, cm.created_at
    from public.chat_messages cm
    where cm.room_id = r.id
    order by cm.created_at desc
    limit 1
  ) latest on true
  left join public.profiles latest_profile on latest_profile.id = latest.sender_id
  left join public.chat_messages m on m.room_id = r.id and m.sender_id <> auth.uid()
  left join public.message_reads mr on mr.message_id = m.id and mr.reader_id = auth.uid()
  where auth.uid() is not null
    and (r.is_public = true or exists (
      select 1 from public.room_members rm
      where rm.room_id = r.id and rm.user_id = auth.uid()
    ))
  group by r.id, latest.id, latest.sender_id, latest.content, latest.image_url, latest.audio_url, latest.image_path, latest.audio_path, latest.reply_to, latest.created_at, latest_profile.username, latest_profile.display_name, latest_profile.avatar_url, r.created_at
  order by coalesce(latest.created_at, r.created_at) desc;
$$;

revoke all on function public.get_room_inbox_summaries() from public;
grant execute on function public.get_room_inbox_summaries() to authenticated;
notify pgrst, 'reload schema';
