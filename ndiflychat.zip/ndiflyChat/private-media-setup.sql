-- ndiflyChat private message media.
-- New chat images and voice notes are stored in a PRIVATE bucket and signed only
-- for users who can read the corresponding message/room. Existing public URLs
-- in image_url/audio_url are retained for backward compatibility.

alter table public.chat_messages add column if not exists image_path text;
alter table public.chat_messages add column if not exists audio_path text;

-- Make the media constraint safe to execute repeatedly and support both legacy URLs
-- and the new private Storage object paths.
alter table public.chat_messages drop constraint if exists chat_messages_need_content_or_image;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_image_or_audio;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_media;
alter table public.chat_messages add constraint chat_messages_need_content_media
 check (
   char_length(trim(coalesce(content,''))) > 0
   or image_url is not null or image_path is not null
   or audio_url is not null or audio_path is not null
 );

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values (
 'chat-media','chat-media',false,20971520,
 array['image/png','image/jpeg','image/webp','audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav']
)
on conflict (id) do update set
 public=false,
 file_size_limit=20971520,
 allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "chat media upload own" on storage.objects;
create policy "chat media upload own"
on storage.objects for insert to authenticated
with check (
 bucket_id='chat-media'
 and (storage.foldername(name))[1]=(select auth.uid())::text
);

drop policy if exists "chat media read through message access" on storage.objects;
create policy "chat media read through message access"
on storage.objects for select to authenticated
using (
 bucket_id='chat-media'
 and exists (
   select 1
   from public.chat_messages m
   where m.image_path=storage.objects.name
      or m.audio_path=storage.objects.name
 )
);

drop policy if exists "chat media delete own" on storage.objects;
create policy "chat media delete own"
on storage.objects for delete to authenticated
using (
 bucket_id='chat-media'
 and (storage.foldername(name))[1]=(select auth.uid())::text
);
