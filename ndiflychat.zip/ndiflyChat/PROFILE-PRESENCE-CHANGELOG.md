# Profile, presence & chat layout update

- Added an in-chat profile sheet for private-chat participants, including avatar, display name, username, bio, online state and last-seen timestamp.
- Tapping the private-chat header name/avatar opens the participant profile. Tapping the current user's sidebar avatar opens their own profile.
- User search results now show profile photos; tapping the small avatar opens profile details, while tapping the row starts a private chat.
- Private conversation list avatars are hydrated from the matching profile photo when available.
- Read-receipt list now displays reader profile photos when available.
- Added editable 160-character bio field to Settings.
- Added a lightweight last_seen heartbeat (updates while the chat tab is visible).
- Lowered the mobile dock and increased the chat safe area so the composer/messages have more breathing room.

## Required Supabase migration
Run `profile-presence-setup.sql` once in Supabase SQL Editor before using bio and online/last-seen fields. Existing profile photo upload continues to use the existing `chat-images` Storage bucket.

Online is inferred from `last_seen` updated in the last 2 minutes; this is a lightweight last-active indicator, not a guaranteed real-time presence connection.
