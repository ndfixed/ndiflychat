-- ndiflyChat — izin Realtime untuk PANGGILAN (suara/video) di chat pribadi dan Global.
-- Jalankan SEKALI di Supabase SQL Editor. Aman dijalankan ulang.
--
-- Topik channel: 'call:<id ruang>'. Dipakai untuk (1) sinyal WebRTC & dering lewat Broadcast,
-- (2) daftar peserta lewat Presence. Hanya anggota ruang yang boleh menerima/mengirim;
-- ruang publik (Global Community) terbuka untuk semua pengguna yang sudah login.

drop policy if exists "ndiflyChat call receive" on realtime.messages;
create policy "ndiflyChat call receive"
on realtime.messages for select to authenticated
using (
  realtime.messages.extension in ('broadcast', 'presence')
  and (select realtime.topic()) like 'call:%'
  and exists (
    select 1 from public.rooms r
    where ('call:' || r.id::text) = (select realtime.topic())
      and (
        r.is_public = true
        or exists (select 1 from public.room_members rm where rm.room_id = r.id and rm.user_id = (select auth.uid()))
      )
  )
);

drop policy if exists "ndiflyChat call send" on realtime.messages;
create policy "ndiflyChat call send"
on realtime.messages for insert to authenticated
with check (
  realtime.messages.extension in ('broadcast', 'presence')
  and (select realtime.topic()) like 'call:%'
  and exists (
    select 1 from public.rooms r
    where ('call:' || r.id::text) = (select realtime.topic())
      and (
        r.is_public = true
        or exists (select 1 from public.room_members rm where rm.room_id = r.id and rm.user_id = (select auth.uid()))
      )
  )
);
