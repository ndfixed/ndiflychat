# Luxe 7 — bugfix & design pass

## Wajib dilakukan di Supabase
Jalankan **`bugfix-7.sql`** sekali di SQL Editor (aman diulang). Berisi perbaikan KRITIS: policy `chat_messages` di
`private-chat-setup.sql` lama memakai `rm.room_id = room_id` (selalu benar), sehingga anggota satu DM bisa membaca/mengirim
ke semua DM lain. Juga: batas nama ruang DM 40→64, kunci anti-DM-ganda, indeks. Deploy ulang Edge Function `username-register`.

## Bug diperbaiki
- Toast tertarik jadi kolom tinggi (top + bottom bentrok).
- Ruang kosong ±100px di atas dock (mobile) dan di bawah composer (desktop).
- Tombol kembali tampil di desktop; tombol tutup banner sambutan tidak berfungsi.
- `auth.js` mendeteksi halaman daftar dari URL → kini dari struktur form (aman untuk clean URL).
- Font heading Cormorant Garamond dipakai CSS tetapi tidak dimuat.
- Auto-scroll melompat saat membaca riwayat; pesan terkirim bisa masuk ke ruang lain saat pindah ruang.
- Pesan dihapus tidak hilang realtime; chat tidak sinkron setelah tab tidur/offline.
- Filter pencarian pesan terbawa saat pindah ruang; banner sambutan muncul lagi setelah ditutup.
- Foto profil lama tidak dihapus dari storage saat diganti.
- Enter saat komposisi IME mengirim pesan.

## Desain
`css/luxe7.css`: pesan beruntun digabung, pemisah hari, tautan otomatis, chip lampiran, lightbox gambar, aksi pesan
muncul saat hover, banner ringkas di ponsel, fokus/hover halus, badge unread di judul tab, reduced-motion.

## Belum teruji
Alur live (login, DM, panggilan WebRTC, upload) butuh project Supabase asli; pengujian memakai Supabase tiruan.
Catatan: lencana verified/developer hanya cek username `andif_dev` di klien — daftarkan akun itu lebih dulu.

## Informasi — perkenalan pengembang
Bagian paling atas `informasi.html` kini memperkenalkan **4ndifly**, pengembang independen yang masih SMK: foto
(`assets/4ndifly.jpg`), sapaan, bio, kutipan, dan tag. Teks bio/kutipan bisa diubah di blok `.dev-intro`.

## Landing, login, daftar
- Landing: bagian "Cara mulai" (3 langkah) dan "Tim": **andif_dev** sebagai satu-satunya pengembang; **nata** dan **dika** ditampilkan sebagai teman support. Footer dan teks "Dibangun…" disesuaikan.
- Login/daftar: kartu "Dikembangkan oleh andif_dev · dibantu nata & dika", peringatan Caps Lock, username otomatis huruf kecil + validasi langsung, meter kekuatan password, indikator kecocokan konfirmasi, padding panel samping diperbaiki.

## Bahasa sehari-hari & peran penguji
- Istilah teknis (Supabase, realtime, WebRTC, backend, Edge Function, API key, dll.) dihapus dari semua teks yang dilihat pengguna. Catatan teknis kini hanya ada di Informasi ("Catatan teknis dari andif_dev") dan di console browser.
- Pesan error di login/daftar/chat/config ditulis ulang dalam bahasa biasa.
- **andif_dev** = satu-satunya pengembang. **nata** dan **dika** = teman support yang diminta mengetes apakah website berjalan normal (landing, FAQ, Informasi, kartu di login/daftar, contoh percakapan).

## Desain lanjutan
Landing: header kaca saat scroll, kartu muncul perlahan (nonaktif di mode Hemat/reduced-motion), FAQ, bagian "Aman dan tertata". Login/daftar: kartu bergetar saat salah + spinner di tombol. Chat: tombol "ke pesan terbaru" dengan penghitung pesan baru. Mode terang: kontras teks kecil lebih tegas.

## Ronde 3 — animasi, desain, bug
**Animasi** (otomatis mati di mode Hemat & reduced-motion): hero landing masuk berurutan; pratinjau chat "hidup" (pesan tiba satu per satu + "dika sedang mengetik"); kilau pada tombol utama; kartu login/daftar/Informasi/Settings masuk berurutan; pesan baru di chat muncul dengan pop (hanya pesan baru, bukan seluruh daftar); daftar chat masuk berurutan sekali; tombol kirim berputar halus; dialog, menu emoji, lampiran, dan overlay panggilan muncul halus; transisi antarhalaman (Chrome/Android).
**Bug**: nilai statistik di panel info menempel ke tepi; panel info tertutup dock; HP landscape (tinggi pendek) hampir tanpa ruang pesan; toast error tampil di landing/Informasi padahal tidak perlu layanan akun.
**Tambahan**: favicon, ikon aplikasi (bisa "Tambahkan ke layar utama"), `manifest.webmanifest`, meta deskripsi, `noindex` untuk chat/settings, tag pratinjau tautan (og), `vercel.json` (header keamanan dasar).
Catatan: `og:image` memakai path relatif; ganti ke URL penuh domainmu agar pratinjau muncul di WhatsApp/sosmed.

## Ronde 4 — telepon, salam WIB, popup selamat datang
**Wajib:** jalankan **`calls-setup.sql`** sekali di Supabase SQL Editor (izin Realtime untuk topik `call:<id ruang>`). Tanpa ini notifikasi/panggilan tidak aktif; pesan error ramah tampil ke pengguna dan petunjuk teknis ke console.
**Panggilan** (suara & video) kini punya **halaman sendiri** `call.html` (+ `js/call.js`, `js/call-tones.js`, `css/call.css`), untuk chat pribadi dan Global:
- Chat pribadi: tekan telepon/video → penelepon masuk ke `call.html` ("Memanggil…" + nada tunggu); lawan bicara melihat layar panggilan masuk penuh (Terima/Tolak + nada dering). Ditolak/dibatalkan/tak dijawab (45 dtk) ditangani dua arah.
- Global: panggilan terdeteksi lewat presence → semua pengguna melihat banner **"Bergabung"** (+ bunyi notifikasi), lalu bisa bicara bersama (hingga 8 peserta). Banner hilang saat panggilan selesai.
- Di dalam panggilan: mikrofon, kamera (bisa dinyalakan di tengah panggilan suara), balik kamera, indikator bicara, tanda mikrofon mati, timer, layar tetap menyala, kontrol otomatis tersembunyi saat video.
- Teknis: WebRTC "perfect negotiation", ICE restart saat jaringan goyang, STUN publik. Opsional TURN: lihat komentar `iceServers` di `js/config.js`.
- Halaman harus dibuka lewat **https://** (atau localhost) agar browser mengizinkan mikrofon/kamera.
**Salam WIB:** "Good morning / afternoon / evening / night" mengikuti jam Asia/Jakarta (05–11 / 12–17 / 18–20 / 21–04), tampil di kartu profil sidebar dan diperbarui otomatis.
**Popup selamat datang:** muncul saat masuk ke chat ("Selamat datang, <nama>"), hilang otomatis 10 detik (ada bar hitung mundur & tombol tutup), sekali per sesi/login.

## Ronde 5 — bug sweep
- Panggilan tidak lagi menggantung: bila lawan bicara tercatat di daftar tetapi koneksi tak terbentuk dalam 25 detik, muncul "Tidak bisa tersambung" lalu kembali ke chat (sebelumnya menunggu selamanya).
- Tombol maju/mundur browser: halaman telepon yang dipulihkan dari cache langsung kembali ke chat; chat yang dipulihkan dimuat ulang agar koneksi realtime hidup lagi.
- Indikator bicara otomatis aktif setelah interaksi pertama di browser yang menunda audio.
- Layout telepon di ponsel landscape diperbaiki (teks patah, video lokal terlalu besar).
- Teruji: tautan panggilan tidak valid, ruang bukan anggota, tanpa login, izin mikrofon ditolak, kamera tidak ada (lanjut sebagai suara), dering terlambat, penelepon menghilang saat berdering, tidak dijawab 45 detik, peserta "zombie"; plus alur login/daftar/pengaturan.

## Ronde 6 — notifikasi yang benar-benar sampai + telepon tanpa keluar dari chat
**Akar masalah "tidak ada notif / Panggilan belum bisa tersambung":** channel Realtime privat gagal dibuka. Penyebab umum: (1) `calls-setup.sql` belum dijalankan, (2) token login belum dipasang ke koneksi realtime sebelum subscribe.
- `js/call-channel.js` (baru): memasang token login lebih dulu, mencoba channel privat, dan bila ditolak otomatis memakai **channel publik sebagai cadangan** (panggilan & notifikasi tetap jalan; konsol memberi catatan). Alasan error disimpan.
- Layar error telepon kini punya **"Detail teknis (untuk andif_dev)"** berisi alasan persis + langkah perbaikan.
- Kehadiran peserta di-refresh tiap 8 detik agar tetap tercatat setelah koneksi putus-sambung.
**Telepon tanpa meninggalkan halaman chat:** panggilan (Global maupun pribadi) kini terbuka sebagai layar penuh *di dalam* halaman chat. Tombol panah-bawah memperkecilnya menjadi **bar mini** (timer, mute, akhiri) sehingga kamu tetap bisa membaca/mengirim pesan dan menerima panggilan/notifikasi baru; ketuk bar untuk membuka lagi. Tombol Back Android juga memperkecil panggilan.
**Notifikasi pesan baru:** kartu notifikasi (ketuk untuk membuka ruang) saat ada pesan dari ruang lain; notifikasi browser bila tab tidak aktif dan izin diberikan (Pengaturan → Notifikasi).
**vercel.json:** `X-Frame-Options` diubah ke `SAMEORIGIN` (layar telepon memakai iframe satu-origin; `DENY` akan memblokirnya).
**Wajib/disarankan:** deploy ulang seluruh folder (terutama `vercel.json`), jalankan `calls-setup.sql`, dan aktifkan Realtime di project Supabase.
Catatan jujur: notifikasi hanya tiba saat ndiflyChat terbuka (atau tab di latar belakang yang masih aktif). Notifikasi saat browser benar-benar tertutup butuh layanan Web Push khusus yang belum ada.

## Ronde 7 — bug sweep fitur chat
Diuji ujung-ke-ujung (26 pemeriksaan): penghitung karakter, Enter/Shift+Enter, emoji, balas, hapus pesan, cari pesan, panel info, kirim foto, cari username → DM baru, tema, logout, unggah foto profil.
- Ikon hasil pencarian username berupa panah "buka tautan luar" padahal membuka chat → diganti ikon pesan.
- Atribut izin iframe telepon disederhanakan (`microphone; camera`) untuk menghilangkan peringatan Permissions Policy di konsol.

## Ronde 8 — "Menghubungkan…" tidak kunjung tersambung
**Penyebab paling mungkin:** dering/notifikasi (sinyal) sudah jalan, tetapi koneksi media antar-HP diblokir jaringan (data seluler/CGNAT, Wi-Fi ketat) karena sebelumnya hanya memakai STUN, tanpa relay **TURN**.
- **`api/turn.js`** (Vercel Function, baru): memberi kredensial TURN sementara hanya kepada pengguna yang login. Mendukung Cloudflare Realtime TURN, Metered.ca, atau coturn sendiri. Panduan langkah demi langkah: **`TURN-SETUP.md`**.
- Urutan sumber ICE di `call.js`: `js/config.js` → `/api/turn` → relay publik cadangan (tidak dijamin). Permintaan `/api/turn` dibatasi 3,5 detik agar tidak menunda panggilan.
- Kandidat ICE kini dikirim berkelompok (3 pesan sinyal, sebelumnya belasan) + `iceCandidatePoolSize: 2` → negosiasi lebih cepat dan tahan batas laju Realtime.
- Status tahap yang jelas: "Menunggu lawan bicara merespons…", "Mencari jalur koneksi…", "Koneksi lambat…". Setelah 6 detik muncul **"Detail koneksi"** (sumber ICE, ada/tidak TURN, jumlah sinyal terkirim/diterima, jenis kandidat host/srflx/relay, status ICE). Setelah tersambung, console mencatat jalur terpilih (host/srflx/relay).
- Teruji: TURN dari `/api/turn` dipakai, 404 → relay cadangan, `/api/turn` menggantung tidak memblokir panggilan, panel diagnosa, regresi panggilan 27/27.

## Ronde 9 — notifikasi "peserta keluar" palsu saat panggilan berjalan
**Gejala:** beberapa detik setelah tersambung muncul "si A keluar dari panggilan" padahal A tidak menutup (pada panggilan pribadi bisa langsung menutup panggilan).
**Penyebab:** `call.js` menyegarkan presence tiap 8 detik; di Realtime asli pembaruan presence bisa sekejap tampil sebagai "keluar lalu masuk", dan kode langsung menganggap peserta pergi lalu menutup koneksinya. Mock uji sebelumnya mengubah presence secara atomik sehingga bug tidak tertangkap — kini mock meniru perilaku asli dan bug sudah direproduksi dulu sebelum diperbaiki.
**Perbaikan:**
- Penyegaran presence dihapus; hanya dipulihkan bila catatan kita benar-benar hilang (cek tiap 10 dtk).
- Peserta baru dianggap keluar setelah hilang **12 detik**, atau **langsung** bila ia menekan Akhiri (sinyal `bye`). Jalur media yang mati >20 detik juga dianggap pergi, dan bila ia kembali akan tersambung ulang otomatis.
- Tampilan peserta disegarkan seketika setelah ada yang keluar (sebelumnya bisa tertunda).
- Lawan bicara menutup sebelum tersambung → "Panggilan sudah berakhir" (tidak menggantung).
- Banner "Bergabung" di chat tidak berkedip saat presence sekejap berubah.
- Teruji: 26 detik stabil sambil mute/unmute berulang tanpa notifikasi palsu (Global), DM 25 detik dengan toggle mic/kamera, kepergian nyata terdeteksi <1 detik, crash terdeteksi ±12 detik; regresi 27/27, 10/10, 26/26.
