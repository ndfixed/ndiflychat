-- ndiflyChat permission repair: run in Supabase SQL Editor after setup.
-- Grants SQL privileges only; existing Row Level Security policies remain enabled.
grant usage on schema public to authenticated, service_role;
do $$ begin
  if to_regclass('public.profiles') is not null then
    execute 'grant select, insert, update on table public.profiles to authenticated';
    execute 'grant select, insert, update on table public.profiles to service_role';
  end if;
  if to_regclass('public.rooms') is not null then
    execute 'grant select, insert, update on table public.rooms to authenticated';
  end if;
  if to_regclass('public.chat_messages') is not null then
    execute 'grant select, insert, delete on table public.chat_messages to authenticated';
  end if;
  if to_regclass('public.message_reads') is not null then
    execute 'grant select, insert on table public.message_reads to authenticated';
  end if;
  if to_regclass('public.room_members') is not null then
    execute 'grant select on table public.room_members to authenticated';
  end if;
  if to_regprocedure('public.start_direct_chat(uuid)') is not null then
    execute 'grant execute on function public.start_direct_chat(uuid) to authenticated';
  end if;
end $$;
notify pgrst, 'reload schema';
