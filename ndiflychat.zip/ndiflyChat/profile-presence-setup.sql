-- Tambahan bio dan status online/terakhir dilihat untuk ndiflyChat
alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists last_seen timestamptz;
update public.profiles set bio = '' where bio is null;
create index if not exists profiles_last_seen_idx on public.profiles(last_seen desc);
-- RLS profiles yang sudah ada tetap berlaku: semua pengguna terautentikasi dapat membaca profil,
-- sedangkan pengguna hanya dapat memperbarui profil miliknya sendiri.
