-- ndiflyChat Status: aktif maksimal 24 jam, batas 2 MB, cleanup melalui Supabase Storage API.
-- Jalankan di Supabase SQL Editor. Tidak menghapus storage.objects secara langsung;
-- penghapusan database langsung dapat meninggalkan file fisik di object storage.

create table if not exists public.user_status (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 media_path text not null unique,
 media_type text not null check (media_type in ('image','video')),
 caption text not null default '' check (char_length(caption) <= 180),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours'),
 constraint status_expiry_window check (expires_at <= created_at + interval '24 hours' and expires_at > created_at)
);
create index if not exists user_status_active_idx on public.user_status(expires_at desc, created_at desc);

-- Waktu status ditetapkan server agar klien tidak dapat memperpanjang masa aktif
-- dengan mengirim created_at / expires_at palsu.
create or replace function public.set_user_status_timestamps()
returns trigger
language plpgsql
set search_path = public
as $$
begin
 new.created_at := now();
 new.expires_at := new.created_at + interval '24 hours';
 return new;
end;
$$;
drop trigger if exists user_status_force_24h on public.user_status;
create trigger user_status_force_24h
before insert on public.user_status
for each row execute function public.set_user_status_timestamps();
revoke all on function public.set_user_status_timestamps() from public, anon, authenticated;
alter table public.user_status enable row level security;
grant select, insert, delete on public.user_status to authenticated;
drop policy if exists "status read active" on public.user_status;
create policy "status read active" on public.user_status for select to authenticated using (expires_at > now());
drop policy if exists "status insert own" on public.user_status;
create policy "status insert own" on public.user_status for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "status delete own" on public.user_status;
create policy "status delete own" on public.user_status for delete to authenticated using (user_id = auth.uid());

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-status','chat-status',false,2097152,array['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
on conflict (id) do update set public=false,file_size_limit=2097152,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "status media read" on storage.objects;
drop policy if exists "status media read active" on storage.objects;
create policy "status media read active" on storage.objects for select to authenticated using (
 bucket_id='chat-status' and exists (
  select 1 from public.user_status s
  where s.media_path=storage.objects.name and s.expires_at > now()
 )
);
drop policy if exists "status media upload own" on storage.objects;
create policy "status media upload own" on storage.objects for insert to authenticated with check (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "status media delete own" on storage.objects;
create policy "status media delete own" on storage.objects for delete to authenticated using (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);

-- Cleanup job calls the status-cleanup Edge Function every minute.
-- The Edge Function removes files through Storage API first, then deletes database records.
