# Polish & Glass pass

**Bug fixes**
- Created missing `css/chat-refine.css` (chat.html referenced it → 404).
- Inputs are 16px on touch devices (stops iOS Safari auto-zoom on focus).
- Sidebar search input now fills its 40px box (was 14px tall, small tap area).
- Touch chat: "Balas/Hapus" and "Terkirim" share one row.
- `js/config.js` error box no longer covers the dock.
- `100vh` → `100dvh` on Informasi/Settings; larger tap targets on touch.

**Smoothness**
- Dock: removed infinite float + looping sheen (forced backdrop re-render each frame); sheen now plays once per entrance/menu change.
- Removed backdrop-filter from stacked cards, list items and the chat shell; removed blur filters from background orbs and call blobs.
- `js/polish.js` pauses decorative animations when the tab is hidden and while scrolling.

**Glass (iOS 26)**
- Dock is clearer and less tinted, lighter blur, softer shadows (dark + light).
- Dock shrinks to icons while scrolling down, returns on scroll up (non-chat pages).
- Same glass recipe on toasts and top bars.

New files: `css/polish.css`, `css/chat-refine.css`, `js/polish.js`. Modified: `css/dock-glass.css`, `js/dock-glass.js`, `css/call.css`, `js/config.js`, all page HTML (links + cache-busters).

## Update 2 — dock "double box" + dock settings
- Removed the reserved bottom strip on Chat (list), Calls, Status and Settings: content now scrolls under the glass dock like Informasi (`polish.css` §6).
- New Settings → "Tampilan docbar": sliders for blur (0–30) and transparency (0–100%), presets (Jernih / Seimbang / Pekat) and reset. Saved per device in localStorage (`ndifly_dock_blur`, `ndifly_dock_clear`), applied on every page via `js/theme.js`; UI in `js/dock-settings.js`.
