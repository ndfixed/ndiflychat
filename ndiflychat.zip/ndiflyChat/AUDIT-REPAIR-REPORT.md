# NDIFLYCHAT — Audit & perbaikan menyeluruh

## Perbaikan kode
- Memindahkan implementasi profil, presence, dan dock kembali ke scope utama `chat.js` agar state Supabase/session dapat dipakai dengan benar. Menghapus handler profil duplikat dan menambahkan guard agar respons profil lama tidak menimpa modal terbaru.
- Mengamankan signaling audio/video: private Realtime channel wajib; tidak ada fallback diam-diam ke channel publik. Token Realtime disegarkan ketika sesi berubah.
- Memperbaiki preview inbox untuk pesan gambar dan voice note; RPC mengembalikan path media, avatar pengirim, dan output function dapat dimigrasikan berulang.
- Upload foto dan voice note chat baru memakai bucket `chat-media` private. Signed URL dibuat setelah pesan tersimpan; akses file mengikuti RLS pesan/ruang. Penghapusan pesan juga mencoba membersihkan objek privat.
- Status menggunakan bucket private, waktu kedaluwarsa ditetapkan trigger database (24 jam dari waktu server), pembacaan memakai RLS, dan cleanup menghapus objek memakai Supabase Storage API lewat Edge Function.
- Kompresi video status didisiplinkan: jika browser tidak mendukung transcode atau hasil tetap di atas 2 MB, upload ditolak dengan pesan yang jelas.
- Memperbaiki idempotensi SQL Voice Note; RPC inbox di-drop/recreate saat tipe hasil berubah.
- Memperbarui nama di pratinjau landing menjadi Nata dan Dika, konsisten dengan permintaan, tanpa mengubah pernyataan bahwa pengembang dan penguji utama dilakukan mandiri oleh `andif_dev`.
- Menaikkan cache-busting aset frontend agar browser mengambil file baru setelah deploy.

## File penting
- `NDIFLYCHAT-DATABASE-REPAIR.sql`: migrasi database lengkap dalam urutan yang benar.
- `PRIVATE-MEDIA-SETUP.md`: catatan bucket media chat private dan kompatibilitas media lama.
- `STATUS-SETUP.md`: deploy `status-cleanup`, secret, dan jadwal cleanup fisik.
- `supabase/functions/username-register`: Edge Function pendaftaran username-only.
- `supabase/functions/status-cleanup`: Edge Function hapus media status kedaluwarsa.

## Hasil pemeriksaan lokal
- 11 file JavaScript eksternal lolos `node --check`.
- 5 blok JavaScript inline lolos `node --check`.
- 7 halaman HTML berhasil diparse; tidak ditemukan ID ganda, aset lokal hilang, atau anchor internal yang putus.
- 11 file CSS berhasil diparse tanpa error sintaks.
- ZIP diuji setelah build.

## Batas pengujian
Pemeriksaan dilakukan statis dan lokal. Browser visual otomatis terhalang oleh lingkungan eksekusi, Deno/Supabase CLI tidak tersedia, dan project Supabase/akun/perangkat/WebRTC aktif tidak dapat diakses dari audit ini. Karena itu keberhasilan deploy, autentikasi real, push, serta panggilan lintas perangkat belum dapat diklaim. Jalankan SQL gabungan dan deploy Edge Functions sebelum menguji fitur live.

## Kompatibilitas media lama
Upload chat baru menggunakan bucket private. URL file lama tetap di bucket `chat-images`/`chat-voice` yang public demi kompatibilitas avatar dan riwayat lama. File lama belum otomatis dipindahkan; lihat `PRIVATE-MEDIA-SETUP.md`.
