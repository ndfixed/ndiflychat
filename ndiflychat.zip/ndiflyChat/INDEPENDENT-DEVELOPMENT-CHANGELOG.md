# Independent Development Update

- Pengembangan, perbaikan bug, pengujian sumber kode, dan pemeliharaan utama NDIFLYCHAT ditangani mandiri oleh `andif_dev`.
- Nama Nata dan Dika tetap dipakai pada bagian yang memang menampilkan nama tersebut; keduanya bukan klaim bahwa pengujian otomatis atau pengelolaan layanan dilakukan oleh pihak eksternal.
- Supabase digunakan untuk autentikasi/database dan Vercel untuk hosting; penggunaan infrastruktur ini dijelaskan secara transparan.
- Perbaikan auth mencakup konfigurasi client, persistensi/refresh sesi, validasi username, penanganan error Edge Function, serta proses login/daftar. SQL voice note dibuat idempotent dan RPC inbox diperbarui untuk tipe media terbaru.
- Audit ini juga memperbaiki scope JavaScript chat, signaling panggilan agar gagal tertutup pada channel privat, status 24 jam dengan bucket private, preview inbox foto/VN, penyimpanan media chat baru ke bucket private, serta cache-busting untuk aset frontend.

Catatan: pemeriksaan sintaks dan struktur berjalan lokal. Pengujian akun Supabase aktif, perangkat, browser lintas platform, dan WebRTC tetap memerlukan deployment dan pengujian langsung.
