# Agar panggilan suara/video selalu tersambung (TURN)

**Gejala:** nada dering & notifikasi sudah jalan, tetapi setelah dijawab layar berhenti di "Menghubungkan…".
**Penyebab:** kedua HP tidak bisa saling terhubung langsung — umum terjadi di data seluler (CGNAT), Wi-Fi kantor/kampus, atau
bila kedua orang beda jaringan. Solusinya server relay **TURN**. Media tetap terenkripsi; relay hanya meneruskan paket.

ndiflyChat sudah menyiapkan semuanya. Kamu cukup memilih SATU penyedia TURN dan mengisi Environment Variables di Vercel.

## Opsi A — Cloudflare Realtime TURN (disarankan, kuota gratis besar)
1. Dashboard Cloudflare → **Realtime → TURN** → *Create TURN key*.
2. Salin **Key ID** dan **API token**.
3. Vercel → Project → *Settings → Environment Variables*:
   - `CF_TURN_KEY_ID` = Key ID
   - `CF_TURN_API_TOKEN` = API token
4. *Redeploy* project.

## Opsi B — Metered.ca (ada paket gratis)
1. Buat akun di metered.ca → buat aplikasi → catat **domain** (mis. `namaapp.metered.live`) dan **API key**.
2. Vercel Environment Variables: `METERED_DOMAIN`, `METERED_API_KEY` → Redeploy.

## Opsi C — TURN sendiri (coturn)
`TURN_URLS` (pisahkan koma, mis. `turn:turn.domainmu.com:3478,turns:turn.domainmu.com:443`), `TURN_USERNAME`, `TURN_CREDENTIAL`.

## Cara memastikan sudah aktif
1. Buka `https://domainmu/api/turn` tanpa login → harus `401` (artinya fungsi hidup & terlindungi).
2. Lakukan panggilan antar dua HP di jaringan berbeda. Jika masih macet >6 detik, ketuk **"Detail koneksi"** di layar panggilan:
   - `Sumber ICE: api/turn` dan `Server relay (TURN): ada` → konfigurasi benar.
   - `Sumber ICE: relay-publik` → `/api/turn` belum aktif; yang dipakai hanya relay publik cadangan (tidak dijamin).
   - `Server relay (TURN): TIDAK ADA` → belum ada TURN sama sekali.
   - `kandidat lokal: ... relay N` (N > 0) → relay berhasil dialokasikan.
   - Setelah tersambung, console browser mencatat `jalur koneksi terpilih: relay ↔ ...` bila relay dipakai.

Tanpa pengaturan apa pun, aplikasi mencoba **relay publik gratis** sebagai cadangan. Itu dibagi banyak orang, bisa lambat/dibatasi,
dan bisa berhenti bekerja sewaktu-waktu; matikan dengan `publicRelay: false` di `js/config.js`.
