import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
});

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method tidak didukung.' }, 405);
  const expected = Deno.env.get('STATUS_CLEANUP_SECRET');
  const supplied = req.headers.get('x-status-cleanup-secret') || '';
  if (!expected || supplied.length !== expected.length || supplied !== expected) {
    return json({ error: 'Tidak diizinkan.' }, 401);
  }

  const url = Deno.env.get('SUPABASE_URL');
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || Deno.env.get('APP_SERVICE_ROLE_KEY');
  if (!url || !serviceKey) return json({ error: 'Konfigurasi server belum lengkap.' }, 500);

  const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
  const now = new Date().toISOString();
  const { data: expired, error: readError } = await admin
    .from('user_status')
    .select('id,media_path')
    .lte('expires_at', now)
    .order('expires_at', { ascending: true })
    .limit(200);
  if (readError) {
    console.error('[status-cleanup] read:', readError.message);
    return json({ error: 'Gagal membaca status kedaluwarsa.' }, 500);
  }
  if (!expired?.length) return json({ ok: true, removed: 0 });

  const paths = expired.map((row) => row.media_path).filter((path): path is string => typeof path === 'string' && path.length > 0);
  if (paths.length) {
    const { error: storageError } = await admin.storage.from('chat-status').remove(paths);
    if (storageError) {
      console.error('[status-cleanup] storage:', storageError.message);
      return json({ error: 'File status belum berhasil dihapus; akan dicoba lagi.' }, 502);
    }
  }

  const ids = expired.map((row) => row.id);
  const { error: deleteError } = await admin.from('user_status').delete().in('id', ids);
  if (deleteError) {
    console.error('[status-cleanup] rows:', deleteError.message);
    return json({ error: 'File sudah dihapus, tetapi catatan database belum terhapus.' }, 500);
  }
  return json({ ok: true, removed: ids.length });
});
