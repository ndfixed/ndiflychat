import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
});

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'Method tidak didukung.' }, 405);

  try {
    const raw = await req.text();
    if (raw.length > 2048) return json({ error: 'Permintaan terlalu besar.' }, 413);
    const payload = JSON.parse(raw);
    const username = payload?.username;
    const password = payload?.password;
    if (typeof username !== 'string' || !/^[a-z0-9_]{3,24}$/.test(username)) {
      return json({ error: 'Username harus 3–24 karakter: huruf kecil, angka, atau underscore.' }, 400);
    }
    if (typeof password !== 'string' || password.length < 8 || password.length > 128) {
      return json({ error: 'Password harus 8–128 karakter.' }, 400);
    }

    const url = Deno.env.get('SUPABASE_URL');
    // Supabase provides SUPABASE_SERVICE_ROLE_KEY to Edge Functions by default.
    // APP_SERVICE_ROLE_KEY remains supported for older deployments.
    const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || Deno.env.get('APP_SERVICE_ROLE_KEY');
    if (!url || !serviceKey) return json({ error: 'Konfigurasi server belum lengkap.' }, 500);

    const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });
    // Internal identifier is generated only on the server; no email is sent.
    const email = `${username}@ndiflychat.invalid`;
    const { data, error } = await admin.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
      user_metadata: { username, display_name: username },
    });
    if (error) {
      const code = (error as { code?: string }).code;
      if (code === 'email_exists' || code === 'user_already_exists' || code === '23505' || /already been registered|already exists|duplicate/i.test(error.message)) {
        return json({ error: 'Username sudah digunakan. Silakan pilih username lain.' }, 409);
      }
      console.error('username-register:', error.message);
      return json({ error: 'Akun gagal dibuat. Periksa konfigurasi server lalu coba lagi.' }, 400);
    }

    const { error: profileError } = await admin.from('profiles').upsert({
      id: data.user.id, username, display_name: username,
    }, { onConflict: 'id' });
    if (profileError) {
      // Remove the partially-created account so a retry is safe.
      await admin.auth.admin.deleteUser(data.user.id);
      console.error('profile create:', profileError.message);
      return json({ error: 'Profil akun gagal dibuat. Jalankan supabase-setup.sql terlebih dahulu.' }, 500);
    }
    return json({ ok: true });
  } catch (error) {
    console.error('username-register request failed');
    return json({ error: 'Permintaan tidak valid.' }, 400);
  }
});
