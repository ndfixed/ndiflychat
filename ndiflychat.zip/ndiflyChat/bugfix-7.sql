-- ndiflyChat BUGFIX 7 — jalankan SEKALI di Supabase SQL Editor (aman dijalankan ulang).
-- Wajib bila kamu sudah menjalankan private-chat-setup.sql versi lama.
--
-- [KRITIS] Policy lama pada chat_messages memakai `rm.room_id = room_id`. Di dalam subquery,
-- `room_id` mengacu ke kolom room_members itu sendiri, sehingga kondisinya SELALU benar:
-- siapa pun yang menjadi anggota satu ruang privat dapat membaca dan mengirim pesan ke SEMUA
-- ruang privat lain. Di bawah ini kolom dikualifikasi dengan benar.

drop policy if exists "members can read room messages" on public.chat_messages;
create policy "members can read room messages"
on public.chat_messages for select to authenticated
using (
  exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
  or exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
);

drop policy if exists "members can send room messages" on public.chat_messages;
create policy "members can send room messages"
on public.chat_messages for insert to authenticated
with check (
  auth.uid() = sender_id and (
    exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
    or exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
  )
);

-- Nama ruang DM bisa mencapai 58 karakter; batas lama 40 memotong username panjang.
alter table public.rooms drop constraint if exists rooms_name_check;
alter table public.rooms add constraint rooms_name_check check (char_length(name) between 3 and 64);

-- Cegah dua ruang DM ganda saat tombol ditekan dua kali (advisory lock per pasangan pengguna).
create or replace function public.start_direct_chat(p_target_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_me uuid := auth.uid();
  v_room uuid;
  v_name text;
  v_target_username text;
  v_my_username text;
begin
  if v_me is null then raise exception 'Login diperlukan'; end if;
  if p_target_user is null or p_target_user = v_me then raise exception 'Pilih pengguna lain'; end if;

  select username into v_target_username from public.profiles where id = p_target_user;
  if v_target_username is null then raise exception 'Pengguna tidak ditemukan'; end if;
  select username into v_my_username from public.profiles where id = v_me;

  perform pg_advisory_xact_lock(hashtextextended(least(v_me::text, p_target_user::text) || ':' || greatest(v_me::text, p_target_user::text), 0));

  select rm1.room_id into v_room
  from public.room_members rm1
  join public.room_members rm2 on rm2.room_id = rm1.room_id
  join public.rooms r on r.id = rm1.room_id and r.is_public = false
  where rm1.user_id = v_me and rm2.user_id = p_target_user
    and (select count(*) from public.room_members allm where allm.room_id = rm1.room_id) = 2
  limit 1;

  if v_room is not null then return v_room; end if;

  v_name := 'DM - @' || coalesce(v_my_username, 'user') || ' / @' || v_target_username;
  insert into public.rooms(name, description, is_public, created_by)
  values (left(v_name, 64), 'Percakapan pribadi', false, v_me)
  returning id into v_room;

  insert into public.room_members(room_id, user_id) values (v_room, v_me), (v_room, p_target_user);
  return v_room;
end;
$$;
revoke all on function public.start_direct_chat(uuid) from public;
grant execute on function public.start_direct_chat(uuid) to authenticated;

-- Percepat hitungan pesan belum dibaca (inbox) dan pemuatan riwayat.
create index if not exists chat_messages_room_sender_idx on public.chat_messages(room_id, sender_id);
do $$ begin
  if to_regclass('public.message_reads') is not null then
    create index if not exists message_reads_reader_msg_idx on public.message_reads(reader_id, message_id);
  end if;
end $$;

notify pgrst, 'reload schema';
