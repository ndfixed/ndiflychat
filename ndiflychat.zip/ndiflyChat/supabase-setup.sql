-- ndiflyChat setup for an existing project. Legacy public.users/conversations/messages remain untouched.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check (username = lower(username) and username ~ '^[a-z0-9_]{3,24}$'),
 display_name text not null default 'Pengguna' check (char_length(display_name) between 1 and 40),
 avatar_url text, created_at timestamptz not null default now()
);
create table if not exists public.rooms (
 id uuid primary key default gen_random_uuid(),
 name text not null check (char_length(name) between 3 and 40),
 description text not null default 'Ruang komunitas', is_public boolean not null default true,
 created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
-- Separate name avoids conflict with legacy public.messages(conversation_id, body).
create table if not exists public.chat_messages (
 id uuid primary key default gen_random_uuid(),
 room_id uuid not null references public.rooms(id) on delete cascade,
 sender_id uuid not null references public.profiles(id) on delete cascade,
 content text not null default '' check (char_length(content) <= 4000), image_url text,
 reply_to uuid references public.chat_messages(id) on delete set null, created_at timestamptz not null default now(),
 constraint chat_messages_need_content_or_image check (char_length(trim(content)) > 0 or image_url is not null)
);
create index if not exists chat_messages_room_created_idx on public.chat_messages(room_id, created_at);
create index if not exists profiles_username_idx on public.profiles(username);
insert into public.rooms(id,name,description,is_public) values ('00000000-0000-4000-8000-000000000001','Global Community','Ruang obrolan publik',true) on conflict (id) do nothing;

-- Explicit table grants: RLS still decides which rows each authenticated user may access.
grant usage on schema public to authenticated, service_role;
grant select, insert, update on table public.profiles to authenticated;
grant select, insert, update on table public.profiles to service_role;
grant select, insert, update on table public.rooms to authenticated;
grant select, insert, update, delete on table public.chat_messages to authenticated;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.chat_messages enable row level security;
drop policy if exists "profiles visible to signed-in users" on public.profiles;
create policy "profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "users create their own profile" on public.profiles;
create policy "users create their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "users update their own profile" on public.profiles;
create policy "users update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "signed-in users can view public rooms" on public.rooms;
create policy "signed-in users can view public rooms" on public.rooms for select to authenticated using (is_public = true);
drop policy if exists "signed-in users can create public rooms" on public.rooms;
create policy "signed-in users can create public rooms" on public.rooms for insert to authenticated with check (auth.uid() = created_by and is_public = true);
drop policy if exists "room creator can update room" on public.rooms;
create policy "room creator can update room" on public.rooms for update to authenticated using (auth.uid() = created_by) with check (auth.uid() = created_by);
drop policy if exists "signed-in users can read messages in public rooms" on public.chat_messages;
create policy "signed-in users can read messages in public rooms" on public.chat_messages for select to authenticated using (exists (select 1 from public.rooms r where r.id = room_id and r.is_public = true));
drop policy if exists "users send messages as themselves" on public.chat_messages;
create policy "users send messages as themselves" on public.chat_messages for insert to authenticated with check (auth.uid() = sender_id and exists (select 1 from public.rooms r where r.id = room_id and r.is_public = true));
drop policy if exists "users delete their own messages" on public.chat_messages;
create policy "users delete their own messages" on public.chat_messages for delete to authenticated using (auth.uid() = sender_id);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('chat-images','chat-images',true,5242880,array['image/png','image/jpeg','image/webp']) on conflict (id) do update set public=true,file_size_limit=5242880,allowed_mime_types=array['image/png','image/jpeg','image/webp'];
drop policy if exists "signed-in users upload images to own folder" on storage.objects;
create policy "signed-in users upload images to own folder" on storage.objects for insert to authenticated with check (bucket_id='chat-images' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "public can view chat images" on storage.objects;
create policy "public can view chat images" on storage.objects for select to public using (bucket_id='chat-images');
drop policy if exists "users delete their own chat images" on storage.objects;
create policy "users delete their own chat images" on storage.objects for delete to authenticated using (bucket_id='chat-images' and (storage.foldername(name))[1]=auth.uid()::text);
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='chat_messages') then alter publication supabase_realtime add table public.chat_messages; end if;
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='rooms') then alter publication supabase_realtime add table public.rooms; end if;
end $$;
