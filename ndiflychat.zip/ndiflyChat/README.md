# ndiflyChat — paket username-only

Paket ini memisahkan halaman landing, login, daftar, dan chat. Form meminta username + password saja. Tidak meminta email pribadi atau OTP.

## PENTING: yang perlu dilakukan sekali di Supabase

Saya tidak bisa mengubah/deploy ke project Supabase milik Anda dari ZIP ini. Agar aplikasi berjalan, lakukan langkah berikut:

1. **Database**: SQL setup `supabase-setup.sql` menyiapkan tabel `profiles`, `rooms`, `chat_messages`, bucket gambar, dan kebijakan akses. Karena database lama Anda punya `users`, `conversations`, `messages`, tabel lama tidak dihapus.
2. **Function**: deploy file `supabase/functions/username-register/index.ts` sebagai Edge Function bernama `username-register`.
3. **Secret**: di Edge Functions → Secrets, tambahkan `APP_SERVICE_ROLE_KEY` berisi secret/service-role key dari project yang sama. Jangan masukkan key ini ke HTML/JS atau kirim ke orang lain.
4. **URL/key publik**: cek `js/config.js`; `SUPABASE_URL` dan `SUPABASE_ANON_KEY` harus berasal dari project yang sama. Publishable/anon key boleh berada di frontend; service-role key tidak boleh.
5. **Function settings**: jika dashboard meminta pengaturan JWT, matikan `Verify JWT with legacy secret` untuk `username-register` agar pendaftaran tanpa sesi dapat memanggil function. Function tetap harus memvalidasi input dan melindungi endpoint dari spam sebelum dibuka ke publik.
6. Hosting melalui HTTPS atau jalankan dengan Live Server. Jangan buka HTML dengan `file://`.

## Cara kerja

Form daftar memanggil Edge Function. Function membuat akun Supabase Auth dengan identifier internal `username@ndiflychat.invalid` dan `email_confirm: true` melalui Admin API, tanpa mengirim email konfirmasi. Frontend lalu membuat sesi melalui `signInWithPassword` menggunakan identifier internal yang sama. Pengguna hanya mengetik username dan password.

Login memakai sesi Supabase Auth yang sama. Chat versi ini memakai tabel `profiles`, `rooms`, dan `chat_messages`; tabel lama `users`, `conversations`, dan `messages` dipertahankan.

## Catatan

- Jangan mengubah password hash manual pada tabel `users`; sistem ini memakai Supabase Auth untuk autentikasi.
- Jika SQL setup sudah sukses dijalankan, jangan perlu menjalankannya berulang kali kecuali ada error spesifik.
- ZIP tidak dapat mengonfigurasi atau menguji project Supabase live secara otomatis. Setelah deploy, tes daftar dengan username baru dan kemudian logout/login.
- Tambahkan rate limit/CAPTCHA dan kebijakan abuse sebelum aplikasi dibuka untuk umum.

## Pencarian kontak dan panggilan
Pencarian username memakai tabel `profiles`; membuka DM memerlukan `private-chat-setup.sql`. Panggilan suara/video diaktifkan untuk Global Community dengan WebRTC dan Supabase Realtime private Broadcast. Ikuti bagian **Panggilan Global Community** di bawah, aktifkan HTTPS dan izin mikrofon/kamera, serta siapkan TURN bila jaringan pengguna membutuhkannya.
## Panggilan Global Community
Panggilan suara/video memakai Supabase Realtime private Broadcast channel `ndifly-global-call` untuk signaling dan WebRTC untuk media. Setelah setup utama, jalankan `global-call-setup.sql` sekali di Supabase SQL Editor. Policy membatasi signaling ke topik `ndifly-global-call` dan extension Broadcast untuk pengguna terautentikasi. Tidak perlu tabel signaling tambahan. Semua peserta harus membuka halaman chat, memakai HTTPS, mengizinkan mikrofon/kamera, dan menggunakan browser yang mendukung WebRTC. Koneksi lintas jaringan tertentu mungkin memerlukan TURN server; STUN saja tidak menjamin semua jaringan. Panggilan grup mesh memakai bandwidth lebih besar saat peserta bertambah. Tombol panggilan bekerja di Global Community; panggilan tidak aktif untuk DM.


## PRO UI & Read Receipts
Versi ini memperkaya layout halaman chat dan menambah status baca. Setelah setup utama serta `private-chat-setup.sql`, jalankan `read-receipts-setup.sql` sekali di Supabase SQL Editor. Pengguna menandai pesan masuk sebagai dibaca ketika membuka ruang; pengirim dapat menekan status di bawah pesannya untuk melihat nama akun dan waktu baca. RLS membatasi daftar pembaca agar hanya pengirim pesan yang bisa melihat pembaca pesan tersebut.

Jika tabel `message_reads` belum dibuat atau SQL belum berhasil, chat tetap terbuka tetapi status baca tidak aktif sampai SQL dijalankan.


## Pembaruan ndiflyChat Pro Style
- CSS diperkaya untuk seluruh halaman chat, landing, masuk, dan daftar dengan lapisan glass, latar bertekstur halus, border kontras lembut, hierarki visual lebih jelas, bubble pesan, panel informasi, status pembaca, komposer, dan dockbar iOS-inspired.
- Layout responsif disetel ulang untuk ponsel kecil, ponsel besar, tablet, dan desktop. Dockbar diberi ruang agar tidak menutupi kolom tulis pesan pada layar ponsel.
- Tampilan nama mengutamakan username kanonis dari tabel `profiles` daripada `display_name`; contoh username yang digunakan pada preview landing adalah `andif_dev`. Nilai username aktual tetap mengikuti akun di database.
- Seluruh file JavaScript diperiksa dengan `node --check`. Setelah perubahan fitur, referensi aset HTML menggunakan versi cache-buster `v=20261018-bugfix5`. Perubahan visual dan alur yang memerlukan database tetap harus diuji dengan akun pada deployment Vercel dan project Supabase milikmu.


## Halaman Informasi & perbaikan startup

- Halaman baru `informasi.html` menjelaskan ndiflyChat, arah produk, fitur, prinsip privasi, dan pengembang independen **4ndifly**.
- Tombol Informasi pada dock bawah dari halaman chat membuka halaman `informasi.html`.
- Tombol Chat membawa pengguna kembali ke `chat.html`. Tombol Settings membuka chat dan mengaktifkan toggle tema.
- Memperbaiki crash startup: `welcome-banner` sekarang punya ID yang digunakan `js/chat.js`; referensinya juga memakai optional chaining agar elemen tidak ditemukan tidak langsung mematikan startup.
- Tidak ada SQL tambahan yang dibutuhkan hanya untuk perbaikan UI ini.


## Perbaikan console dan halaman Settings

- Menambahkan deklarasi `messageReadObserver` dan `readMessagesHandled` yang dipakai fitur status baca. Sebelumnya variabel tersebut belum dideklarasikan sehingga memicu `ReferenceError: messageReadObserver is not defined` ketika pesan dirender.
- Menu Settings sekarang membuka halaman khusus `settings.html`. Klik dock Settings tidak lagi otomatis mengubah tema.
- Halaman Settings menyediakan pilihan Gelap/Terang yang hanya berubah ketika tombol tema dipilih, lalu menyimpan pilihan di `localStorage` sebagai `ndifly_theme`.
- Halaman Informasi dan Settings memakai dockbar yang sama.
- Tidak perlu SQL baru untuk perbaikan ini.


## Audit & final stability fixes
- Fixed `messageReadObserver is not defined` and the related read-message tracking set declaration.
- Reinitialize the intersection observer when switching rooms, preventing stale DOM observation.
- The Settings dock now navigates to `settings.html`; it no longer toggles theme merely because the route is opened. `informasi.html` also links to the dedicated settings page.
- Searching usernames preserves underscores (e.g. `andif_dev`).
- The private-chat RPC now shows an actionable message when `start_direct_chat(uuid)` is absent from PostgREST schema cache.
- `supabase-setup.sql` and `private-chat-setup.sql` now include explicit SQL grants while leaving RLS policies enabled.
- If you already ran the setup files, `repair-permissions.sql` provides the additional grants and schema reload. Run only after the corresponding tables exist.
- Static JavaScript syntax and HTML-to-JS ID checks have been performed. Live behavior still requires deployment and an authenticated two-account test against your own Supabase project.

- The unused legacy `js/script.js` no longer initializes another Supabase client; current HTML pages use their page-specific script files.
- HTML assets have version query strings to help mobile browsers avoid stale cached JavaScript after redeployment.


## Bagian "Didukung oleh"

- Menambahkan bagian **Didukung oleh** pada landing page dan halaman Informasi.
- Menampilkan logo Vercel dan Supabase menggunakan gambar yang disediakan, dengan keterangan fungsi layanan.
- Kartu logo membuka situs resmi penyedia di tab baru.
- Menambahkan disclaimer bahwa logo menjelaskan teknologi yang digunakan dan bukan pernyataan kemitraan resmi.
- Asset logo berada di `assets/vercel-supported.jpg` dan `assets/supabase-supported.jpg`.


## Branding & logout dialog polish

- Logo Vercel dan Supabase pada halaman Informasi menggunakan `object-fit: contain` agar seluruh wordmark tampil utuh, dengan wrapper dan ukuran responsif yang diperbarui.
- Dockbar memakai highlight berbentuk lingkaran/oval pada ikon aktif. Latar belakang item tetap transparan untuk menghindari sorotan persegi saat ditekan di browser mobile.
- Tombol keluar memakai modal ndiflyChat bergaya glass, menampilkan username aktif, opsi tetap masuk/keluar, tombol tutup, dukungan tombol Escape, dan keadaan loading saat proses sign-out. Dialog `confirm()` browser tidak lagi digunakan untuk logout.
- Copy bagian “Didukung oleh” menjelaskan fungsi infrastruktur Vercel dan Supabase serta peran konfigurasi aplikasi/database terhadap keamanan. Tidak membuat klaim keamanan mutlak.
- Tidak ada SQL tambahan untuk perubahan ini.


## Final UI repair pack

- Menyelaraskan markup, CSS, dan JS dalam satu paket. Semua referensi aset lokal pada HTML diberi cache-buster `v=20261018-bugfix5` supaya browser tidak memakai file lama.
- Efek tap native biru berbentuk persegi dinonaktifkan. Dockbar menggunakan lingkaran pada ikon aktif, transparansi pada item, serta animasi tekan berbentuk bulat.
- Menambah ruang bawah nyata pada sidebar dan panel chat pada layar mobile/desktop agar footer/composer tidak tertimpa dock tetap.
- Logo Vercel dan Supabase memakai `object-fit: contain` dengan ukuran responsif agar seluruh wordmark tetap terlihat di landing page dan informasi.
- Copy “Didukung oleh” menjelaskan peran Vercel/Supabase untuk hosting, autentikasi, backend, dan data secara profesional tanpa menjanjikan keamanan mutlak.
- Mengganti dialog browser `confirm()` dengan modal custom ndiflyChat untuk logout dan hapus pesan; pencarian kode tidak lagi menemukan penggunaan `confirm()` atau `alert()` native.
- Halaman Informasi dan Settings tetap tersedia dan dockbar berfungsi sebagai navigasi antarhalaman.
- Tidak perlu SQL baru untuk perubahan UI ini.
- Tetap deploy seluruh folder project dari ZIP ini; mengganti CSS saja tidak cukup untuk mendapatkan modal, cache bust, dan layout yang cocok.


## Perbaikan fungsional & audit terbaru
- Menyambungkan pencarian username di sidebar ke tabel `profiles`, lalu membuka/membuat DM melalui RPC `start_direct_chat`. Fitur memerlukan `private-chat-setup.sql`.
- Menyambungkan pencarian pesan, toggle bar pencarian, panel informasi, tombol kembali mobile, serta penutupan modal lewat Escape.
- Memuat 100 pesan terbaru (lalu menampilkannya urut lama-ke-baru), menambahkan perlindungan agar respons saat pindah ruang cepat tidak menimpa ruang yang sedang aktif, dan mencegah status baca ditandai untuk semua pesan hanya karena ruang dibuka.
- Memvalidasi unggahan hanya PNG/JPG/WEBP maksimal 5 MB serta membersihkan file gambar jika pengiriman pesan gagal.
- Menambahkan signaling panggilan suara/video di Global Community menggunakan WebRTC + Realtime private channel, termasuk mute, kamera, join, leave, dan end-call. Jalankan `global-call-setup.sql` agar RLS kanal private diaktifkan. Kualitas koneksi masih bergantung pada izin perangkat, konfigurasi Realtime, HTTPS, dan kebutuhan TURN di jaringan tertentu.
- Memperbaiki logout saat panggilan aktif agar media lokal dihentikan dan signaling dibersihkan; preferensi tema tetap berfungsi ketika akses `localStorage` dibatasi.
- Catatan verifikasi: pemeriksaan sintaks statis, ID HTML, dan referensi aset lokal dilakukan pada paket ini. Uji live end-to-end tetap membutuhkan project Supabase aktif dan dua akun nyata; kredensial service-role tidak disertakan di ZIP.


## Inbox WhatsApp-style dan unread count
Jalankan `room-inbox-setup.sql` satu kali di Supabase SQL Editor setelah setup tabel private chat dan read receipts. Script ini menambahkan RPC untuk mengambil preview pesan terakhir dan jumlah unread secara presisi. Tanpa RPC, UI memakai fallback client-side pada pesan terbaru yang dapat diakses. Foto dikompres otomatis menjadi WebP sebelum upload.


## Badge pesan belum dibaca
Badge angka biru ala WhatsApp sudah ditambahkan pada daftar percakapan. Hitungan unread menggunakan `message_reads` dan RPC `get_room_inbox_summaries`; jalankan `read-receipts-setup.sql` dan `room-inbox-setup.sql` di Supabase SQL Editor bila belum diterapkan.
