# ndiflyChat — Craft visual update

## Direction
A unified product interface with editorial restraint: ink/navy surfaces for dark mode, paper-white surfaces for light mode, cobalt as the primary action color, precise borders, intentional whitespace, and a clearer type hierarchy. Decorative blur, glowing gradients, and repeated pill shapes are reduced in favor of useful structure and readable conversation details.

## Pages covered
- Landing page
- Login and registration
- Main chat workspace, inbox rows, message metadata, reply preview, composer, room details, dock, and dialogs
- Settings and theme selection
- Product information/about page

## Theme behavior
`js/theme.js` reads the saved `ndifly_theme` preference before styles render, so the saved theme is consistent across all pages. The chat and settings controls continue to write the same preference. The browser theme-color metadata is synchronized for dark and light modes.

## Reference principles
The Jagoan Hosting website was used as a high-level reference for content hierarchy, clear calls to action, grouped product information, and whitespace—not copied as a page layout or branding system. Reference: https://www.jagoanhosting.com/

## Changed files
- Added `css/craft.css` as the unified visual layer, loaded after core and page-specific stylesheets on all six pages. The old `luxe.css` override file was removed from the package, preventing its high-specificity theme rules from fighting the redesign.
- Added `js/theme.js` to apply the saved theme consistently across pages.
- Updated `js/chat.js` so the browser theme-color matches the selected theme.
- Updated stylesheet links and theme-color metadata in all HTML pages.
