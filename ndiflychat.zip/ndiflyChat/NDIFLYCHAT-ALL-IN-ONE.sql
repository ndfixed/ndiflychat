-- NDIFLYCHAT — ALL-IN-ONE DATABASE SETUP (repair + fitur Status)
-- Jalankan SELURUH file ini sekali di Supabase → SQL Editor → New query → Run.
-- Aman dijalankan ulang. Melengkapi: kolom profiles.bio & last_seen, fungsi inbox,
-- kolom pesan image_path/audio_path, izin panggilan Realtime, dan tabel user_status.
-- Setelah sukses, buka Database → Replication/Realtime dan pastikan Realtime aktif, lalu muat ulang aplikasi.

-- NDIFLYCHAT — DATABASE REPAIR & FULL SETUP
-- Jalankan seluruh file ini sekali di Supabase SQL Editor.
-- Aman dijalankan ulang untuk skema yang dikelola paket ini; data akun/pesan lama
-- tidak dihapus. Urutan migrasi disatukan agar kolom/tabel dibuat lebih dulu.
-- Setelah SQL berhasil: deploy Edge Functions username-register + status-cleanup,
-- set STATUS_CLEANUP_SECRET, lalu pasang Cron berdasarkan STATUS-SETUP.md.
-- Catatan: URL media lama masih dilayani bucket publik lama untuk kompatibilitas;
-- upload foto/VN baru menggunakan bucket chat-media yang private.


------------------------------------------------------------------------------
-- 01 · Tabel inti, ruang, pesan global dan Storage [supabase-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat setup for an existing project. Legacy public.users/conversations/messages remain untouched.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique check (username = lower(username) and username ~ '^[a-z0-9_]{3,24}$'),
 display_name text not null default 'Pengguna' check (char_length(display_name) between 1 and 40),
 avatar_url text, created_at timestamptz not null default now()
);
create table if not exists public.rooms (
 id uuid primary key default gen_random_uuid(),
 name text not null check (char_length(name) between 3 and 40),
 description text not null default 'Ruang komunitas', is_public boolean not null default true,
 created_by uuid references auth.users(id) on delete set null, created_at timestamptz not null default now()
);
-- Separate name avoids conflict with legacy public.messages(conversation_id, body).
create table if not exists public.chat_messages (
 id uuid primary key default gen_random_uuid(),
 room_id uuid not null references public.rooms(id) on delete cascade,
 sender_id uuid not null references public.profiles(id) on delete cascade,
 content text not null default '' check (char_length(content) <= 4000), image_url text,
 reply_to uuid references public.chat_messages(id) on delete set null, created_at timestamptz not null default now(),
 constraint chat_messages_need_content_or_image check (char_length(trim(content)) > 0 or image_url is not null)
);
create index if not exists chat_messages_room_created_idx on public.chat_messages(room_id, created_at);
create index if not exists profiles_username_idx on public.profiles(username);
insert into public.rooms(id,name,description,is_public) values ('00000000-0000-4000-8000-000000000001','Global Community','Ruang obrolan publik',true) on conflict (id) do nothing;

-- Explicit table grants: RLS still decides which rows each authenticated user may access.
grant usage on schema public to authenticated, service_role;
grant select, insert, update on table public.profiles to authenticated;
grant select, insert, update on table public.profiles to service_role;
grant select, insert, update on table public.rooms to authenticated;
grant select, insert, update, delete on table public.chat_messages to authenticated;

alter table public.profiles enable row level security;
alter table public.rooms enable row level security;
alter table public.chat_messages enable row level security;
drop policy if exists "profiles visible to signed-in users" on public.profiles;
create policy "profiles visible to signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "users create their own profile" on public.profiles;
create policy "users create their own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "users update their own profile" on public.profiles;
create policy "users update their own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "signed-in users can view public rooms" on public.rooms;
create policy "signed-in users can view public rooms" on public.rooms for select to authenticated using (is_public = true);
drop policy if exists "signed-in users can create public rooms" on public.rooms;
create policy "signed-in users can create public rooms" on public.rooms for insert to authenticated with check (auth.uid() = created_by and is_public = true);
drop policy if exists "room creator can update room" on public.rooms;
create policy "room creator can update room" on public.rooms for update to authenticated using (auth.uid() = created_by) with check (auth.uid() = created_by);
drop policy if exists "signed-in users can read messages in public rooms" on public.chat_messages;
create policy "signed-in users can read messages in public rooms" on public.chat_messages for select to authenticated using (exists (select 1 from public.rooms r where r.id = room_id and r.is_public = true));
drop policy if exists "users send messages as themselves" on public.chat_messages;
create policy "users send messages as themselves" on public.chat_messages for insert to authenticated with check (auth.uid() = sender_id and exists (select 1 from public.rooms r where r.id = room_id and r.is_public = true));
drop policy if exists "users delete their own messages" on public.chat_messages;
create policy "users delete their own messages" on public.chat_messages for delete to authenticated using (auth.uid() = sender_id);

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types) values ('chat-images','chat-images',true,5242880,array['image/png','image/jpeg','image/webp']) on conflict (id) do update set public=true,file_size_limit=5242880,allowed_mime_types=array['image/png','image/jpeg','image/webp'];
drop policy if exists "signed-in users upload images to own folder" on storage.objects;
create policy "signed-in users upload images to own folder" on storage.objects for insert to authenticated with check (bucket_id='chat-images' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "public can view chat images" on storage.objects;
create policy "public can view chat images" on storage.objects for select to public using (bucket_id='chat-images');
drop policy if exists "users delete their own chat images" on storage.objects;
create policy "users delete their own chat images" on storage.objects for delete to authenticated using (bucket_id='chat-images' and (storage.foldername(name))[1]=auth.uid()::text);
do $$ begin
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='chat_messages') then alter publication supabase_realtime add table public.chat_messages; end if;
 if not exists(select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='rooms') then alter publication supabase_realtime add table public.rooms; end if;
end $$;


------------------------------------------------------------------------------
-- 02 · Profil, bio dan last-seen [profile-presence-setup.sql]
------------------------------------------------------------------------------
-- Tambahan bio dan status online/terakhir dilihat untuk ndiflyChat
alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists last_seen timestamptz;
update public.profiles set bio = '' where bio is null;
create index if not exists profiles_last_seen_idx on public.profiles(last_seen desc);
-- RLS profiles yang sudah ada tetap berlaku: semua pengguna terautentikasi dapat membaca profil,
-- sedangkan pengguna hanya dapat memperbarui profil miliknya sendiri.


------------------------------------------------------------------------------
-- 03 · Chat pribadi dan kebijakan akses ruang [private-chat-setup.sql]
------------------------------------------------------------------------------
-- Jalankan sekali di Supabase SQL Editor untuk mengaktifkan chat pribadi.
-- Tetap mempertahankan Global Community dan pesan publik yang sudah ada.

-- DM room names ("DM - @a / @b") can be up to 58 chars; the original limit of 40 truncated long usernames.
alter table public.rooms drop constraint if exists rooms_name_check;
alter table public.rooms add constraint rooms_name_check check (char_length(name) between 3 and 64);

create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create index if not exists room_members_user_room_idx
  on public.room_members(user_id, room_id);

alter table public.room_members enable row level security;
grant usage on schema public to authenticated, service_role;
grant select, insert, update on public.profiles to service_role;
grant select, insert, update on public.profiles to authenticated;
grant select on public.room_members to authenticated;
grant select, insert, update on public.rooms to authenticated;
grant select, insert, delete on public.chat_messages to authenticated;

-- Anggota hanya dapat melihat keanggotaan ruang yang mereka ikuti.
drop policy if exists "members can view own room memberships" on public.room_members;
create policy "members can view own room memberships"
on public.room_members for select to authenticated
using (user_id = auth.uid());

-- Daftar room: ruang publik atau room privat tempat user menjadi anggota.
drop policy if exists "signed-in users can view public rooms" on public.rooms;
drop policy if exists "members can view their private rooms" on public.rooms;
create policy "members can view their private rooms"
on public.rooms for select to authenticated
using (
  is_public = true OR exists (
    select 1 from public.room_members rm
    where rm.room_id = rooms.id and rm.user_id = auth.uid()
  )
);

-- Chat message hanya boleh dibaca/dikirim pada ruang publik atau ruang privat anggota.
drop policy if exists "signed-in users can read messages in public rooms" on public.chat_messages;
drop policy if exists "members can read room messages" on public.chat_messages;
create policy "members can read room messages"
on public.chat_messages for select to authenticated
using (
  exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
  OR exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
);

drop policy if exists "users send messages as themselves" on public.chat_messages;
drop policy if exists "members can send room messages" on public.chat_messages;
create policy "members can send room messages"
on public.chat_messages for insert to authenticated
with check (
  auth.uid() = sender_id AND (
    exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
    OR exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
  )
);

-- Membuat atau membuka kembali DM yang sama. SECURITY DEFINER diperlukan agar
-- dua anggota bisa ditambahkan secara atomik tanpa membuka insert room_members ke client.
create or replace function public.start_direct_chat(p_target_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_me uuid := auth.uid();
  v_room uuid;
  v_name text;
  v_target_username text;
  v_my_username text;
begin
  if v_me is null then
    raise exception 'Login diperlukan';
  end if;
  if p_target_user is null or p_target_user = v_me then
    raise exception 'Pilih pengguna lain';
  end if;

  select username into v_target_username from public.profiles where id = p_target_user;
  if v_target_username is null then
    raise exception 'Pengguna tidak ditemukan';
  end if;
  select username into v_my_username from public.profiles where id = v_me;

  -- Serialise concurrent requests for the same pair so double-taps cannot create two DM rooms.
  perform pg_advisory_xact_lock(hashtextextended(least(v_me::text, p_target_user::text) || ':' || greatest(v_me::text, p_target_user::text), 0));

  -- Cari room DM yang sudah berisi tepat dua pengguna ini.
  select rm1.room_id into v_room
  from public.room_members rm1
  join public.room_members rm2 on rm2.room_id = rm1.room_id
  join public.rooms r on r.id = rm1.room_id and r.is_public = false
  where rm1.user_id = v_me and rm2.user_id = p_target_user
    and (select count(*) from public.room_members allm where allm.room_id = rm1.room_id) = 2
  limit 1;

  if v_room is not null then
    return v_room;
  end if;

  v_name := 'DM - @' || coalesce(v_my_username, 'user') || ' / @' || v_target_username;
  insert into public.rooms(name, description, is_public, created_by)
  values (left(v_name, 64), 'Percakapan pribadi', false, v_me)
  returning id into v_room;

  insert into public.room_members(room_id, user_id)
  values (v_room, v_me), (v_room, p_target_user);

  return v_room;
end;
$$;

revoke all on function public.start_direct_chat(uuid) from public;
grant execute on function public.start_direct_chat(uuid) to authenticated;

-- Realtime untuk pesan baru sudah dipakai oleh chat.js; pastikan tabel tercantum.
do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='chat_messages'
  ) then
    alter publication supabase_realtime add table public.chat_messages;
  end if;
end $$;


-- Status baca pesan. Untuk project existing, file read-receipts-setup.sql juga dapat dijalankan terpisah.
-- ndiflyChat: status baca pesan (jalankan setelah supabase-setup.sql dan private-chat-setup.sql)
create table if not exists public.message_reads (
  message_id uuid not null references public.chat_messages(id) on delete cascade,
  reader_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, reader_id)
);
create index if not exists message_reads_reader_idx on public.message_reads(reader_id, message_id);
create index if not exists message_reads_message_idx on public.message_reads(message_id, read_at desc);

alter table public.message_reads enable row level security;
grant usage on schema public to authenticated, service_role;
grant select, insert, update on public.profiles to service_role;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.message_reads to authenticated;

drop policy if exists "users can view own read receipts and receipts for own messages" on public.message_reads;
create policy "users can view own read receipts and receipts for own messages"
on public.message_reads for select to authenticated
using (
  reader_id = auth.uid()
  or exists (
    select 1 from public.chat_messages m
    where m.id = message_reads.message_id and m.sender_id = auth.uid()
  )
);

drop policy if exists "users can mark accessible messages as read" on public.message_reads;
create policy "users can mark accessible messages as read"
on public.message_reads for insert to authenticated
with check (
  reader_id = auth.uid()
  and exists (
    select 1
    from public.chat_messages m
    join public.rooms r on r.id = m.room_id
    where m.id = message_reads.message_id
      and m.sender_id <> auth.uid()
      and (
        r.is_public = true
        or exists (
          select 1 from public.room_members rm
          where rm.room_id = r.id and rm.user_id = auth.uid()
        )
      )
  )
);

do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'message_reads'
  ) then
    alter publication supabase_realtime add table public.message_reads;
  end if;
end $$;
notify pgrst, 'reload schema';


------------------------------------------------------------------------------
-- 04 · Voice note dan kolom audio legacy [vn-feature-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat Voice Note setup
-- Run once in Supabase SQL Editor.
alter table public.chat_messages add column if not exists audio_url text;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_or_image;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_image_or_audio;
alter table public.chat_messages add constraint chat_messages_need_content_image_or_audio
  check (char_length(trim(coalesce(content,''))) > 0 or image_url is not null or audio_url is not null);

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat-voice', 'chat-voice', true, 15728640,
  array['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav'])
on conflict (id) do update set public=true, file_size_limit=15728640,
  allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "authenticated users upload voice notes" on storage.objects;
create policy "authenticated users upload voice notes" on storage.objects
for insert to authenticated with check (bucket_id='chat-voice' and (storage.foldername(name))[1]=auth.uid()::text);

drop policy if exists "authenticated users read voice notes" on storage.objects;
create policy "authenticated users read voice notes" on storage.objects
for select to authenticated using (bucket_id='chat-voice');

drop policy if exists "owners delete voice notes" on storage.objects;
create policy "owners delete voice notes" on storage.objects
for delete to authenticated using (bucket_id='chat-voice' and (storage.foldername(name))[1]=auth.uid()::text);


------------------------------------------------------------------------------
-- 05 · Media pesan baru menggunakan bucket privat [private-media-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat private message media.
-- New chat images and voice notes are stored in a PRIVATE bucket and signed only
-- for users who can read the corresponding message/room. Existing public URLs
-- in image_url/audio_url are retained for backward compatibility.

alter table public.chat_messages add column if not exists image_path text;
alter table public.chat_messages add column if not exists audio_path text;

-- Make the media constraint safe to execute repeatedly and support both legacy URLs
-- and the new private Storage object paths.
alter table public.chat_messages drop constraint if exists chat_messages_need_content_or_image;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_image_or_audio;
alter table public.chat_messages drop constraint if exists chat_messages_need_content_media;
alter table public.chat_messages add constraint chat_messages_need_content_media
 check (
   char_length(trim(coalesce(content,''))) > 0
   or image_url is not null or image_path is not null
   or audio_url is not null or audio_path is not null
 );

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values (
 'chat-media','chat-media',false,20971520,
 array['image/png','image/jpeg','image/webp','audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav']
)
on conflict (id) do update set
 public=false,
 file_size_limit=20971520,
 allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "chat media upload own" on storage.objects;
create policy "chat media upload own"
on storage.objects for insert to authenticated
with check (
 bucket_id='chat-media'
 and (storage.foldername(name))[1]=(select auth.uid())::text
);

drop policy if exists "chat media read through message access" on storage.objects;
create policy "chat media read through message access"
on storage.objects for select to authenticated
using (
 bucket_id='chat-media'
 and exists (
   select 1
   from public.chat_messages m
   where m.image_path=storage.objects.name
      or m.audio_path=storage.objects.name
 )
);

drop policy if exists "chat media delete own" on storage.objects;
create policy "chat media delete own"
on storage.objects for delete to authenticated
using (
 bucket_id='chat-media'
 and (storage.foldername(name))[1]=(select auth.uid())::text
);


------------------------------------------------------------------------------
-- 06 · Read receipts [read-receipts-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat: status baca pesan (jalankan setelah supabase-setup.sql dan private-chat-setup.sql)
create table if not exists public.message_reads (
  message_id uuid not null references public.chat_messages(id) on delete cascade,
  reader_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, reader_id)
);
create index if not exists message_reads_reader_idx on public.message_reads(reader_id, message_id);
create index if not exists message_reads_message_idx on public.message_reads(message_id, read_at desc);

alter table public.message_reads enable row level security;
grant usage on schema public to authenticated;
grant select, insert on public.message_reads to authenticated;

drop policy if exists "users can view own read receipts and receipts for own messages" on public.message_reads;
create policy "users can view own read receipts and receipts for own messages"
on public.message_reads for select to authenticated
using (
  reader_id = auth.uid()
  or exists (
    select 1 from public.chat_messages m
    where m.id = message_reads.message_id and m.sender_id = auth.uid()
  )
);

drop policy if exists "users can mark accessible messages as read" on public.message_reads;
create policy "users can mark accessible messages as read"
on public.message_reads for insert to authenticated
with check (
  reader_id = auth.uid()
  and exists (
    select 1
    from public.chat_messages m
    join public.rooms r on r.id = m.room_id
    where m.id = message_reads.message_id
      and m.sender_id <> auth.uid()
      and (
        r.is_public = true
        or exists (
          select 1 from public.room_members rm
          where rm.room_id = r.id and rm.user_id = auth.uid()
        )
      )
  )
);

do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'message_reads'
  ) then
    alter publication supabase_realtime add table public.message_reads;
  end if;
end $$;
notify pgrst, 'reload schema';


------------------------------------------------------------------------------
-- 07 · Inbox, unread count dan preview media [room-inbox-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat inbox: pesan terakhir dan jumlah pesan belum dibaca per room.
-- Jalankan sekali di Supabase SQL Editor setelah supabase-setup.sql, private-chat-setup.sql, dan read-receipts-setup.sql.

create index if not exists chat_messages_room_created_idx
  on public.chat_messages(room_id, created_at desc);

-- Output function diperluas; DROP diperlukan karena PostgreSQL tidak mengizinkan
-- CREATE OR REPLACE mengubah tipe/kolom hasil RETURNS TABLE yang sudah ada.
drop function if exists public.get_room_inbox_summaries();

create or replace function public.get_room_inbox_summaries()
returns table (
  room_id uuid,
  latest_message_id uuid,
  latest_sender_id uuid,
  latest_content text,
  latest_image_url text,
  latest_audio_url text,
  latest_image_path text,
  latest_audio_path text,
  latest_reply_to uuid,
  latest_created_at timestamptz,
  latest_sender_username text,
  latest_sender_display_name text,
  latest_sender_avatar_url text,
  unread_count bigint
)
language sql
stable
security invoker
set search_path = public
as $$
  select
    r.id as room_id,
    latest.id as latest_message_id,
    latest.sender_id as latest_sender_id,
    latest.content as latest_content,
    latest.image_url as latest_image_url,
    latest.audio_url as latest_audio_url,
    latest.image_path as latest_image_path,
    latest.audio_path as latest_audio_path,
    latest.reply_to as latest_reply_to,
    latest.created_at as latest_created_at,
    latest_profile.username as latest_sender_username,
    latest_profile.display_name as latest_sender_display_name,
    latest_profile.avatar_url as latest_sender_avatar_url,
    count(m.id) filter (where m.sender_id <> auth.uid() and mr.message_id is null)::bigint as unread_count
  from public.rooms r
  left join lateral (
    select cm.id, cm.sender_id, cm.content, cm.image_url, cm.audio_url, cm.image_path, cm.audio_path, cm.reply_to, cm.created_at
    from public.chat_messages cm
    where cm.room_id = r.id
    order by cm.created_at desc
    limit 1
  ) latest on true
  left join public.profiles latest_profile on latest_profile.id = latest.sender_id
  left join public.chat_messages m on m.room_id = r.id and m.sender_id <> auth.uid()
  left join public.message_reads mr on mr.message_id = m.id and mr.reader_id = auth.uid()
  where auth.uid() is not null
    and (r.is_public = true or exists (
      select 1 from public.room_members rm
      where rm.room_id = r.id and rm.user_id = auth.uid()
    ))
  group by r.id, latest.id, latest.sender_id, latest.content, latest.image_url, latest.audio_url, latest.image_path, latest.audio_path, latest.reply_to, latest.created_at, latest_profile.username, latest_profile.display_name, latest_profile.avatar_url, r.created_at
  order by coalesce(latest.created_at, r.created_at) desc;
$$;

revoke all on function public.get_room_inbox_summaries() from public;
grant execute on function public.get_room_inbox_summaries() to authenticated;
notify pgrst, 'reload schema';


------------------------------------------------------------------------------
-- 08 · Izin Realtime untuk panggilan privat [calls-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat — izin Realtime untuk PANGGILAN (suara/video) di chat pribadi dan Global.
-- Jalankan SEKALI di Supabase SQL Editor. Aman dijalankan ulang.
--
-- Topik channel: 'call:<id ruang>'. Dipakai untuk (1) sinyal WebRTC & dering lewat Broadcast,
-- (2) daftar peserta lewat Presence. Hanya anggota ruang yang boleh menerima/mengirim;
-- ruang publik (Global Community) terbuka untuk semua pengguna yang sudah login.

drop policy if exists "ndiflyChat call receive" on realtime.messages;
create policy "ndiflyChat call receive"
on realtime.messages for select to authenticated
using (
  realtime.messages.extension in ('broadcast', 'presence')
  and (select realtime.topic()) like 'call:%'
  and exists (
    select 1 from public.rooms r
    where ('call:' || r.id::text) = (select realtime.topic())
      and (
        r.is_public = true
        or exists (select 1 from public.room_members rm where rm.room_id = r.id and rm.user_id = (select auth.uid()))
      )
  )
);

drop policy if exists "ndiflyChat call send" on realtime.messages;
create policy "ndiflyChat call send"
on realtime.messages for insert to authenticated
with check (
  realtime.messages.extension in ('broadcast', 'presence')
  and (select realtime.topic()) like 'call:%'
  and exists (
    select 1 from public.rooms r
    where ('call:' || r.id::text) = (select realtime.topic())
      and (
        r.is_public = true
        or exists (select 1 from public.room_members rm where rm.room_id = r.id and rm.user_id = (select auth.uid()))
      )
  )
);


------------------------------------------------------------------------------
-- 09 · Status 24 jam dengan bucket privat [status-feature-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat Status: aktif maksimal 24 jam, batas 2 MB, cleanup melalui Supabase Storage API.
-- Jalankan di Supabase SQL Editor. Tidak menghapus storage.objects secara langsung;
-- penghapusan database langsung dapat meninggalkan file fisik di object storage.

create table if not exists public.user_status (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 media_path text not null unique,
 media_type text not null check (media_type in ('image','video')),
 caption text not null default '' check (char_length(caption) <= 180),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours'),
 constraint status_expiry_window check (expires_at <= created_at + interval '24 hours' and expires_at > created_at)
);
create index if not exists user_status_active_idx on public.user_status(expires_at desc, created_at desc);

-- Waktu status ditetapkan server agar klien tidak dapat memperpanjang masa aktif
-- dengan mengirim created_at / expires_at palsu.
create or replace function public.set_user_status_timestamps()
returns trigger
language plpgsql
set search_path = public
as $$
begin
 new.created_at := now();
 new.expires_at := new.created_at + interval '24 hours';
 return new;
end;
$$;
drop trigger if exists user_status_force_24h on public.user_status;
create trigger user_status_force_24h
before insert on public.user_status
for each row execute function public.set_user_status_timestamps();
revoke all on function public.set_user_status_timestamps() from public, anon, authenticated;
alter table public.user_status enable row level security;
grant select, insert, delete on public.user_status to authenticated;
drop policy if exists "status read active" on public.user_status;
create policy "status read active" on public.user_status for select to authenticated using (expires_at > now());
drop policy if exists "status insert own" on public.user_status;
create policy "status insert own" on public.user_status for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "status delete own" on public.user_status;
create policy "status delete own" on public.user_status for delete to authenticated using (user_id = auth.uid());

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-status','chat-status',false,2097152,array['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
on conflict (id) do update set public=false,file_size_limit=2097152,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "status media read" on storage.objects;
drop policy if exists "status media read active" on storage.objects;
create policy "status media read active" on storage.objects for select to authenticated using (
 bucket_id='chat-status' and exists (
  select 1 from public.user_status s
  where s.media_path=storage.objects.name and s.expires_at > now()
 )
);
drop policy if exists "status media upload own" on storage.objects;
create policy "status media upload own" on storage.objects for insert to authenticated with check (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "status media delete own" on storage.objects;
create policy "status media delete own" on storage.objects for delete to authenticated using (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);

-- Cleanup job calls the status-cleanup Edge Function every minute.
-- The Edge Function removes files through Storage API first, then deletes database records.


------------------------------------------------------------------------------
-- 10 · Izin database dan reload PostgREST [repair-permissions.sql]
------------------------------------------------------------------------------
-- ndiflyChat permission repair: run in Supabase SQL Editor after setup.
-- Grants SQL privileges only; existing Row Level Security policies remain enabled.
grant usage on schema public to authenticated, service_role;
do $$ begin
  if to_regclass('public.profiles') is not null then
    execute 'grant select, insert, update on table public.profiles to authenticated';
    execute 'grant select, insert, update on table public.profiles to service_role';
  end if;
  if to_regclass('public.rooms') is not null then
    execute 'grant select, insert, update on table public.rooms to authenticated';
  end if;
  if to_regclass('public.chat_messages') is not null then
    execute 'grant select, insert, delete on table public.chat_messages to authenticated';
  end if;
  if to_regclass('public.message_reads') is not null then
    execute 'grant select, insert on table public.message_reads to authenticated';
  end if;
  if to_regclass('public.room_members') is not null then
    execute 'grant select on table public.room_members to authenticated';
  end if;
  if to_regprocedure('public.start_direct_chat(uuid)') is not null then
    execute 'grant execute on function public.start_direct_chat(uuid) to authenticated';
  end if;
end $$;
notify pgrst, 'reload schema';

------------------------------------------------------------------------------
-- 99 · Fitur Status 24 jam [status-feature-setup.sql]
------------------------------------------------------------------------------
-- ndiflyChat Status: aktif maksimal 24 jam, batas 2 MB, cleanup melalui Supabase Storage API.
-- Jalankan di Supabase SQL Editor. Tidak menghapus storage.objects secara langsung;
-- penghapusan database langsung dapat meninggalkan file fisik di object storage.

create table if not exists public.user_status (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 media_path text not null unique,
 media_type text not null check (media_type in ('image','video')),
 caption text not null default '' check (char_length(caption) <= 180),
 created_at timestamptz not null default now(),
 expires_at timestamptz not null default (now() + interval '24 hours'),
 constraint status_expiry_window check (expires_at <= created_at + interval '24 hours' and expires_at > created_at)
);
create index if not exists user_status_active_idx on public.user_status(expires_at desc, created_at desc);

-- Waktu status ditetapkan server agar klien tidak dapat memperpanjang masa aktif
-- dengan mengirim created_at / expires_at palsu.
create or replace function public.set_user_status_timestamps()
returns trigger
language plpgsql
set search_path = public
as $$
begin
 new.created_at := now();
 new.expires_at := new.created_at + interval '24 hours';
 return new;
end;
$$;
drop trigger if exists user_status_force_24h on public.user_status;
create trigger user_status_force_24h
before insert on public.user_status
for each row execute function public.set_user_status_timestamps();
revoke all on function public.set_user_status_timestamps() from public, anon, authenticated;
alter table public.user_status enable row level security;
grant select, insert, delete on public.user_status to authenticated;
drop policy if exists "status read active" on public.user_status;
create policy "status read active" on public.user_status for select to authenticated using (expires_at > now());
drop policy if exists "status insert own" on public.user_status;
create policy "status insert own" on public.user_status for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "status delete own" on public.user_status;
create policy "status delete own" on public.user_status for delete to authenticated using (user_id = auth.uid());

insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('chat-status','chat-status',false,2097152,array['image/jpeg','image/png','image/webp','video/mp4','video/webm'])
on conflict (id) do update set public=false,file_size_limit=2097152,allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "status media read" on storage.objects;
drop policy if exists "status media read active" on storage.objects;
create policy "status media read active" on storage.objects for select to authenticated using (
 bucket_id='chat-status' and exists (
  select 1 from public.user_status s
  where s.media_path=storage.objects.name and s.expires_at > now()
 )
);
drop policy if exists "status media upload own" on storage.objects;
create policy "status media upload own" on storage.objects for insert to authenticated with check (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "status media delete own" on storage.objects;
create policy "status media delete own" on storage.objects for delete to authenticated using (bucket_id='chat-status' and (storage.foldername(name))[1]=auth.uid()::text);

-- Cleanup job calls the status-cleanup Edge Function every minute.
-- The Edge Function removes files through Storage API first, then deletes database records.


-- 100 · Log panggilan + balasan status
-- ndiflyChat bagian 7: log panggilan + balasan status. Aman dijalankan ulang.
alter table public.chat_messages add column if not exists kind text not null default 'text';
alter table public.chat_messages add column if not exists meta jsonb;
alter table public.chat_messages drop constraint if exists chat_messages_kind_check;
alter table public.chat_messages add constraint chat_messages_kind_check check (kind in ('text','call','status_reply'));
create table if not exists public.call_logs (id uuid primary key default gen_random_uuid(), room_id uuid references public.rooms(id) on delete set null, caller_id uuid not null references public.profiles(id) on delete cascade, callee_id uuid not null references public.profiles(id) on delete cascade, mode text not null check (mode in ('audio','video')), status text not null check (status in ('completed','missed','declined','canceled','failed')), started_at timestamptz not null default now(), answered_at timestamptz, ended_at timestamptz not null default now(), duration_seconds integer not null default 0 check (duration_seconds >= 0), created_at timestamptz not null default now());
create index if not exists call_logs_caller_idx on public.call_logs (caller_id, started_at desc);
create index if not exists call_logs_callee_idx on public.call_logs (callee_id, started_at desc);
alter table public.call_logs enable row level security;
drop policy if exists "call logs read own" on public.call_logs;
create policy "call logs read own" on public.call_logs for select to authenticated using (auth.uid() in (caller_id, callee_id));
drop policy if exists "call logs insert as caller" on public.call_logs;
create policy "call logs insert as caller" on public.call_logs for insert to authenticated with check (auth.uid() = caller_id);
grant select, insert on public.call_logs to authenticated;
notify pgrst, 'reload schema';

