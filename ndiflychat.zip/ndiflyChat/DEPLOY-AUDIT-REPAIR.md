# Panduan menerapkan hasil audit NDIFLYCHAT

## 1. Database

Buka Supabase Dashboard → SQL Editor, lalu jalankan seluruh isi `NDIFLYCHAT-DATABASE-REPAIR.sql`. Jalankan script sampai selesai tanpa error. Script ini mempertahankan data akun/pesan; ia menambah/memperbaiki struktur tabel, policy, bucket, fungsi inbox, serta aturan realtime.

## 2. Edge Functions

Di terminal pada root project yang sudah di-link ke Supabase:

```bash
supabase login
supabase link --project-ref jueycexmxuetbdqdwrfv
supabase functions deploy username-register
supabase functions deploy status-cleanup
```

`supabase/config.toml` menetapkan `verify_jwt = false` untuk dua fungsi tersebut. Pendaftaran username memvalidasi input sendiri dan memakai service role hanya di server. Fungsi cleanup status dilindungi `STATUS_CLEANUP_SECRET`.

Buat secret acak minimal 32 karakter dan simpan sebagai Edge Function Secret `STATUS_CLEANUP_SECRET`. Gunakan nilai yang sama di Supabase Vault untuk jadwal Cron, ikuti SQL di `STATUS-SETUP.md`. Jangan menaruh service-role key atau secret cleanup di frontend.

## 3. Frontend

Deploy seluruh isi folder website ke Vercel. Jangan hanya mengganti satu file JS; gunakan seluruh ZIP supaya HTML, JavaScript, CSS, dan migrasi berada pada versi yang cocok. Penanda cache aset sudah dinaikkan ke `audit3`.

## 4. Pemeriksaan live sesudah deploy

Uji dengan dua akun berbeda: daftar username baru, logout/login, refresh browser, buka Global Community, mulai DM, kirim teks/foto/VN, hapus pesan, periksa status, lalu uji panggilan audio/video di dua perangkat/browser. Pastikan status benar-benar dihapus oleh Cron setelah 24 jam.

Paket ini lolos pemeriksaan sintaks lokal, tetapi belum menggantikan pengujian runtime pada project Supabase, deployment Vercel, dan perangkat nyata.
