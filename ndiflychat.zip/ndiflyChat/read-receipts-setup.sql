-- ndiflyChat: status baca pesan (jalankan setelah supabase-setup.sql dan private-chat-setup.sql)
create table if not exists public.message_reads (
  message_id uuid not null references public.chat_messages(id) on delete cascade,
  reader_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, reader_id)
);
create index if not exists message_reads_reader_idx on public.message_reads(reader_id, message_id);
create index if not exists message_reads_message_idx on public.message_reads(message_id, read_at desc);

alter table public.message_reads enable row level security;
grant usage on schema public to authenticated;
grant select, insert on public.message_reads to authenticated;

drop policy if exists "users can view own read receipts and receipts for own messages" on public.message_reads;
create policy "users can view own read receipts and receipts for own messages"
on public.message_reads for select to authenticated
using (
  reader_id = auth.uid()
  or exists (
    select 1 from public.chat_messages m
    where m.id = message_reads.message_id and m.sender_id = auth.uid()
  )
);

drop policy if exists "users can mark accessible messages as read" on public.message_reads;
create policy "users can mark accessible messages as read"
on public.message_reads for insert to authenticated
with check (
  reader_id = auth.uid()
  and exists (
    select 1
    from public.chat_messages m
    join public.rooms r on r.id = m.room_id
    where m.id = message_reads.message_id
      and m.sender_id <> auth.uid()
      and (
        r.is_public = true
        or exists (
          select 1 from public.room_members rm
          where rm.room_id = r.id and rm.user_id = auth.uid()
        )
      )
  )
);

do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'message_reads'
  ) then
    alter publication supabase_realtime add table public.message_reads;
  end if;
end $$;
notify pgrst, 'reload schema';
