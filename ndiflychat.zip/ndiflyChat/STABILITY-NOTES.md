# ndiflyChat stability build — 2026-10-18

## Fixes included
- Declared `messageReadObserver` and `readMessagesHandled`, and disconnect/recreate the observer when switching rooms.
- Added `id="welcome-banner"` and made the corresponding JavaScript access optional, preventing the `classList` startup crash.
- Removed the legacy `?dock=settings` theme-toggle behavior. Settings now has a dedicated `settings.html` page; opening it does not change the selected theme.
- Updated the Information page dock link to `settings.html`.
- Added cache-busting versions to core chat/auth/landing assets so mobile browsers are less likely to reuse stale JS/CSS.
- Kept username underscore support for search (`andif_dev`).
- Improved feedback when the direct-message RPC is missing from Supabase schema cache.
- Added explicit table grants to setup SQL and a guarded `repair-permissions.sql`; row-level security remains enabled.
- Retired the unused duplicate legacy `js/script.js` bundle to prevent accidental second Supabase initialization.
- Added a guard if Supabase client initialization fails and hardened the landing-page session check.

## Validation performed
- `node --check` on every JavaScript file.
- Syntax check for inline JavaScript in HTML pages.
- HTML duplicate-ID checks and local asset-link checks.
- `chat.js` direct DOM-ID reference check.
- CSS parsing using tinycss2.

## Live-test limitations
Static validation cannot verify the user's deployed Vercel build, Supabase role grants/RLS, Realtime configuration, or WebRTC connectivity. These still need an on-site test against the connected Supabase project. Do not put the Supabase service-role key in frontend files.


## Audit fungsional terbaru
- Menyambungkan pencarian username, pembukaan DM, pencarian pesan, panel informasi, dan navigasi mobile.
- Memuat pesan terbaru dan menangani perpindahan ruang cepat; status baca hanya ditandai saat pesan terlihat.
- Membatasi unggahan ke PNG/JPG/WEBP dan membersihkan objek jika kirim gagal.
- Menambahkan signaling panggilan WebRTC pada Global Community dan kebijakan RLS private channel melalui `global-call-setup.sql`.
- Memperbaiki logout ketika panggilan sedang aktif dan menangani penyimpanan tema yang tidak tersedia.
- Tes langsung dengan Supabase memerlukan setup SQL, Edge Function, HTTPS, serta minimal dua akun untuk chat/panggilan.
