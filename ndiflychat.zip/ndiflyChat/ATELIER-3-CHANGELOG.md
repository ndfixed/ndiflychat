# ndiflyChat — Atelier 3.2

A product-wide visual and responsive refinement of ndiflyChat. This revision focuses on the full experience rather than a color-only reskin: page hierarchy, form layout, conversation surfaces, settings, information architecture, theme behavior, and compact navigation are treated as one system.

## Product and visual changes

- Rebuilt the landing page around a clearer product introduction, a labeled interface preview, user-facing benefits, a balanced feature grid, infrastructure details, and direct calls to action.
- Rebuilt login and registration page layouts while preserving the IDs consumed by `js/auth.js`.
- Applied one shared ink/navy + cobalt dark theme and paper + cobalt light theme. Borders, input surfaces, active states, avatar accents, action buttons, and focus rings now follow the same token system.
- Reduced decorative glow and glass effects in the chat workspace in favor of clearer surfaces, consistent spacing, and stronger reading contrast.
- Refined the navigation dock to be shorter on mobile and placed the desktop chat navigation in the sidebar rather than over the message composer.
- Reworked Settings and Information as viewport-sized app shells with their own scroll regions, reserving a separate row for the dock so long content cannot disappear behind navigation on desktop or mobile.
- Tuned the mobile Settings profile editor, Information hero/developer card, feature grid, and dock spacing after checking actual 390px viewport layouts.
- Fixed a high-specificity mobile layout conflict that squeezed the Information hero into a narrow column, and stacked the developer profile card correctly on phones.
- Balanced the four Information feature cards in a four-column desktop grid, two-column tablet grid, and single-column phone layout.
- Harmonized the Information page accents with cobalt while preserving explicit success/live states as status indicators.
- Made saved dark/light preference apply consistently and update `color-scheme` / browser theme color metadata.
- Preserved existing chat and backend code, including Supabase setup files, SQL migrations, Edge Function code, message/read-receipt hooks, profile-photo flow, and call-related files.

## Key files

- `index.html`, `login.html`, `daftar.html`
- `chat.html`, `settings.html`, `informasi.html`
- `css/atelier.css` (shared visual overrides/refinements)
- `js/theme.js` (saved theme initialization)
- `ATELIER-3-CHANGELOG.md`

## Verification performed

- Parsed all 6 HTML pages and checked for duplicate IDs.
- Checked 46 local asset/script/stylesheet references; no missing local references were found.
- Ran `node --check` on all 6 application JavaScript files and 4 inline scripts; no syntax errors were found.
- Parsed all 6 CSS files, including nested at-rules; no parser errors were found.
- Rendered all primary pages at 1365px desktop and 390px mobile viewports in an isolated Chromium layout harness; no horizontal overflow was recorded. The final pass also inspected dark and light mobile layouts and fixed the Information hero/developer-card sizing issue.
- Specifically verified Settings and Information internal scrolling at desktop and phone sizes: long content reaches its end while the dock remains in a separate, non-overlapping layout row.
- Verified the ZIP archive after packaging.

This is not a substitute for a live backend test. Authentication, private-room creation, real-time sync, read receipts, storage upload, and WebRTC signaling still depend on valid Supabase configuration, deployed functions, database schema, RLS rules, browser permissions, and the target hosting environment. Those live flows were not end-to-end tested here.

## Design reference

The page hierarchy takes broad inspiration from the benefit-first content structure and clear action hierarchy seen on [Jagoan Hosting](https://www.jagoanhosting.com/). It does not reuse their logo, copy, or exact page layout; ndiflyChat has its own cobalt-centered visual system.

## Luxe 4
- `css/luxe.css` (loaded last): champagne-gold + cobalt luxe layer, overlap/clipping guards (min-width, ellipsis, safe-area, dvh-limited dialogs, dock-clear scroll padding).
- `js/perf.js` + Settings → "Performa & animasi": **Smooth · 120 Hz** (default, compositor-only motion) and **Lite · 60 Hz** (no animation, no blur). Saved in `ndifly_perf`.
- Luxe 4.1: pill tanggal & badge simetris (tengah presisi), baris percakapan dirapikan (grid avatar | judul+tanggal / pratinjau+badge), heading daftar sejajar, ikon/tombol di semua halaman terpusat, polish hero/auth/informasi.
- Luxe 5: cache version naik ke `luxe5` (memaksa browser memuat CSS/JS baru), palet terang/gelap disegarkan, ikon SVG kustom (Smooth, Lite, "Ruang chat milikmu"), header/composer/bubble ruang chat simetris, `fa-sparkles` (Pro-only, tampil kosong) diganti.
- Luxe 6: cache `luxe6`; copy dibuat meyakinkan & jujur; contoh pengguna diganti andif_dev/dika/nata; tombol aksi pesan, status baca, kutipan balasan, landing & auth diperbaiki; animasi scroll-reveal yang menyembunyikan kartu dihapus.
