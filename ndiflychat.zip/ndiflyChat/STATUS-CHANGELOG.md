# Status feature & repair

- Added status list, upload foto/video, and full-screen viewer.
- Client compresses images to WebP and converts supported larger videos to WebM; final upload is capped at 2 MB.
- The database sets expiry to 24 hours on the server, avoiding device-clock drift.
- Status media bucket is private; short-lived signed URLs end at status expiry.
- Physical cleanup runs through an Edge Function using the Supabase Storage API, then deletes expired database rows.
- Existing username-only authentication remains unchanged; no phone-number field is added.

## Redesign halaman Status + perbaikan dock (v. sp1 / dg4)
- `status.html` dibuat ulang bergaya WhatsApp Status dengan dark glassmorphism: "Status Saya" (avatar cincin biru + tanda +), pembatas "Pembaruan terkini", lalu daftar kontak dengan cincin avatar (biru-ungu-cyan = belum dilihat, abu-abu = sudah dilihat, terpotong per jumlah status) dan cap waktu ("Hari ini, 14.20" / "Kemarin, ...").
- Status yang sudah dilihat disimpan per akun di perangkat (`localStorage`, hanya untuk cincin avatar).
- Bug: `status.html` tidak memuat `status-ui.css`, `splash.css`, `design.css`, `neo.css` sehingga penampil story/editor tidak bergaya dan loading screen tidak ada. Sudah dimuat.
- Bug: dock di semua halaman hanya 4 item dan tidak ada tautan ke Status (di halaman Status malah tidak ada Panggilan). Sekarang 5 item di semua halaman: Chat, Status, Informasi, Panggilan, Settings.
- Dock desktop (sidebar chat 280px) tidak lagi meluap dengan 5 item; layar 320px juga muat.
- Gloss dock: pantulan atas lebih besar dan lebih turun, ditambah pantulan di bagian bawah + garis terang tepi bawah (token `--dg-gloss-*` di `css/dock-glass.css`).
- Halaman Status tidak lagi memutar spinner selamanya bila koneksi/tabel bermasalah; pesan galat ditampilkan.
- Nama di penampil story dan daftar memakai `display_name` bila ada.

## Dock: lensa tidak keluar pill + chat tidak auto-masuk (dg5 / chat s3)
- Bug: lensa kaca meluncur dengan easing pegas yang overshoot ~10% dari jarak tempuh, jadi saat pindah ke Settings (paling kanan) lensa keluar dari pill. Sekarang memakai ease-in-out simetris tanpa overshoot (`--dg-glide`), posisi lensa juga di-clamp di `dock-glass.js`.
- Efek "jelly" dibuat simetris (meregang di tengah perjalanan lalu kembali persis ke ukuran awal), durasi 0,42 dtk sama dengan luncuran lensa.
- Menu Chat tidak lagi langsung masuk ke ruang Global Community di layar kecil: ruang disiapkan di latar (`openRoom(..., {auto:true})`), tetapi yang tampil daftar chat; ruang dibuka manual dengan mengetuknya. Tautan `?room=` (notifikasi) tetap langsung membuka ruang.
