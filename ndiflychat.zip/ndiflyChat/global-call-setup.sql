-- ndiflyChat: izin signaling panggilan Global Community.
-- Jalankan sekali di Supabase SQL Editor setelah Realtime tersedia.
-- Private channel + RLS membatasi signaling ke pengguna terautentikasi.

-- Broadcast: pengguna terautentikasi dapat menerima sinyal hanya pada topik panggilan.
drop policy if exists "authenticated users receive ndiflyChat global call signals" on realtime.messages;
create policy "authenticated users receive ndiflyChat global call signals"
on realtime.messages
for select
to authenticated
using (
  (select realtime.topic()) = 'ndifly-global-call'
  and realtime.messages.extension = 'broadcast'
);

-- Broadcast: pengguna terautentikasi dapat mengirim sinyal hanya pada topik panggilan.
drop policy if exists "authenticated users send ndiflyChat global call signals" on realtime.messages;
create policy "authenticated users send ndiflyChat global call signals"
on realtime.messages
for insert
to authenticated
with check (
  (select realtime.topic()) = 'ndifly-global-call'
  and realtime.messages.extension = 'broadcast'
);
