# ndiflyChat — Craft visual redesign (Craft 2)

This package includes the full ndiflyChat project with the expanded visual system integrated into its existing pages and assets.

## Visual direction
- Dark: near-black ink/navy surfaces with restrained cobalt accents and clear surface hierarchy.
- Light: paper-white surfaces, cool gray backgrounds, and matching cobalt actions.
- Responsive chat inbox and conversation layout, compact but readable metadata, reply previews, unread indicators, and composer focus states.
- Consistent landing, sign-in, sign-up, settings, and information pages.
- Theme preference shared across pages via `localStorage` key `ndifly_theme`.
- Keyboard focus visibility, reduced-motion support, and mobile safe-area spacing.

## Files
- `css/craft.css`: final visual layer, loaded after the existing page styles.
- `js/theme.js`: early theme initialization to avoid a flash of the wrong theme.
- Existing `js/chat.js`, auth, configuration, SQL setup, and Supabase function files are retained.

## Install
Extract the ZIP and deploy the entire `ndiflyChat` folder as a unit. Do not upload only the HTML files; keep the relative `css/`, `js/`, `assets/`, and Supabase setup files together. Configure the Supabase project values in `js/config.js` before using authentication or realtime features.

## Validation notes
JavaScript syntax and CSS parsing were checked locally. A live browser session connected to the project's Supabase instance was not available for end-to-end testing; verify sign-in, registration, realtime chat, and theme persistence after deployment.
