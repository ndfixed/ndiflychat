# Status ndiflyChat — setup dan kedaluwarsa 24 jam

1. Jalankan `status-feature-setup.sql` di Supabase SQL Editor. Bucket `chat-status` dibuat **private**; file tidak memakai public URL. Trigger database menetapkan `created_at` dan `expires_at` dari waktu server, sehingga klien tidak dapat memperpanjang masa aktif.
2. Deploy Edge Function `username-register` dan `status-cleanup` bersama folder `supabase/functions`. Pastikan konfigurasi `supabase/config.toml` ikut dipakai saat deploy. Perintah CLI: `supabase functions deploy username-register` dan `supabase functions deploy status-cleanup`.
3. Atur secret `STATUS_CLEANUP_SECRET` pada Supabase Edge Functions dengan nilai acak panjang (minimal 32 karakter). Fungsi cleanup memeriksa header rahasia ini sebelum memakai service role.
4. Di Supabase Database, aktifkan Extensions `pg_cron`, `pg_net`, dan `supabase_vault` bila belum aktif.
5. Simpan URL project dan secret cleanup ke Vault. Ganti nilai contoh berikut dengan nilai milik project:

```sql
select vault.create_secret('https://PROJECT_REF.supabase.co', 'ndifly_project_url');
select vault.create_secret('NILAI_STATUS_CLEANUP_SECRET_YANG_SAMA', 'ndifly_status_cleanup_secret');
```

6. Jadwalkan cleanup setiap menit. Jalankan sekali:

```sql
select cron.unschedule(jobid) from cron.job where jobname = 'ndiflychat-status-cleanup';
select cron.schedule(
  'ndiflychat-status-cleanup',
  '* * * * *',
  $$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name = 'ndifly_project_url') || '/functions/v1/status-cleanup',
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-status-cleanup-secret', (select decrypted_secret from vault.decrypted_secrets where name = 'ndifly_status_cleanup_secret')
      ),
      body := '{}'::jsonb
    );
  $$
);
```

Status tidak lagi bisa dilihat setelah `expires_at` karena query RLS dan URL media bertanda tangan berakhir pada waktu tersebut. Pembersihan fisik menghapus file melalui Supabase Storage API terlebih dahulu, baru menghapus row database. Jika Storage API gagal, row tetap ada agar percobaan cleanup berikutnya dapat mengulanginya.

Foto diubah menjadi WebP. Video besar dicoba dikompres menjadi WebM oleh browser; perangkat yang tidak mendukung proses ini akan menolak upload dengan pesan yang jelas, bukan mengunggah file di atas 2 MB. Gunakan HTTPS.
