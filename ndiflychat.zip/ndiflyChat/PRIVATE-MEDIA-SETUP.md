# Media percakapan privat

Media pesan yang baru dikirim sekarang masuk ke bucket `chat-media` yang **private**. Aplikasi hanya membuat signed URL ketika pengguna dapat membaca pesan terkait, mengikuti RLS ruang publik/privat.

1. Jalankan `private-media-setup.sql`, atau jalankan file gabungan `NDIFLYCHAT-DATABASE-REPAIR.sql`.
2. Deploy frontend setelah migrasi berhasil.
3. Media lama tetap memakai URL lama dari bucket `chat-images` / `chat-voice` agar riwayat tidak rusak. URL lama tersebut belum dimigrasikan otomatis dan bucket lama tetap public untuk kompatibilitas avatar serta riwayat. Untuk menghilangkan akses publik lama sepenuhnya, diperlukan migrasi objek lama dan kolom avatar ke skema privat terpisah.

Saat pesan baru dihapus, aplikasi menghapus baris pesan lalu mencoba menghapus objek privat milik pengirim. Jika Storage gagal, pesan tetap terhapus dan objek yatim tercatat di console agar admin dapat membersihkannya.
