-- ndiflyChat bagian 7: log panggilan + balasan status. Aman dijalankan ulang.
alter table public.chat_messages add column if not exists kind text not null default 'text';
alter table public.chat_messages add column if not exists meta jsonb;
alter table public.chat_messages drop constraint if exists chat_messages_kind_check;
alter table public.chat_messages add constraint chat_messages_kind_check check (kind in ('text','call','status_reply'));
create table if not exists public.call_logs (id uuid primary key default gen_random_uuid(), room_id uuid references public.rooms(id) on delete set null, caller_id uuid not null references public.profiles(id) on delete cascade, callee_id uuid not null references public.profiles(id) on delete cascade, mode text not null check (mode in ('audio','video')), status text not null check (status in ('completed','missed','declined','canceled','failed')), started_at timestamptz not null default now(), answered_at timestamptz, ended_at timestamptz not null default now(), duration_seconds integer not null default 0 check (duration_seconds >= 0), created_at timestamptz not null default now());
create index if not exists call_logs_caller_idx on public.call_logs (caller_id, started_at desc);
create index if not exists call_logs_callee_idx on public.call_logs (callee_id, started_at desc);
alter table public.call_logs enable row level security;
drop policy if exists "call logs read own" on public.call_logs;
create policy "call logs read own" on public.call_logs for select to authenticated using (auth.uid() in (caller_id, callee_id));
drop policy if exists "call logs insert as caller" on public.call_logs;
create policy "call logs insert as caller" on public.call_logs for insert to authenticated with check (auth.uid() = caller_id);
grant select, insert on public.call_logs to authenticated;
notify pgrst, 'reload schema';
