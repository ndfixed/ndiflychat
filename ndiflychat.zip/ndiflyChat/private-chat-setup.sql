-- Jalankan sekali di Supabase SQL Editor untuk mengaktifkan chat pribadi.
-- Tetap mempertahankan Global Community dan pesan publik yang sudah ada.

-- DM room names ("DM - @a / @b") can be up to 58 chars; the original limit of 40 truncated long usernames.
alter table public.rooms drop constraint if exists rooms_name_check;
alter table public.rooms add constraint rooms_name_check check (char_length(name) between 3 and 64);

create table if not exists public.room_members (
  room_id uuid not null references public.rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create index if not exists room_members_user_room_idx
  on public.room_members(user_id, room_id);

alter table public.room_members enable row level security;
grant usage on schema public to authenticated, service_role;
grant select, insert, update on public.profiles to service_role;
grant select, insert, update on public.profiles to authenticated;
grant select on public.room_members to authenticated;
grant select, insert, update on public.rooms to authenticated;
grant select, insert, delete on public.chat_messages to authenticated;

-- Anggota hanya dapat melihat keanggotaan ruang yang mereka ikuti.
drop policy if exists "members can view own room memberships" on public.room_members;
create policy "members can view own room memberships"
on public.room_members for select to authenticated
using (user_id = auth.uid());

-- Daftar room: ruang publik atau room privat tempat user menjadi anggota.
drop policy if exists "signed-in users can view public rooms" on public.rooms;
drop policy if exists "members can view their private rooms" on public.rooms;
create policy "members can view their private rooms"
on public.rooms for select to authenticated
using (
  is_public = true OR exists (
    select 1 from public.room_members rm
    where rm.room_id = rooms.id and rm.user_id = auth.uid()
  )
);

-- Chat message hanya boleh dibaca/dikirim pada ruang publik atau ruang privat anggota.
drop policy if exists "signed-in users can read messages in public rooms" on public.chat_messages;
drop policy if exists "members can read room messages" on public.chat_messages;
create policy "members can read room messages"
on public.chat_messages for select to authenticated
using (
  exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
  OR exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
);

drop policy if exists "users send messages as themselves" on public.chat_messages;
drop policy if exists "members can send room messages" on public.chat_messages;
create policy "members can send room messages"
on public.chat_messages for insert to authenticated
with check (
  auth.uid() = sender_id AND (
    exists (select 1 from public.rooms r where r.id = chat_messages.room_id and r.is_public = true)
    OR exists (select 1 from public.room_members rm where rm.room_id = chat_messages.room_id and rm.user_id = auth.uid())
  )
);

-- Membuat atau membuka kembali DM yang sama. SECURITY DEFINER diperlukan agar
-- dua anggota bisa ditambahkan secara atomik tanpa membuka insert room_members ke client.
create or replace function public.start_direct_chat(p_target_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_me uuid := auth.uid();
  v_room uuid;
  v_name text;
  v_target_username text;
  v_my_username text;
begin
  if v_me is null then
    raise exception 'Login diperlukan';
  end if;
  if p_target_user is null or p_target_user = v_me then
    raise exception 'Pilih pengguna lain';
  end if;

  select username into v_target_username from public.profiles where id = p_target_user;
  if v_target_username is null then
    raise exception 'Pengguna tidak ditemukan';
  end if;
  select username into v_my_username from public.profiles where id = v_me;

  -- Serialise concurrent requests for the same pair so double-taps cannot create two DM rooms.
  perform pg_advisory_xact_lock(hashtextextended(least(v_me::text, p_target_user::text) || ':' || greatest(v_me::text, p_target_user::text), 0));

  -- Cari room DM yang sudah berisi tepat dua pengguna ini.
  select rm1.room_id into v_room
  from public.room_members rm1
  join public.room_members rm2 on rm2.room_id = rm1.room_id
  join public.rooms r on r.id = rm1.room_id and r.is_public = false
  where rm1.user_id = v_me and rm2.user_id = p_target_user
    and (select count(*) from public.room_members allm where allm.room_id = rm1.room_id) = 2
  limit 1;

  if v_room is not null then
    return v_room;
  end if;

  v_name := 'DM - @' || coalesce(v_my_username, 'user') || ' / @' || v_target_username;
  insert into public.rooms(name, description, is_public, created_by)
  values (left(v_name, 64), 'Percakapan pribadi', false, v_me)
  returning id into v_room;

  insert into public.room_members(room_id, user_id)
  values (v_room, v_me), (v_room, p_target_user);

  return v_room;
end;
$$;

revoke all on function public.start_direct_chat(uuid) from public;
grant execute on function public.start_direct_chat(uuid) to authenticated;

-- Realtime untuk pesan baru sudah dipakai oleh chat.js; pastikan tabel tercantum.
do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='chat_messages'
  ) then
    alter publication supabase_realtime add table public.chat_messages;
  end if;
end $$;


-- Status baca pesan. Untuk project existing, file read-receipts-setup.sql juga dapat dijalankan terpisah.
-- ndiflyChat: status baca pesan (jalankan setelah supabase-setup.sql dan private-chat-setup.sql)
create table if not exists public.message_reads (
  message_id uuid not null references public.chat_messages(id) on delete cascade,
  reader_id uuid not null references public.profiles(id) on delete cascade,
  read_at timestamptz not null default now(),
  primary key (message_id, reader_id)
);
create index if not exists message_reads_reader_idx on public.message_reads(reader_id, message_id);
create index if not exists message_reads_message_idx on public.message_reads(message_id, read_at desc);

alter table public.message_reads enable row level security;
grant usage on schema public to authenticated, service_role;
grant select, insert, update on public.profiles to service_role;
grant select, insert, update on public.profiles to authenticated;
grant select, insert on public.message_reads to authenticated;

drop policy if exists "users can view own read receipts and receipts for own messages" on public.message_reads;
create policy "users can view own read receipts and receipts for own messages"
on public.message_reads for select to authenticated
using (
  reader_id = auth.uid()
  or exists (
    select 1 from public.chat_messages m
    where m.id = message_reads.message_id and m.sender_id = auth.uid()
  )
);

drop policy if exists "users can mark accessible messages as read" on public.message_reads;
create policy "users can mark accessible messages as read"
on public.message_reads for insert to authenticated
with check (
  reader_id = auth.uid()
  and exists (
    select 1
    from public.chat_messages m
    join public.rooms r on r.id = m.room_id
    where m.id = message_reads.message_id
      and m.sender_id <> auth.uid()
      and (
        r.is_public = true
        or exists (
          select 1 from public.room_members rm
          where rm.room_id = r.id and rm.user_id = auth.uid()
        )
      )
  )
);

do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'message_reads'
  ) then
    alter publication supabase_realtime add table public.message_reads;
  end if;
end $$;
notify pgrst, 'reload schema';
