(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const form = $('auth-form');
  if (!form) return;
  const isRegister = !!$('auth-password-confirm');
  let busy = false, toastTimer = 0, redirecting = false;
  const toast = (message, type = '') => {
    const el = $('toast'); if (!el) return;
    el.textContent = message; el.className = `toast show ${type}`;
    if (type === 'error') {
      const card = document.querySelector('.auth-card');
      if (card) { card.classList.remove('shake'); void card.offsetWidth; card.classList.add('shake'); }
    }
    clearTimeout(toastTimer); toastTimer = setTimeout(() => { el.className = 'toast'; }, 4500);
  };
  const emailFor = username => `${username}@ndiflychat.invalid`; // keep compatibility with existing username-only accounts
  const setBusy = state => {
    busy = state;
    const btn = $('auth-submit'); if (!btn) return;
    btn.disabled = state; btn.setAttribute('aria-busy', String(state));
    btn.innerHTML = state ? '<i class="fa-solid fa-spinner fa-spin"></i> Memproses...' : `${isRegister ? 'Buat akun' : 'Masuk'} <i class="fa-solid fa-arrow-right"></i>`;
  };
  const usernameInput = $('auth-username'), passwordInput = $('auth-password');
  $('toggle-password')?.addEventListener('click', () => {
    const input = passwordInput; if (!input) return;
    const show = input.type === 'password'; input.type = show ? 'text' : 'password';
    const button = $('toggle-password');
    button.innerHTML = show ? '<i class="fa-regular fa-eye-slash"></i>' : '<i class="fa-regular fa-eye"></i>';
    button.setAttribute('aria-label', show ? 'Sembunyikan password' : 'Tampilkan password');
    button.setAttribute('aria-pressed', String(show));
  });
  usernameInput?.addEventListener('input', event => {
    const el = event.target, pos = el.selectionStart;
    const value = el.value.toLowerCase().replace(/\s+/g, '');
    if (value !== el.value) { el.value = value; try { el.setSelectionRange(pos, pos); } catch (_) {} }
  });
  const capsEl = $('caps-warning');
  const capsCheck = event => { if (capsEl && event.getModifierState) capsEl.classList.toggle('hidden', !event.getModifierState('CapsLock')); };
  passwordInput?.addEventListener('keydown', capsCheck);
  passwordInput?.addEventListener('keyup', capsCheck);
  passwordInput?.addEventListener('blur', () => capsEl?.classList.add('hidden'));

  if (isRegister) {
    const helper = $('username-helper'), defaultHelper = helper?.textContent;
    usernameInput?.addEventListener('input', () => {
      if (!helper) return;
      const value = usernameInput.value;
      if (!value) { helper.textContent = defaultHelper; helper.className = 'field-helper'; }
      else if (value.length < 3) { helper.textContent = 'Terlalu pendek — minimal 3 karakter.'; helper.className = 'field-helper is-bad'; }
      else if (!/^[a-z0-9_]{3,24}$/.test(value)) { helper.textContent = 'Hanya huruf kecil, angka, dan underscore (maks. 24).'; helper.className = 'field-helper is-bad'; }
      else { helper.textContent = 'Format username valid.'; helper.className = 'field-helper is-ok'; }
    });
    const meter = $('pw-meter'), label = $('pw-label'), confirm = $('auth-password-confirm'), hint = $('auth-hint');
    const scoreNames = ['Minimal 8 karakter', 'Lemah', 'Cukup', 'Kuat', 'Sangat kuat'];
    const refresh = () => {
      const value = passwordInput?.value || '';
      let score = value.length < 8 ? (value ? 1 : 0) : 1;
      if (value.length >= 12) score++;
      if (/[a-z]/.test(value) && /[A-Z]/.test(value)) score++;
      if (/\d/.test(value) && /[^A-Za-z0-9]/.test(value)) score++;
      score = Math.min(4, score);
      if (meter) meter.dataset.score = String(score);
      if (label) label.textContent = value && value.length < 8 ? `Terlalu pendek (${value.length}/8)` : scoreNames[score];
      if (hint && confirm?.value) {
        const same = confirm.value === value;
        hint.textContent = same ? 'Kedua password sama.' : 'Konfirmasi password belum sama.';
        hint.classList.toggle('is-bad', !same); hint.classList.toggle('is-ok', same);
      }
    };
    passwordInput?.addEventListener('input', refresh);
    confirm?.addEventListener('input', refresh);
  }

  try {
    const reason = new URLSearchParams(location.search).get('reason');
    if (reason === 'session') setTimeout(() => toast('Sesimu sudah berakhir. Silakan masuk lagi.', 'error'), 150);
    else if (reason === 'missing-session') setTimeout(() => toast('Masuk dulu untuk membuka chat.'), 150);
  } catch (_) {}

  const getClient = async () => {
    if (window.ndiflySupabase) return window.ndiflySupabase;
    if (window.ndiflySupabaseReady) {
      const client = await window.ndiflySupabaseReady;
      if (client) return client;
    }
    throw new Error('Koneksi Supabase belum siap. Muat ulang halaman dan periksa koneksi internet.');
  };
  const functionErrorMessage = async error => {
    let detail = '';
    try {
      const context = error?.context;
      if (context && typeof context.clone === 'function') {
        const payload = await context.clone().json();
        detail = payload?.error || payload?.message || '';
      } else if (context && typeof context.json === 'function') {
        const payload = await context.json(); detail = payload?.error || payload?.message || '';
      }
    } catch (_) {}
    return detail || error?.message || 'Pendaftaran belum berhasil. Coba lagi.';
  };
  const explainError = error => {
    const raw = String(error?.message || error || 'Terjadi kesalahan. Coba lagi.');
    console.error('[ndiflyChat auth]', error);
    if (/invalid login credentials/i.test(raw)) return 'Username atau password salah.';
    if (/email not confirmed/i.test(raw)) return 'Akun belum dikonfirmasi. Hubungi pengelola.';
    if (/already registered|user already registered|username sudah digunakan/i.test(raw)) return 'Username sudah digunakan. Silakan pilih username lain atau masuk.';
    if (/duplicate key|profiles_username_key/i.test(raw)) return 'Username sudah digunakan. Pilih username lain.';
    if (/invalid api key|invalid jwt|api key/i.test(raw)) return 'Koneksi akun bermasalah. Pengelola perlu memeriksa key Supabase.';
    if (/failed to fetch|networkerror|network request failed|load failed|fetch failed/i.test(raw)) return 'Tidak dapat terhubung. Periksa internet lalu coba lagi.';
    if (/function.*not found|failed to send a request to the edge function|username-register/i.test(raw)) return 'Layanan pendaftaran belum aktif. Pengelola perlu deploy Edge Function username-register.';
    if (/rate limit|too many requests/i.test(raw)) return 'Terlalu banyak percobaan. Tunggu sebentar lalu coba lagi.';
    if (/password.*(weak|short)|weak password/i.test(raw)) return 'Password terlalu lemah. Gunakan minimal 8 karakter.';
    if (/invalid email/i.test(raw)) return 'Format identitas akun internal ditolak oleh konfigurasi Auth. Periksa konfigurasi Supabase.';
    return raw.length > 180 ? 'Terjadi kendala pada layanan akun. Coba lagi beberapa saat.' : raw;
  };

  // Session check is awaited before enabling form submission, preventing redirect races.
  let clientReady = false;
  (async () => {
    try {
      const sb = await getClient();
      const { data, error } = await sb.auth.getSession();
      if (error) throw error;
      clientReady = true;
      if (data?.session && !redirecting) { redirecting = true; location.replace('chat.html'); }
    } catch (error) {
      console.error('[ndiflyChat auth] session check:', error);
      clientReady = true;
      toast(explainError(error), 'error');
    }
  })();

  form.addEventListener('submit', async event => {
    event.preventDefault(); if (busy || redirecting) return;
    if (!clientReady) { toast('Sedang memeriksa sesi akun. Coba sebentar lagi.'); return; }
    const username = (usernameInput?.value || '').trim().toLowerCase();
    const password = passwordInput?.value || '';
    if (!/^[a-z0-9_]{3,24}$/.test(username)) { toast('Username harus 3–24 karakter: huruf kecil, angka, atau underscore.', 'error'); return; }
    if (password.length < 8 || password.length > 128) { toast('Password harus 8–128 karakter.', 'error'); return; }
    if (isRegister && $('auth-password-confirm')?.value !== password) { toast('Konfirmasi password tidak sama.', 'error'); return; }
    setBusy(true);
    try {
      const sb = await getClient();
      if (isRegister) {
        const { data: created, error: createError } = await sb.functions.invoke('username-register', { body: { username, password } });
        if (createError) throw new Error(await functionErrorMessage(createError));
        if (!created?.ok) throw new Error(created?.error || 'Server belum mengonfirmasi pembuatan akun.');
      }
      const { data, error } = await sb.auth.signInWithPassword({ email: emailFor(username), password });
      if (error) throw error;
      if (!data?.session || !data?.user) throw new Error('Login tidak menghasilkan sesi aktif. Coba masuk kembali.');
      try { sessionStorage.removeItem('ndifly_welcome_shown'); } catch (_) {}
      redirecting = true; location.replace('chat.html');
    } catch (error) {
      toast(explainError(error), 'error');
    } finally {
      if (!redirecting) setBusy(false);
    }
  });
})();
