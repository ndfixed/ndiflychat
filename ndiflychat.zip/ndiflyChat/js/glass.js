/* ndiflyChat · glass.js — buram (0–40 px) & transparansi (0–100 %) efek kaca. Tersimpan di perangkat, berlaku di semua halaman
   (termasuk iframe panggilan: storage event menyegarkan halaman lain yang sedang terbuka). */
(() => {
  'use strict';
  const root = document.documentElement, BK = 'ndifly_glass_blur', CK = 'ndifly_glass_clear';
  const DEF = { blur: 18, clear: 60 }, PRE = { clear: [22, 85], balanced: [18, 60], frosted: [12, 25] };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  const read = (k, d) => { try { const v = parseFloat(localStorage.getItem(k)); return Number.isFinite(v) ? v : d; } catch (_) { return d; } };
  const get = () => ({ blur: clamp(Math.round(read(BK, DEF.blur)), 0, 40), clear: clamp(Math.round(read(CK, DEF.clear)), 0, 100) });
  const apply = v => { root.style.setProperty('--g-blur', v.blur + 'px'); root.style.setProperty('--g-k', ((100 - v.clear) / 40).toFixed(3)); return v; };   // 60 % = tampilan bawaan
  const set = (blur, clear) => {
    const v = apply({ blur: clamp(Math.round(blur), 0, 40), clear: clamp(Math.round(clear), 0, 100) });
    try { localStorage.setItem(BK, v.blur); localStorage.setItem(CK, v.clear); } catch (_) {}
    return v;
  };
  apply(get());
  window.ndiflyGlass = { get, set, reset: () => set(DEF.blur, DEF.clear), defaults: DEF };
  window.addEventListener('storage', e => { if (e.key === BK || e.key === CK) apply(get()); });

  document.addEventListener('DOMContentLoaded', () => {
    const $ = id => document.getElementById(id), blur = $('glass-blur'), clear = $('glass-clear');
    if (!blur || !clear) return;
    const paint = v => {
      blur.value = v.blur; clear.value = v.clear;
      $('glass-blur-out').textContent = String(v.blur); $('glass-clear-out').textContent = v.clear + '%';
      document.querySelectorAll('[data-glass-preset]').forEach(b => { const p = PRE[b.dataset.glassPreset]; b.setAttribute('aria-pressed', String(p[0] === v.blur && p[1] === v.clear)); });
    };
    const onInput = () => paint(set(+blur.value, +clear.value));
    blur.addEventListener('input', onInput); clear.addEventListener('input', onInput);
    document.querySelectorAll('[data-glass-preset]').forEach(b => b.addEventListener('click', () => { const p = PRE[b.dataset.glassPreset]; paint(set(p[0], p[1])); }));
    $('glass-reset').addEventListener('click', () => paint(window.ndiflyGlass.reset()));
    paint(get());
  });
})();
