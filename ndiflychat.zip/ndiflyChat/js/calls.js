/* Riwayat panggilan: daftar log, filter, ringkasan, dan detail lengkap. */
(()=>{
 const sb=window.ndiflySupabase,$=id=>document.getElementById(id);
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let me=null,logs=[],filter='all',toastT=0;
 const toast=m=>{const t=$('toast');if(!t)return;t.textContent=m;t.className='toast show';clearTimeout(toastT);toastT=setTimeout(()=>t.className='toast',3200);};
 const dur=s=>{s=Math.max(0,Math.round(Number(s)||0));const h=Math.floor(s/3600),m=Math.floor(s%3600/60),r=s%60;return h?`${h} jam ${m} mnt`:m?`${m} mnt ${r} dtk`:`${r} dtk`;};
 const clock=d=>new Date(d).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}).replace(':','.');
 const fullDate=d=>new Date(d).toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
 function dayLabel(d){const t=new Date(d),n=new Date(),y=new Date(n);y.setDate(n.getDate()-1);if(t.toDateString()===n.toDateString())return 'Hari ini';if(t.toDateString()===y.toDateString())return 'Kemarin';return t.toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});}
 const info=l=>{
  const out=l.caller_id===me,peer=(out?l.callee:l.caller)||{},name=peer.username||peer.display_name||'Pengguna';
  const missedIn=!out&&(l.status==='missed'||l.status==='canceled');
  const labels={completed:dur(l.duration_seconds),missed:out?'Tidak dijawab':'Tak terjawab',canceled:out?'Dibatalkan':'Tak terjawab',declined:out?'Ditolak':'Kamu menolak',failed:'Gagal tersambung'};
  return {out,peer,name,missedIn,bad:missedIn||l.status==='failed',label:labels[l.status]||'',arrow:out?'fa-arrow-up-right':'fa-arrow-down-left',dir:out?'Keluar':'Masuk'};
 };
 const ava=p=>p.avatar_url?`<img src="${esc(p.avatar_url)}" alt="">`:esc((p.username||p.display_name||'?').charAt(0).toUpperCase());
 const visible=()=>logs.filter(l=>{const i=info(l);return filter==='all'||(filter==='missed'?i.missedIn:l.mode===filter);});
 function renderStats(){
  const done=logs.filter(l=>l.status==='completed');
  $('st-total').textContent=String(logs.length);{const t=done.reduce((a,l)=>a+(l.duration_seconds||0),0),h=Math.floor(t/3600),m=Math.floor(t%3600/60);$('st-time').textContent=h?`${h} j ${m} m`:m?`${m} mnt`:`${t} dtk`;}$('st-missed').textContent=String(logs.filter(l=>info(l).missedIn).length);
 }
 function render(){
  const box=$('calls-list'),rows=visible();
  if(!rows.length){box.innerHTML=`<div class="calls-empty"><i class="fa-solid fa-phone-slash"></i><p>${logs.length?'Tidak ada panggilan di kategori ini.':'Belum ada riwayat panggilan.'}</p><small>${logs.length?'Coba filter lain.':'Telepon atau video call temanmu dari chat privat, lalu riwayatnya muncul di sini.'}</small></div>`;return;}
  let last='';
  box.innerHTML=rows.map(l=>{const i=info(l),day=dayLabel(l.started_at),head=day!==last?`<h3 class="cl-day">${esc(day)}</h3>`:'';last=day;
   return head+`<button type="button" class="cl-item ${i.bad?'is-bad':''}" data-id="${esc(l.id)}"><span class="cl-ava">${ava(i.peer)}</span><span class="cl-main"><b>@${esc(i.name)}</b><small><i class="fa-solid ${i.arrow}"></i> ${i.dir} · ${esc(i.label)}</small></span><span class="cl-side"><em>${clock(l.started_at)}</em><i class="fa-solid ${l.mode==='video'?'fa-video':'fa-phone'}"></i></span></button>`;}).join('');
  box.querySelectorAll('.cl-item').forEach(b=>b.addEventListener('click',()=>openDetail(b.dataset.id)));
 }
 function openDetail(id){
  const l=logs.find(x=>x.id===id);if(!l)return;const i=info(l),st={completed:'Terhubung',missed:i.out?'Tidak dijawab':'Tak terjawab',canceled:i.out?'Dibatalkan':'Tak terjawab',declined:i.out?'Ditolak':'Kamu menolak',failed:'Gagal tersambung'}[l.status];
  const row=(ic,k,v)=>`<div class="cl-row"><span><i class="fa-solid ${ic}"></i> ${k}</span><b>${v}</b></div>`;
  const rid=l.room_id?encodeURIComponent(l.room_id):'';
  $('cl-detail').innerHTML=`<div class="cl-top"><span class="cl-ava big">${ava(i.peer)}</span><h2>@${esc(i.name)}</h2><span class="cl-badge ${i.bad?'bad':'ok'}">${esc(st)}</span></div>
   ${row(l.mode==='video'?'fa-video':'fa-phone','Jenis',l.mode==='video'?'Video call':'Telepon suara')}${row(i.arrow,'Arah',i.dir)}${row('fa-calendar','Tanggal',esc(fullDate(l.started_at)))}${row('fa-clock','Mulai',clock(l.started_at))}${row('fa-flag-checkered','Berakhir',clock(l.ended_at))}${row('fa-hourglass-half','Durasi',l.status==='completed'?dur(l.duration_seconds):'—')}
   ${rid?`<div class="cl-actions"><a class="cl-btn" href="chat.html?room=${rid}&call=audio"><i class="fa-solid fa-phone"></i> Telepon</a><a class="cl-btn" href="chat.html?room=${rid}&call=video"><i class="fa-solid fa-video"></i> Video</a><a class="cl-btn ghost" href="chat.html?room=${rid}"><i class="fa-solid fa-message"></i> Chat</a></div>`:''}`;
  $('cl-sheet').classList.remove('hidden');
 }
 const closeSheet=()=>$('cl-sheet').classList.add('hidden');
 document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',closeSheet));
 document.addEventListener('keydown',e=>{if(e.key==='Escape')closeSheet();});
 $('calls-tabs').addEventListener('click',e=>{const b=e.target.closest('[data-f]');if(!b)return;filter=b.dataset.f;document.querySelectorAll('#calls-tabs button').forEach(x=>x.classList.toggle('on',x===b));render();});
 async function load(){
  try{
   const {data:ses}=await sb.auth.getSession();if(!ses?.session){location.replace('login.html');return;}me=ses.session.user.id;
   const cols='id,room_id,caller_id,callee_id,mode,status,started_at,answered_at,ended_at,duration_seconds,caller:profiles!call_logs_caller_id_fkey(id,username,display_name,avatar_url),callee:profiles!call_logs_callee_id_fkey(id,username,display_name,avatar_url)';
   const {data,error}=await sb.from('call_logs').select(cols).order('started_at',{ascending:false}).limit(300);
   if(error)throw error;logs=data||[];renderStats();render();
  }catch(err){
   console.warn('[calls]',err);const missing=/42P01|PGRST205|does not exist|schema cache/i.test(`${err.code||''} ${err.message||''}`);
   $('calls-list').innerHTML=`<div class="calls-empty"><i class="fa-solid fa-triangle-exclamation"></i><p>${missing?'Fitur log panggilan belum aktif di database.':'Riwayat panggilan belum bisa dimuat.'}</p><small>${missing?'Jalankan SQL bagian 7 (NDIFLYCHAT-UPDATE-7-CALL-LOGS.sql) di Supabase SQL Editor, lalu muat ulang.':esc(err.message||'Coba lagi sebentar lagi.')}</small></div>`;
  }
 }
 document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible'&&me)load();});
 load();
})();
