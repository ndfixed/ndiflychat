/* ndiflyChat · Liquid Glass Dock
   Tambahan untuk <nav class="ios-dock">. Tidak mengubah tautan, tombol, id, maupun handler yang sudah ada.
   1) "Lensa" kaca yang meluncur ke item aktif (dengan efek jelly).
   2) Tap pada menu lain: lensa meluncur dulu (~130 ms), baru menu dibuka lewat klik asli.
   3) Tekan lama lalu geser lensa ke menu di sebelahnya, lepas untuk memilih.
   4) Ikon garis minimalis (ikon Font Awesome tetap jadi cadangan).
   5) Chromium: pembiasan tepi kaca lewat filter SVG (progressive enhancement). */
(() => {
  'use strict';

  const root = document.documentElement;
  const TAP_DELAY = 150;   // jeda agar luncuran lensa terlihat sebelum pindah halaman
  const HOLD_MS = 380;     // lama tekan sebelum mode geser aktif
  const SLOP = 10;         // toleransi gerak (px) sebelum tekan lama dibatalkan

  const motionOn = () =>
    root.dataset.perf !== 'lite' && !(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

  // Ikon garis 24x24 (gaya Lucide). Kunci = kelas Font Awesome yang dipakai di markup dock.
  const ICONS = {
    'fa-message': '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    'fa-circle-info': '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/>',
    'fa-phone-volume': '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
    'fa-sliders': '<path d="M21 4h-7"/><path d="M10 4H3"/><path d="M21 12h-9"/><path d="M8 12H3"/><path d="M21 20h-5"/><path d="M12 20H3"/><path d="M14 2v4"/><path d="M8 10v4"/><path d="M16 18v4"/>',
    'fa-circle-dot': '<circle cx="12" cy="12" r="9" stroke-dasharray="3.2 3.2"/><circle cx="12" cy="12" r="3.2"/>'
  };

  function swapIcons(nav) {
    nav.querySelectorAll('.dock-icon > i').forEach(icon => {
      const key = Object.keys(ICONS).find(cls => icon.classList.contains(cls));
      if (!key) return; // ikon yang tidak dikenal dibiarkan apa adanya
      const tpl = document.createElement('template');
      tpl.innerHTML = '<svg class="dock-svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false">' + ICONS[key] + '</svg>';
      icon.replaceWith(tpl.content.firstElementChild);
    });
  }

  /* ---------- Pembiasan tepi (Chromium saja) ----------
     Peta perpindahan dilukis di canvas: di dalam "bezel" tepi pill, piksel mengambil warna dari
     titik yang lebih ke dalam, sehingga isi di belakang dock tampak melengkung di pinggir seperti kaca tebal.
     Browser lain (Safari, Firefox) melewati bagian ini dan tetap memakai blur biasa. */
  const isChromium = () => {
    try {
      const brands = navigator.userAgentData && navigator.userAgentData.brands;
      return !!brands && brands.some(b => /Chromium/i.test(b.brand));
    } catch (_) { return false; }
  };

  function setupRefraction(nav) {
    if (!isChromium() || root.dataset.perf === 'lite') return;
    const NS = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('width', '0');
    svg.setAttribute('height', '0');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('focusable', 'false');
    svg.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;pointer-events:none';
    svg.innerHTML = '<filter id="dg-refract" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB">' +
      '<feImage x="0" y="0" width="1" height="1" preserveAspectRatio="none" result="map"/>' +
      '<feDisplacementMap in="SourceGraphic" in2="map" scale="34" xChannelSelector="R" yChannelSelector="G"/></filter>';
    document.body.appendChild(svg);
    const feImage = svg.querySelector('feImage');

    let lw = 0, lh = 0;
    const build = () => {
      const w = nav.offsetWidth, h = nav.offsetHeight;
      if (!w || !h || (w === lw && h === lh)) return;
      lw = w; lh = h;
      try {
        const c = document.createElement('canvas');
        c.width = w; c.height = h;
        const ctx = c.getContext('2d');
        const img = ctx.createImageData(w, h);
        const d = img.data;
        const r = h / 2, bezel = Math.min(r, 18);
        for (let y = 0; y < h; y++) {
          for (let x = 0; x < w; x++) {
            const px = x + .5, py = y + .5;
            const cx = Math.min(Math.max(px, r), w - r);     // titik terdekat pada garis tengah kapsul
            const dx = px - cx, dy = py - r;
            const dist = Math.hypot(dx, dy);
            const depth = r - dist;                           // jarak ke tepi, makin dalam makin besar
            let mx = 0, my = 0;
            if (depth >= 0 && dist > 0.001) {
              const m = Math.pow(1 - Math.min(depth / bezel, 1), 2.4);
              mx = -dx / dist * m;                            // arah ke dalam
              my = -dy / dist * m;
            }
            const i = (y * w + x) * 4;
            d[i] = 128 + mx * 127;
            d[i + 1] = 128 + my * 127;
            d[i + 2] = 128;
            d[i + 3] = 255;
          }
        }
        ctx.putImageData(img, 0, 0);
        const url = c.toDataURL('image/png');
        feImage.setAttribute('href', url);
        feImage.setAttributeNS('http://www.w3.org/1999/xlink', 'href', url);
        feImage.setAttribute('width', w);
        feImage.setAttribute('height', h);
        nav.classList.add('dg-refract');
      } catch (_) {
        nav.classList.remove('dg-refract');
      }
    };
    build();
    let raf = 0;
    const later = () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(build); };
    if ('ResizeObserver' in window) new ResizeObserver(later).observe(nav);
    window.addEventListener('resize', later, { passive: true });
  }

  /* ---------- Lensa + gestur ---------- */
  function setup(nav) {
    if (nav.dataset.dockGlass) return;
    nav.dataset.dockGlass = '1';
    swapIcons(nav);

    const lens = document.createElement('span');
    lens.className = 'dock-lens no-anim';
    lens.setAttribute('aria-hidden', 'true');
    nav.prepend(lens);

    // state bersama (didefinisikan lebih awal karena dipakai refresh)
    const drag = { on: false, timer: 0, id: null, x0: 0, y0: 0, item: null, target: null, w: 0, justDragged: false };
    const tap = { pending: false, replay: false };
    let lastX = null;

    const items = () => [...nav.querySelectorAll('.ios-dock-item')];
    const measure = () => {
      const active = nav.querySelector('.ios-dock-item.active');
      if (!active || !nav.offsetWidth) return null;
      return { x: active.offsetLeft, w: active.offsetWidth };
    };
    const jelly = () => {
      lens.classList.remove('is-moving');
      void lens.offsetWidth;            // mulai ulang animasi
      lens.classList.add('is-moving');
    };
    lens.addEventListener('animationend', () => lens.classList.remove('is-moving'));

    const place = (x, w, animate) => {
      // jaga lensa tetap di dalam pill (tidak pernah melewati item pertama/terakhir)
      const all = items();
      if (all.length) {
        const first = all[0], last = all[all.length - 1];
        x = Math.max(first.offsetLeft, Math.min(x, last.offsetLeft + last.offsetWidth - w));
      }
      if (!animate || !motionOn()) lens.classList.add('no-anim');
      else if (lastX !== null && Math.abs(x - lastX) > 4) jelly();
      lens.style.setProperty('--lens-x', x + 'px');
      lens.style.setProperty('--lens-w', w + 'px');
      lens.classList.add('is-ready');
      nav.classList.add('has-lens');
      lastX = x;
      if (lens.classList.contains('no-anim')) { void lens.offsetWidth; lens.classList.remove('no-anim'); }
    };
    const refresh = (animate) => {
      if (drag.on || tap.pending) return; // lensa sedang dipegang jari atau menunggu pindah halaman
      const m = measure();
      if (!m) { lens.classList.remove('is-ready'); return; }
      place(m.x, m.w, animate);
    };

    // Posisi awal: langsung di item aktif, tanpa animasi (kapsul cadangan CSS identik, jadi tidak ada kedipan).
    refresh(false);

    // Item aktif berubah (mis. klik "Chat" di halaman chat): lensa meluncur.
    let raf = 0;
    const later = (animate) => { cancelAnimationFrame(raf); raf = requestAnimationFrame(() => refresh(animate)); };
    const mo = new MutationObserver(() => later(true));
    nav.querySelectorAll('.ios-dock-item').forEach(el => mo.observe(el, { attributes: true, attributeFilter: ['class'] }));

    // Ukuran berubah (rotasi layar, font selesai dimuat, resize): pindah tanpa animasi.
    if ('ResizeObserver' in window) new ResizeObserver(() => later(false)).observe(nav);
    window.addEventListener('resize', () => later(false), { passive: true });
    window.addEventListener('load', () => later(false));
    window.addEventListener('pageshow', e => { if (e.persisted) { tap.pending = false; later(false); } });
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => later(false)).catch(() => {});

    // Loading screen terangkat: ukur ulang (dock baru terlihat saat itu).
    if (root.classList.contains('is-loading')) {
      const lift = new MutationObserver(() => {
        if (!root.classList.contains('is-loading')) { lift.disconnect(); later(false); }
      });
      lift.observe(root, { attributes: true, attributeFilter: ['class'] });
    }

    /* Memilih menu lewat klik asli, setelah lensa sempat meluncur. */
    const activate = (item) => {
      tap.pending = true;
      place(item.offsetLeft, item.offsetWidth, true);
      setTimeout(() => {
        tap.replay = true;
        try { item.click(); } finally { tap.replay = false; }
        // bila tidak pindah halaman (aksi di halaman yang sama), kembali sinkron dengan item aktif
        setTimeout(() => { tap.pending = false; refresh(true); }, 900);
      }, motionOn() ? TAP_DELAY : 0);
    };

    nav.addEventListener('click', e => {
      if (tap.replay) return;                                   // klik ulang milik kita sendiri: biarkan lewat
      if (drag.justDragged || tap.pending) { e.preventDefault(); e.stopImmediatePropagation(); return; }
      if (e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
      const item = e.target.closest && e.target.closest('.ios-dock-item');
      if (!item || !nav.contains(item) || item.classList.contains('active')) return;
      if (!motionOn()) return;                                  // tanpa animasi: perilaku asli
      e.preventDefault();
      e.stopImmediatePropagation();
      activate(item);
    }, true);

    /* ----- Tekan lama, lalu geser lensa ke menu di sebelahnya (seperti tab bar iOS 26) ----- */
    const buzz = (ms) => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) { /* tidak didukung */ } };
    const nearest = (cx) => items().reduce((best, el) => {
      const d = Math.abs(el.offsetLeft + el.offsetWidth / 2 - cx);
      return !best || d < best.d ? { el, d } : best;
    }, null).el;
    const setTarget = (el) => {
      if (drag.target === el) return;
      items().forEach(i => (i === el ? i.setAttribute('data-dock-target', '') : i.removeAttribute('data-dock-target')));
      drag.target = el;
      buzz(6);
    };
    const begin = () => {
      drag.timer = 0;
      drag.on = true;
      drag.target = null;
      nav.classList.add('is-dragging');
      try { nav.setPointerCapture(drag.id); } catch (_) { /* pointer sudah hilang */ }
      const it = drag.item;
      drag.w = it.offsetWidth;
      place(it.offsetLeft, it.offsetWidth, true);
      lens.classList.add('is-grab');
      setTarget(it);
      buzz(12);
    };
    const end = (commit) => {
      clearTimeout(drag.timer);
      drag.timer = 0;
      if (!drag.on) return;
      const t = drag.target || drag.item;
      drag.on = false;
      lens.classList.remove('is-drag', 'is-grab');
      nav.classList.remove('is-dragging');
      try { nav.releasePointerCapture(drag.id); } catch (_) { /* sudah dilepas */ }
      items().forEach(i => i.removeAttribute('data-dock-target'));
      drag.justDragged = true; // klik bawaan setelah lepas jari diabaikan; kita yang memicu klik tujuan
      setTimeout(() => { drag.justDragged = false; }, 450);
      const active = nav.querySelector('.ios-dock-item.active');
      if (commit && t && t !== active) {
        place(t.offsetLeft, t.offsetWidth, true);                // lensa meluncur ke tujuan
        tap.pending = true;
        setTimeout(() => {
          drag.justDragged = false;
          tap.replay = true;
          try { t.click(); } finally { tap.replay = false; }
          setTimeout(() => { tap.pending = false; refresh(true); }, 900);
        }, 170);
      } else if (active) {
        place(active.offsetLeft, active.offsetWidth, true);      // batal: kembali ke menu aktif
      }
    };

    nav.addEventListener('pointerdown', e => {
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      const item = e.target.closest && e.target.closest('.ios-dock-item');
      if (!item || !nav.contains(item) || tap.pending) return;
      clearTimeout(drag.timer);
      drag.id = e.pointerId; drag.x0 = e.clientX; drag.y0 = e.clientY; drag.item = item;
      drag.timer = setTimeout(begin, HOLD_MS);
    });
    nav.addEventListener('pointermove', e => {
      if (e.pointerId !== drag.id) return;
      if (!drag.on) {
        // bergeser sebelum tahan cukup lama = bukan tekan lama, batalkan
        if (drag.timer && Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0) > SLOP) { clearTimeout(drag.timer); drag.timer = 0; }
        return;
      }
      e.preventDefault();
      const list = items(), last = list[list.length - 1];
      const minX = list[0].offsetLeft, maxX = last.offsetLeft + last.offsetWidth - drag.w;
      const r = nav.getBoundingClientRect();
      const x = Math.max(minX, Math.min(maxX, e.clientX - r.left - nav.clientLeft - drag.w / 2));
      lens.classList.add('is-drag');
      lens.style.setProperty('--lens-x', x + 'px');
      lens.style.setProperty('--lens-w', drag.w + 'px');
      lastX = x;
      setTarget(nearest(x + drag.w / 2));
    });
    nav.addEventListener('pointerup', e => { if (e.pointerId === drag.id) { clearTimeout(drag.timer); end(true); } });
    nav.addEventListener('pointercancel', e => { if (e.pointerId === drag.id) { clearTimeout(drag.timer); end(false); } });
    window.addEventListener('blur', () => end(false));
    nav.addEventListener('contextmenu', e => { if (drag.timer || drag.on) e.preventDefault(); });
    nav.addEventListener('dragstart', e => e.preventDefault());

    /* ----- Kilau kaca: sekali saat muncul dan saat berganti menu (bukan loop tak berujung) ----- */
    const shine = () => {
      if (!motionOn()) return;
      nav.classList.remove('dg-shine');
      void nav.offsetWidth;
      nav.classList.add('dg-shine');
    };
    nav.addEventListener('animationend', e => { if (e.target === nav && e.animationName === 'dg-sheen') nav.classList.remove('dg-shine'); });
    const afterLoad = () => setTimeout(shine, 650);
    if (root.classList.contains('is-loading')) {
      const lift = new MutationObserver(() => { if (!root.classList.contains('is-loading')) { lift.disconnect(); afterLoad(); } });
      lift.observe(root, { attributes: true, attributeFilter: ['class'] });
    } else afterLoad();
    const shineMo = new MutationObserver(shine);
    nav.querySelectorAll('.ios-dock-item').forEach(el => shineMo.observe(el, { attributes: true, attributeFilter: ['class'] }));

    /* ----- Mode ringkas ala iOS 26: dock menyusut saat menggulir ke bawah, kembali saat menggulir ke atas ----- */
    if (!document.body.classList.contains('chat-body')) {
      const lastY = new WeakMap();
      let acc = 0, small = false;
      const setSmall = (v) => {
        if (v === small || drag.on || tap.pending) return;
        small = v;
        nav.classList.toggle('is-min', v);
      };
      document.addEventListener('scroll', e => {
        const t = e.target === document ? document.scrollingElement : e.target;
        if (!(t instanceof Element) || nav.contains(t)) return;
        if (t.scrollHeight - t.clientHeight < 220) return;      // bukan area gulir utama
        const y = t.scrollTop, prev = lastY.get(t);
        lastY.set(t, y);
        if (prev === undefined) return;
        if (y < 24) { acc = 0; setSmall(false); return; }
        const dy = y - prev;
        if ((dy > 0 && acc < 0) || (dy < 0 && acc > 0)) acc = 0;
        acc += dy;
        if (acc > 44) setSmall(true);
        else if (acc < -28) setSmall(false);
      }, { capture: true, passive: true });
      nav.addEventListener('pointerdown', () => { acc = 0; setSmall(false); }, { passive: true });
    }

    setupRefraction(nav);
  }

  // Skrip ini diletakkan tepat setelah markup dock, jadi nav sudah ada: langsung pasang tanpa menunggu
  // DOMContentLoaded (yang bisa tertahan oleh library CDN). setup() aman dipanggil ulang.
  const init = () => document.querySelectorAll('nav.ios-dock').forEach(setup);
  init();
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
})();
