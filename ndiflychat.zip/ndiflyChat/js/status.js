/* ndiflyChat ephemeral Status. Uses existing username-only Supabase session. */
(()=>{
 const sb=window.ndiflySupabase;
 if(!sb){const l=document.getElementById('status-list');if(l&&document.body.classList.contains('status-page-body'))l.innerHTML='<div class="st-empty"><i class="fa-solid fa-wifi"></i><p>Status belum bisa dimuat.<br>Periksa koneksi internet lalu muat ulang.</p></div>';return;}
 const $=id=>document.getElementById(id), MAX=2*1024*1024;
 let current=[], viewerIndex=0, meProfile=null, seenDirty=false;
 const isPage=document.body.classList.contains('status-page-body');
 /* Status yang sudah dilihat disimpan per akun di perangkat ini (hanya untuk cincin avatar, bukan data penting). */
 const seenKey=()=>`ndifly_status_seen:${window.ndiflyCurrentUserId||'anon'}`;
 let seenCache=null;
 const seenSet=()=>{if(seenCache)return seenCache;try{seenCache=new Set(JSON.parse(localStorage.getItem(seenKey())||'[]'));}catch(_){seenCache=new Set();}return seenCache;};
 const saveSeen=()=>{try{localStorage.setItem(seenKey(),JSON.stringify([...seenSet()].slice(-400)));}catch(_){}};
 const markSeen=id=>{const set=seenSet();if(id&&!set.has(id)){set.add(id);seenDirty=true;saveSeen();}};
 const pruneSeen=()=>{const set=seenSet(),live=new Set(current.map(x=>x.id));let ch=false;[...set].forEach(id=>{if(!live.has(id)){set.delete(id);ch=true;}});if(ch)saveSeen();};
 const isSeen=id=>seenSet().has(id);
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let toastT=0;const toast=(m)=>{const t=$('toast');if(t){t.textContent=m;t.className='toast show';clearTimeout(toastT);toastT=setTimeout(()=>t.className='toast',3000);}};
 const formatAge=d=>{const stamp=Date.parse(d);if(!Number.isFinite(stamp))return 'Baru saja';const m=Math.max(0,Math.floor((Date.now()-stamp)/60000));return m<1?'Baru saja':m<60?`${m} mnt lalu`:`${Math.floor(m/60)} jam lalu`;};
 async function compressImage(file){
  const bmp=await createImageBitmap(file);let w=bmp.width,h=bmp.height,scale=Math.min(1,1920/Math.max(w,h));w=Math.round(w*scale);h=Math.round(h*scale);
  const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;const ctx=canvas.getContext('2d');ctx.drawImage(bmp,0,0,w,h);bmp.close();
  for(let q=.86;q>=.35;q-=.1){const blob=await new Promise(r=>canvas.toBlob(r,'image/webp',q));if(blob&&blob.size<=MAX)return new File([blob],`status-${Date.now()}.webp`,{type:'image/webp'});}
  throw Error('Foto masih lebih dari 2 MB setelah kompresi. Pilih foto lain.');
 }
 async function compressVideo(file){
  const safeOriginal=['video/mp4','video/webm'].includes(file.type);
  if(file.size<=MAX&&safeOriginal)return file;
  const canCapture=HTMLCanvasElement.prototype.captureStream;
  const captureVideo=HTMLVideoElement.prototype.captureStream||HTMLVideoElement.prototype.mozCaptureStream;
  if(!window.MediaRecorder||!canCapture||!captureVideo)throw Error('Browser ini belum mendukung kompresi video. Gunakan video MP4/WebM maksimal 2 MB.');
  const url=URL.createObjectURL(file),video=document.createElement('video');
  let canvasStream=null,sourceStream=null,recorder=null,raf=0,timeout=0;
  try{
    video.src=url;video.muted=true;video.playsInline=true;video.preload='auto';
    await new Promise((resolve,reject)=>{
      if(video.readyState>=1)return resolve();
      video.addEventListener('loadedmetadata',resolve,{once:true});
      video.addEventListener('error',()=>reject(Error('Video tidak dapat dibaca oleh browser ini.')),{once:true});
    });
    if(!video.videoWidth||!video.videoHeight)throw Error('Resolusi video tidak valid.');
    const ratio=Math.min(1,720/Math.max(video.videoWidth,video.videoHeight));
    const canvas=document.createElement('canvas');canvas.width=Math.max(2,Math.round(video.videoWidth*ratio));canvas.height=Math.max(2,Math.round(video.videoHeight*ratio));
    const ctx=canvas.getContext('2d');if(!ctx)throw Error('Kompresi video tidak didukung perangkat ini.');
    sourceStream=video.captureStream?video.captureStream():video.mozCaptureStream();
    canvasStream=canvas.captureStream(20);
    sourceStream.getAudioTracks().forEach(track=>canvasStream.addTrack(track));
    const mime=['video/webm;codecs=vp8,opus','video/webm;codecs=vp8','video/webm'].find(type=>MediaRecorder.isTypeSupported(type));
    if(!mime)throw Error('Browser ini tidak mendukung format WebM untuk kompresi video.');
    const chunks=[];
    const finished=new Promise((resolve,reject)=>{
      recorder=new MediaRecorder(canvasStream,{mimeType:mime,videoBitsPerSecond:380000,audioBitsPerSecond:48000});
      recorder.ondataavailable=event=>{if(event.data?.size)chunks.push(event.data);};
      recorder.onerror=event=>reject(event.error||Error('Proses kompresi video gagal.'));
      recorder.onstop=()=>resolve(new Blob(chunks,{type:mime}));
    });
    finished.catch(()=>{});
    const ended=new Promise((resolve,reject)=>{
      video.addEventListener('ended',resolve,{once:true});
      video.addEventListener('error',()=>reject(Error('Video berhenti saat dikompres.')),{once:true});
      timeout=setTimeout(()=>reject(Error('Kompresi video terlalu lama. Pilih video yang lebih pendek.')),120000);
    });
    recorder.start(250);
    await video.play();
    const draw=()=>{
      if(video.ended||video.paused)return;
      try{ctx.drawImage(video,0,0,canvas.width,canvas.height);}catch(_){}
      raf=requestAnimationFrame(draw);
    };
    draw();
    await ended;
    clearTimeout(timeout);timeout=0;
    if(recorder.state==='recording')recorder.stop();
    const blob=await finished;
    if(blob.size>MAX)throw Error('Video masih lebih dari 2 MB setelah kompresi. Potong durasi atau pilih video lebih pendek.');
    return new File([blob],`status-${Date.now()}.webm`,{type:'video/webm'});
  }catch(error){
    if(recorder&&recorder.state==='recording'){try{recorder.stop();}catch(_){}}
    throw error;
  }finally{
    clearTimeout(timeout);if(raf)cancelAnimationFrame(raf);
    try{video.pause();}catch(_){}
    [canvasStream,sourceStream].filter(Boolean).forEach(stream=>stream.getTracks().forEach(track=>track.stop()));
    video.remove();URL.revokeObjectURL(url);
  }
 }
 async function loadStatuses(){
  try{
  const auth=await sb.auth.getUser();if(auth.error)throw auth.error;window.ndiflyCurrentUserId=auth.data?.user?.id||null;if(!window.ndiflyCurrentUserId)return;const {data,error}=await sb.from('user_status').select('id,user_id,media_path,media_type,caption,created_at,expires_at').order('created_at',{ascending:false});
  if(error){console.warn('[status]',error);if(/42P01|PGRST205|does not exist|schema cache/i.test(`${error.code||''} ${error.message||''}`))window.ndiflyDbNotice?.('fitur status');const l=$('status-list');if(isPage&&l)l.innerHTML='<div class="st-empty"><i class="fa-solid fa-triangle-exclamation"></i><p>Status belum bisa dimuat.<br>Coba lagi sebentar lagi.</p></div>';return;}current=data||[];const ids=[...new Set([window.ndiflyCurrentUserId,...current.map(x=>x.user_id)])];if(ids.length){const p=await sb.from('profiles').select('id,username,display_name,avatar_url').in('id',ids);if(!p.error){const map=new Map((p.data||[]).map(x=>[x.id,x]));meProfile=map.get(window.ndiflyCurrentUserId)||meProfile;current=current.map(x=>({...x,profiles:map.get(x.user_id)||{}}));}}pruneSeen();renderStatuses();
  }catch(error){console.warn('[status load]',error);}
 }
 function renderStrip(){const list=$('status-list');if(!list)return;const grouped=new Map();current.forEach(s=>{const k=s.user_id;if(!grouped.has(k))grouped.set(k,[]);grouped.get(k).push(s);});const me=window.ndiflyCurrentUserId;
  list.innerHTML=`<button class="status-add" id="status-add"><span class="status-avatar"><i class="fa-solid fa-plus"></i></span><b>Tambah</b><small>Tambahkan</small></button>`+[...grouped.entries()].map(([uid,items])=>{const p=items[0].profiles||{},mine=uid===me;return `<button class="status-person" data-status-user="${esc(uid)}"><span class="status-ring"><span class="status-avatar">${p.avatar_url?`<img src="${esc(p.avatar_url)}" alt="">`:esc((p.username||'?')[0].toUpperCase())}</span></span><b>${mine?'Status saya':`@${esc(p.username||'pengguna')}`}</b><small>${items.length} status · ${formatAge(items[0].created_at)}</small></button>`;}).join('');
  $('status-add')?.addEventListener('click',()=> $('status-file')?.click());list.querySelectorAll('[data-status-user]').forEach(b=>b.addEventListener('click',()=>openViewer(b.dataset.statusUser)));
 }

 /* ===== Halaman Status (status.html): Status Saya + Pembaruan terkini ===== */
 const fmtStamp=d=>{const t=new Date(d);if(!Number.isFinite(+t))return 'Baru saja';const now=new Date(),day=x=>new Date(x.getFullYear(),x.getMonth(),x.getDate()).getTime(),diff=Math.round((day(now)-day(t))/86400000),clock=fmtClock(d);return diff<=0?`Hari ini, ${clock}`:diff===1?`Kemarin, ${clock}`:`${t.toLocaleDateString('id-ID',{day:'numeric',month:'short'})}, ${clock}`;};
 const ringStyle=flags=>{const n=flags.length;if(n<2)return '';const gap=n>8?3:7,seg=360/n,parts=[];let pos=0;flags.forEach((seen,i)=>{const a=+(i*seg+gap/2).toFixed(2),b=+((i+1)*seg-gap/2).toFixed(2);parts.push(`transparent ${pos}deg ${a}deg`,`${seen?'rgba(255,255,255,.26)':'#5b8cff'} ${a}deg ${b}deg`);pos=b;});parts.push(`transparent ${pos}deg 360deg`);return `--ring:conic-gradient(from 0deg,${parts.join(',')})`;};
 const avatarHtml=(p,name)=>p?.avatar_url?`<img src="${esc(p.avatar_url)}" alt="" loading="lazy">`:`<span class="st-initial">${esc((name||'?').charAt(0).toUpperCase())}</span>`;
 const personName=p=>p?.display_name||p?.username||'Pengguna';
 function renderPage(){
  const list=$('status-list'),meEl=$('status-me');if(!list||!meEl)return;
  const me=window.ndiflyCurrentUserId,grouped=new Map();
  [...current].sort((a,b)=>Date.parse(a.created_at)-Date.parse(b.created_at)).forEach(s=>{if(!grouped.has(s.user_id))grouped.set(s.user_id,[]);grouped.get(s.user_id).push(s);});
  /* --- Status Saya --- */
  const mine=grouped.get(me)||[],mp=mine[0]?.profiles||meProfile||{},mname=personName(mp);
  const myLatest=mine[mine.length-1];
  const mySub=mine.length?`${mine.length} status · ${fmtStamp(myLatest.created_at)}`:'Ketuk untuk menambahkan pembaruan status';
  meEl.innerHTML=`<button class="st-me-main" id="status-add" type="button" aria-label="${mine.length?'Lihat status saya':'Tambahkan status saya'}" ${mine.length?`data-status-user="${esc(me)}"`:''}><span class="st-ring st-ring-me" style="${mine.length>1?ringStyle(mine.map(()=>false)):''}"><span class="st-ava">${avatarHtml(mp,mname)}</span><span class="st-plus" aria-hidden="true"><i class="fa-solid fa-plus"></i></span></span><span class="st-text"><b>Status Saya</b><small>${esc(mySub)}</small></span></button>${mine.length?'<button class="st-add-more" id="status-add-more" type="button" aria-label="Tambah status baru"><i class="fa-solid fa-plus"></i></button>':''}`;
  /* --- Pembaruan terkini: yang belum dilihat dulu, lalu yang terbaru --- */
  const others=[...grouped.entries()].filter(([uid])=>uid!==me).map(([uid,items])=>({uid,items,p:items[0].profiles||{},unseen:items.filter(x=>!isSeen(x.id)).length,latest:items[items.length-1]}));
  others.sort((a,b)=>(!!b.unseen-!!a.unseen)||Date.parse(b.latest.created_at)-Date.parse(a.latest.created_at));
  list.innerHTML=others.length?others.map(o=>{const nm=personName(o.p),flags=o.items.map(x=>isSeen(x.id));return `<div class="st-item ${o.unseen?'is-unread':'is-seen'}"><button class="st-item-main" type="button" data-status-user="${esc(o.uid)}" aria-label="Lihat status ${esc(nm)}"><span class="st-ring ${o.unseen?'':'is-seen'}" style="${ringStyle(flags)}${o.unseen?'':';--ring:conic-gradient(rgba(255,255,255,.26),rgba(255,255,255,.26))'}"><span class="st-ava">${avatarHtml(o.p,nm)}</span></span><span class="st-text"><b>${esc(nm)}</b><small>${esc(fmtStamp(o.latest.created_at))}</small></span></button></div>`;}).join(''):'<div class="st-empty"><i class="fa-regular fa-circle-dot"></i><p>Belum ada pembaruan dari pengguna lain.<br>Status baru akan muncul di sini.</p></div>';
  $('status-add')?.addEventListener('click',e=>{const uid=e.currentTarget.dataset.statusUser;if(uid)openViewer(uid);else $('status-file')?.click();});
  $('status-add-more')?.addEventListener('click',()=>$('status-file')?.click());
  list.querySelectorAll('[data-status-user]').forEach(b=>b.addEventListener('click',()=>openViewer(b.dataset.statusUser)));
 }
 function renderStatuses(){if(isPage)renderPage();else renderStrip();}
 async function publish(file,caption=''){const auth=await sb.auth.getUser();if(auth.error)throw auth.error;const user=auth.data?.user;if(!user)throw Error('Sesi login berakhir.');let output=file;
  if(file.type.startsWith('image/'))output=await compressImage(file);else if(file.type.startsWith('video/'))output=await compressVideo(file);else throw Error('Pilih foto atau video.');
  if(output.size>MAX)throw Error('Ukuran media harus maksimal 2 MB.');const ext=output.type==='image/webp'?'webp':output.type==='video/webm'?'webm':output.type.split('/')[1];const path=`${user.id}/${crypto.randomUUID()}.${ext}`;
  const up=await sb.storage.from('chat-status').upload(path,output,{contentType:output.type,upsert:false});if(up.error)throw up.error;
  const ins=await sb.from('user_status').insert({user_id:user.id,media_path:path,media_type:output.type.startsWith('video/')?'video':'image',caption:String(caption||'').trim().slice(0,180)});if(ins.error){await sb.storage.from('chat-status').remove([path]);throw ins.error;}toast('Status berhasil dibagikan · berlaku 24 jam.');await loadStatuses();
 }
 /* ===== Editor: full-screen preview + caption + audience + send (WhatsApp style) ===== */
 const AUD=[{id:'all',icon:'fa-earth-asia',label:'Semua pengguna',ok:true},{id:'close',icon:'fa-star',label:'Teman dekat',ok:false},{id:'private',icon:'fa-lock',label:'Hanya saya',ok:false}];
 let editor=null;
 function closeEditor(){if(!editor)return;editor.el.querySelectorAll('video').forEach(v=>{v.pause();v.removeAttribute('src');v.load();});editor.el.remove();URL.revokeObjectURL(editor.url);editor=null;document.documentElement.classList.remove('sx-lock');}
 function openEditor(file){
  if(!/^(image|video)\//.test(file.type)){toast('Pilih foto atau video.');return;}
  closeEditor();closeViewer();
  const url=URL.createObjectURL(file),isVid=file.type.startsWith('video/'),el=document.createElement('div');
  el.className='se';el.setAttribute('role','dialog');el.setAttribute('aria-label','Buat status');
  el.innerHTML=`<div class="se-media">${isVid?`<video src="${url}" autoplay muted loop playsinline></video>`:`<img src="${url}" alt="Pratinjau status">`}</div>
  <div class="se-top"><button type="button" class="se-round" data-se="close" aria-label="Batal"><i class="fa-solid fa-xmark"></i></button><span class="se-hint"><i class="fa-regular fa-clock"></i> Hilang dalam 24 jam</span></div>
  <div class="se-bottom"><label class="se-caption"><i class="fa-regular fa-image"></i><input id="se-caption" maxlength="180" placeholder="Tambahkan keterangan…" autocomplete="off"><em id="se-count">0</em></label>
  <div class="se-row"><button type="button" class="se-audience" data-se="audience"><i class="fa-solid fa-earth-asia"></i><span>Status (Semua pengguna)</span></button><button type="button" class="se-send" data-se="send" aria-label="Bagikan status"><i class="fa-solid fa-paper-plane"></i></button></div></div>
  <div class="se-sheet hidden" id="se-sheet"><div class="se-sheet-card"><b>Siapa yang bisa melihat status?</b><p>Pengaturan privasi global masih dalam pengembangan. Untuk saat ini status terlihat oleh semua pengguna.</p>${AUD.map(a=>`<button type="button" class="se-opt ${a.ok?'on':''}" ${a.ok?'':'disabled'}><i class="fa-solid ${a.icon}"></i><span>${a.label}</span>${a.ok?'<i class="fa-solid fa-circle-check se-check"></i>':'<small>Masih pengembangan</small>'}</button>`).join('')}<button type="button" class="se-done" data-se="sheet-close">Selesai</button></div></div>`;
  document.body.appendChild(el);document.documentElement.classList.add('sx-lock');editor={el,url,file,busy:false};
  const input=el.querySelector('#se-caption'),sheet=el.querySelector('#se-sheet');
  input.addEventListener('input',()=>{el.querySelector('#se-count').textContent=String(input.value.length);});
  el.addEventListener('click',async e=>{
   if(e.target===sheet){sheet.classList.add('hidden');return;}
   const act=e.target.closest('[data-se]')?.dataset.se;if(!act||!editor||editor.busy)return;
   if(act==='close')closeEditor();
   else if(act==='audience')sheet.classList.remove('hidden');
   else if(act==='sheet-close')sheet.classList.add('hidden');
   else if(act==='send'){
    editor.busy=true;el.classList.add('busy');el.querySelector('.se-send i').className='fa-solid fa-spinner fa-spin';
    try{toast(isVid?'Memproses video…':'Mengunggah…');await publish(file,input.value);closeEditor();}
    catch(err){console.error('[status upload]',err);toast(err.message||'Gagal mengunggah status.');if(editor){editor.busy=false;el.classList.remove('busy');el.querySelector('.se-send i').className='fa-solid fa-paper-plane';}}
   }
  });
 }
 /* ===== Viewer: segmented progress, tap zones, hold to pause, swipe down to close (Telegram/IG style) ===== */
 const IMG_MS=6000;let sv=null;
 const userItems=uid=>current.filter(s=>s.user_id===uid).sort((a,b)=>Date.parse(a.created_at)-Date.parse(b.created_at));
 const userOrder=()=>{const me=window.ndiflyCurrentUserId,ids=[...new Set(current.map(s=>s.user_id))].filter(u=>u!==me);if(isPage)ids.sort((a,b)=>{const ua=userItems(a).some(x=>!isSeen(x.id)),ub=userItems(b).some(x=>!isSeen(x.id));return (ub-ua)||Date.parse(userItems(b).slice(-1)[0].created_at)-Date.parse(userItems(a).slice(-1)[0].created_at);});return ids;};
 function closeViewer(){if(!sv)return;cancelAnimationFrame(sv.raf);sv.token++;sv.el.querySelectorAll('video').forEach(v=>{v.pause();v.removeAttribute('src');v.load();});sv.el.remove();sv=null;document.documentElement.classList.remove('sx-lock');if(seenDirty){seenDirty=false;renderStatuses();}}
 const fmtClock=d=>{const t=new Date(d);return Number.isFinite(+t)?t.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}).replace(':','.'):'';};
 async function openViewer(uid,startIdx=0){
  const items=userItems(uid);if(!items.length)return;closeEditor();closeViewer();
  const p=items[0].profiles||{},name=personName(p),mine=uid===window.ndiflyCurrentUserId,el=document.createElement('div');
  el.className='sv';el.setAttribute('role','dialog');el.setAttribute('aria-label','Lihat status');
  el.innerHTML=`<div class="sv-card"><div class="sv-bg"></div><div class="sv-media" id="sv-media"></div><div class="sv-spin"><i class="fa-solid fa-spinner fa-spin"></i></div>
  <button type="button" class="sv-zone sv-prev" aria-label="Sebelumnya"></button><button type="button" class="sv-zone sv-next" aria-label="Berikutnya"></button>
  <div class="sv-top"><div class="sv-bars">${items.map(()=>'<span class="sv-seg"><i></i></span>').join('')}</div>
  <div class="sv-head"><span class="sv-ava">${p.avatar_url?`<img src="${esc(p.avatar_url)}" alt="">`:esc(name.charAt(0).toUpperCase())}</span><div class="sv-who"><b>${esc(mine?'Status saya':name)}</b><small id="sv-time"></small></div>
  <button type="button" class="sv-ic hidden" id="sv-mute" aria-label="Suara"><i class="fa-solid fa-volume-high"></i></button>${mine?'<button type="button" class="sv-ic" id="sv-del" aria-label="Hapus status"><i class="fa-regular fa-trash-can"></i></button>':''}<button type="button" class="sv-ic" id="sv-close" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button></div></div>
  <div class="sv-bottom"><p class="sv-caption" id="sv-caption"></p><div class="sv-foot">${mine?'<i class="fa-regular fa-clock"></i><span id="sv-left">Status kamu</span>':`<form class="sv-reply" id="sv-reply" autocomplete="off"><input id="sv-reply-input" maxlength="500" placeholder="Balas status ${esc(name)}…" enterkeyhint="send"><button type="submit" aria-label="Kirim balasan" id="sv-reply-send" disabled><i class="fa-solid fa-paper-plane"></i></button></form>`}</div></div></div>`;
  document.body.appendChild(el);document.documentElement.classList.add('sx-lock');
  sv={el,uid,items,idx:0,raf:0,paused:false,elapsed:0,dur:IMG_MS,last:0,token:0,video:null};
  const $$=s=>el.querySelector(s);
  const next=()=>{if(!sv)return;if(sv.idx<sv.items.length-1)show(sv.idx+1);else{const o=userOrder(),i=o.indexOf(sv.uid),n=o[i+1];if(n)openViewer(n);else closeViewer();}};
  const prev=()=>{if(!sv)return;show(Math.max(0,sv.idx-1));};
  const setPause=v=>{if(!sv)return;sv.paused=v;if(sv.video){v?sv.video.pause():sv.video.play().catch(()=>{});}};
  $$('#sv-close').addEventListener('click',closeViewer);
  const replyForm=$$('#sv-reply'),replyInput=$$('#sv-reply-input');
  if(replyForm){
   let typing=false;const sendBtn=$$('#sv-reply-send');
   replyInput.addEventListener('focus',()=>{typing=true;setPause(true);});
   replyInput.addEventListener('blur',()=>{typing=false;setTimeout(()=>{if(sv&&sv.el===el&&!typing)setPause(false);},120);});
   replyInput.addEventListener('input',()=>{sendBtn.disabled=!replyInput.value.trim();});
   replyForm.addEventListener('submit',async e=>{
    e.preventDefault();const text=replyInput.value.trim();if(!text||!sv)return;sendBtn.disabled=true;
    const s=sv.items[sv.idx];
    try{
     const me=window.ndiflyCurrentUserId;if(!me)throw Error('Sesi login berakhir.');
     const {data:rid,error:re}=await sb.rpc('start_direct_chat',{p_target_user:uid});if(re)throw re;const roomId=Array.isArray(rid)?rid[0]:rid;if(!roomId)throw Error('Percakapan pribadi belum bisa dibuka.');
     const meta={status_id:s.id,owner_id:uid,owner_name:name,media_type:s.media_type,media_path:s.media_path,caption:s.caption||''};
     const {error}=await sb.from('chat_messages').insert({room_id:roomId,sender_id:me,content:text,kind:'status_reply',meta});
     if(error)throw error;
     replyInput.value='';replyInput.blur();toast(`Balasan terkirim ke ${name}.`);
    }catch(err){console.error('[status reply]',err);const m=String(err.message||'');toast(/kind|meta|column|schema cache/i.test(m)?'Fitur balas status belum aktif di database (jalankan SQL bagian 7).':(m||'Balasan gagal dikirim.'));sendBtn.disabled=!replyInput.value.trim();}
   });
  }
  $$('#sv-mute').addEventListener('click',()=>{if(!sv?.video)return;sv.video.muted=!sv.video.muted;$$('#sv-mute i').className='fa-solid '+(sv.video.muted?'fa-volume-xmark':'fa-volume-high');});
  $$('#sv-del')?.addEventListener('click',async()=>{
   if(!sv)return;setPause(true);const s=sv.items[sv.idx];
   if(!window.confirm('Hapus status ini?')){setPause(false);return;}
   const {data,error}=await sb.from('user_status').delete().eq('id',s.id).eq('user_id',window.ndiflyCurrentUserId).select('id');
   if(error||!data?.length){toast('Status tidak bisa dihapus. Coba lagi.');setPause(false);return;}
   sb.storage.from('chat-status').remove([s.media_path]).catch(()=>{});current=current.filter(x=>x.id!==s.id);toast('Status dihapus.');renderStatuses();
   const left=sv.items.filter(x=>x.id!==s.id);if(!left.length){closeViewer();return;}const keep=Math.min(sv.idx,left.length-1),uidKeep=sv.uid;closeViewer();openViewer(uidKeep,keep);
  });
  [['.sv-prev',prev],['.sv-next',next]].forEach(([sel,fn])=>{const z=$$(sel);let t=0;
   z.addEventListener('pointerdown',()=>{t=Date.now();setPause(true);});
   z.addEventListener('pointerup',()=>{setPause(false);if(Date.now()-t<260)fn();});
   z.addEventListener('pointercancel',()=>setPause(false));z.addEventListener('pointerleave',()=>{if(sv?.paused)setPause(false);});});
  let y0=null;el.addEventListener('touchstart',e=>{y0=e.touches[0].clientY;},{passive:true});
  el.addEventListener('touchend',e=>{if(y0!==null&&e.changedTouches[0].clientY-y0>110)closeViewer();y0=null;},{passive:true});
  const tick=ts=>{if(!sv||sv.el!==el)return;if(sv.last&&!sv.paused&&sv.dur>0&&sv.ready){sv.elapsed+=ts-sv.last;const seg=el.querySelectorAll('.sv-seg i')[sv.idx];if(seg)seg.style.width=Math.min(100,sv.elapsed/sv.dur*100)+'%';if(sv.elapsed>=sv.dur){sv.last=0;next();return;}}sv.last=ts;sv.raf=requestAnimationFrame(tick);};
  async function show(i){
   if(!sv||sv.el!==el)return;const token=++sv.token;sv.idx=i;sv.elapsed=0;sv.ready=false;sv.video=null;sv.last=0;
   el.querySelectorAll('.sv-seg i').forEach((b,k)=>b.style.width=k<i?'100%':'0%');
   const s=sv.items[i],media=$$('#sv-media');markSeen(s.id);media.replaceChildren();$$('.sv-bg').style.backgroundImage='';el.classList.add('loading');$$('#sv-mute').classList.add('hidden');
   $$('#sv-time').textContent=`${fmtClock(s.created_at)} · ${formatAge(s.created_at)}`;$$('#sv-caption').textContent=s.caption||'';
   const left=$$('#sv-left');if(left){const h=Math.max(0,Math.ceil((Date.parse(s.expires_at)-Date.now())/3600000));left.textContent=`Berakhir dalam ${h} jam`;}
   const remaining=Math.floor((Date.parse(s.expires_at)-Date.now())/1000);
   if(!Number.isFinite(remaining)||remaining<=0){toast('Status ini sudah berakhir.');await loadStatuses();next();return;}
   try{
    const {data,error}=await sb.storage.from('chat-status').createSignedUrl(s.media_path,Math.max(60,remaining));if(error)throw error;if(token!==sv?.token)return;
    if(s.media_type==='video'){
     const v=document.createElement('video');v.src=data.signedUrl;v.playsInline=true;v.autoplay=true;v.muted=false;media.appendChild(v);sv.video=v;
     v.addEventListener('loadedmetadata',()=>{if(token!==sv?.token)return;sv.dur=Math.min(60000,Math.max(1000,(v.duration||6)*1000));},{once:true});
     v.addEventListener('playing',()=>{if(token!==sv?.token)return;el.classList.remove('loading');sv.ready=true;},{once:true});
     v.addEventListener('ended',()=>{if(token===sv?.token){sv.elapsed=sv.dur;}});
     v.addEventListener('error',()=>{if(token===sv?.token){toast('Video status tidak dapat diputar.');el.classList.remove('loading');sv.dur=2000;sv.ready=true;}},{once:true});
     $$('#sv-mute').classList.remove('hidden');$$('#sv-mute i').className='fa-solid fa-volume-high';
     v.play().catch(()=>{v.muted=true;$$('#sv-mute i').className='fa-solid fa-volume-xmark';v.play().catch(()=>{});});
    }else{
     const im=new Image();im.alt='Status';im.onload=()=>{if(token!==sv?.token)return;media.appendChild(im);$$('.sv-bg').style.backgroundImage=`url("${data.signedUrl}")`;el.classList.remove('loading');sv.dur=IMG_MS;sv.ready=true;};
     im.onerror=()=>{if(token===sv?.token){toast('Foto status tidak dapat dimuat.');next();}};im.src=data.signedUrl;
    }
   }catch(err){console.warn('[status viewer]',err);if(token===sv?.token){toast(err.message||'Status tidak dapat dibuka.');closeViewer();}}
  }
  sv.raf=requestAnimationFrame(tick);await show(Math.min(startIdx,items.length-1));
 }
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(editor&&!editor.busy)closeEditor();else closeViewer();}if(sv&&e.key==='ArrowRight')sv.el.querySelector('.sv-next')?.dispatchEvent(new PointerEvent('pointerup'));});
window.ndiflyOpenStatus=async(uid,statusId)=>{
  if(!current.some(x=>x.id===statusId))await loadStatuses();
  const items=userItems(uid),idx=items.findIndex(x=>String(x.id)===String(statusId));
  if(idx<0){toast('Status ini sudah berakhir (hilang setelah 24 jam).');return;}
  openViewer(uid,idx);
 };
 $('status-file')?.addEventListener('change',e=>{const f=e.target.files?.[0];e.target.value='';if(f)openEditor(f);});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',loadStatuses);else loadStatuses();
 setInterval(()=>{if(document.visibilityState==='visible')loadStatuses();},60000);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')loadStatuses();});
})();
