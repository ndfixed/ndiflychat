/* Apply the saved appearance before the page paints to avoid a light/dark flash. */
(() => {
  const root = document.documentElement;
  let theme = 'dark';
  try { theme = localStorage.getItem('ndifly_theme') === 'light' ? 'light' : 'dark'; } catch (_) {}
  const light = theme === 'light';
  root.classList.toggle('light', light);
  root.classList.toggle('dark', !light);
  root.style.colorScheme = light ? 'light' : 'dark';
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.content = light ? '#f4f6fb' : '#0b1018';
})();

/* Preferensi tampilan docbar (Settings → Tampilan docbar): buram 0-30 px, transparansi 0-100 %. */
(() => {
  const root = document.documentElement, BK = 'ndifly_dock_blur', CK = 'ndifly_dock_clear', DEF = { blur: 9, clear: 65 };
  const read = (k, d) => { try { const v = parseFloat(localStorage.getItem(k)); return Number.isFinite(v) ? v : d; } catch (_) { return d; } };
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function apply(blur, clear) {
    blur = clamp(Math.round(blur), 0, 30); clear = clamp(Math.round(clear), 0, 100);
    root.style.setProperty('--dock-blur', blur + 'px');
    root.style.setProperty('--dock-k', ((1 - clear / 100) / 0.35).toFixed(3));   // 65 % = tampilan bawaan
    return { blur, clear };
  }
  function save(blur, clear) {
    const v = apply(blur, clear);
    try { localStorage.setItem(BK, v.blur); localStorage.setItem(CK, v.clear); } catch (_) {}
    return v;
  }
  const get = () => ({ blur: clamp(read(BK, DEF.blur), 0, 30), clear: clamp(read(CK, DEF.clear), 0, 100) });
  window.ndiflyDock = { get, set: save, reset: () => save(DEF.blur, DEF.clear), defaults: DEF };
  const cur = get(); apply(cur.blur, cur.clear);
  window.addEventListener('storage', e => { if (e.key === BK || e.key === CK) { const c = get(); apply(c.blur, c.clear); } });
})();
