/* Supabase public client configuration. Never put service_role keys in browser code. */
window.NDIFLY_CONFIG = {
  SUPABASE_URL: 'https://jueycexmxuetbdqdwrfv.supabase.co',
  SUPABASE_ANON_KEY: 'sb_publishable_FKg5xu4pKtTH45HbGTe4bw_NKs85MLe'
  // TURN credentials must remain server-side; see TURN-SETUP.md.
};

(function initSupabase() {
  let resolveReady, rejectReady;
  window.ndiflySupabaseReady = new Promise((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
  const cfg = window.NDIFLY_CONFIG || {};
  const showConfigError = (message) => {
    console.error('[ndiflyChat config]', message);
    if (document.body && (document.body.classList.contains('home-body') || document.querySelector('.info-page'))) return;
    const toast = document.getElementById('toast');
    if (toast) {
      toast.textContent = message;
      toast.className = 'toast show error';
      toast.setAttribute('role', 'alert');
    } else if (document.body) {
      const el = document.createElement('div');
      el.textContent = message;
      el.setAttribute('role', 'alert');
      el.style.cssText = 'position:fixed;z-index:99999;left:16px;right:16px;bottom:calc(96px + env(safe-area-inset-bottom,0px));padding:14px 16px;border-radius:12px;background:#7f1d1d;color:#fff;font:14px/1.5 sans-serif;box-shadow:0 8px 30px #0005';
      document.body.appendChild(el);
    }
  };
  const fail = (message) => { showConfigError(message); resolveReady(null); };

  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(cfg.SUPABASE_URL || '')) {
    fail('URL Supabase belum benar. Periksa js/config.js.'); return;
  }
  const key = cfg.SUPABASE_ANON_KEY || '';
  // Supabase currently supports publishable keys (sb_publishable_) and legacy anon JWT keys.
  if (!(key.startsWith('sb_publishable_') || (key.startsWith('eyJ') && key.length > 80))) {
    fail('Publishable/anon key Supabase tidak valid. Periksa js/config.js.'); return;
  }
  if (!window.supabase?.createClient) {
    fail('Library Supabase gagal dimuat. Periksa koneksi internet lalu muat ulang.'); return;
  }
  try {
    window.ndiflySupabase = window.supabase.createClient(cfg.SUPABASE_URL, key, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: false,
        flowType: 'pkce'
      },
      global: { headers: { 'X-Client-Info': 'ndiflychat-web' } }
    });
    resolveReady(window.ndiflySupabase);
    window.dispatchEvent(new CustomEvent('ndifly:supabase-ready'));
  } catch (error) {
    console.error('[ndiflyChat config] Inisialisasi Supabase gagal:', error);
    fail('Layanan akun belum siap. Periksa konfigurasi Supabase.');
  }
})();
