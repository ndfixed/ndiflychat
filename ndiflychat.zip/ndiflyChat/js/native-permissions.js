/* Android permission bridge. Browser/PWA users continue to use normal browser prompts. */
(function () {
  const plugin = () => window.Capacitor?.Plugins?.MediaPermissions;
  async function request(method, fallbackMessage) {
    const native = plugin();
    if (!native || typeof native[method] !== 'function') return true;
    const result = await native[method]();
    if (!result?.granted) {
      const error = new Error(fallbackMessage);
      error.name = 'NotAllowedError';
      throw error;
    }
    return true;
  }
  window.ndiflyPermissions = {
    audio: () => request('requestAudioPermission', 'Izin mikrofon belum diberikan.'),
    camera: () => request('requestCameraPermission', 'Izin kamera belum diberikan.'),
    notifications: () => request('requestNotificationPermission', 'Izin notifikasi belum diberikan.')
  };
})();
