/* ndiflyChat · polish.js — pekerjaan kecil saat runtime untuk animasi yang lebih mulus.
   1) Menjeda animasi dekoratif saat tab disembunyikan (hemat baterai) dan selagi halaman digulir.
   2) Tidak mengubah markup, id, atau handler lain. Aman dimuat berkali-kali. */
(() => {
  'use strict';
  if (window.__ndiflyPolish) return;
  window.__ndiflyPolish = true;
  const root = document.documentElement;

  // tab tersembunyi / app di latar belakang → semua animasi dijeda
  const syncIdle = () => root.classList.toggle('is-idle', document.hidden);
  document.addEventListener('visibilitychange', syncIdle);
  syncIdle();

  // selagi menggulir: jeda animasi dekoratif + matikan transisi hover; pulih 140 ms setelah berhenti
  let t = 0, scrolling = false;
  const stop = () => { scrolling = false; root.classList.remove('is-scrolling'); };
  document.addEventListener('scroll', () => {
    if (!scrolling) { scrolling = true; root.classList.add('is-scrolling'); }
    clearTimeout(t);
    t = setTimeout(stop, 140);
  }, { capture: true, passive: true });
})();
