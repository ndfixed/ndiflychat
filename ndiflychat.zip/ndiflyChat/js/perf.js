/* ndiflyChat — performance mode. smooth (default, 120Hz-ready) | lite (60Hz-class, no animation). */
(() => {
  const KEY = 'ndifly_perf', root = document.documentElement;
  const get = () => { try { return localStorage.getItem(KEY) === 'lite' ? 'lite' : 'smooth'; } catch (_) { return 'smooth'; } };
  const nativeIntoView = Element.prototype.scrollIntoView, nativeScrollTo = Element.prototype.scrollTo;
  function apply(mode) {
    root.dataset.perf = mode;
    const lite = mode === 'lite';
    Element.prototype.scrollIntoView = function (o) { return nativeIntoView.call(this, lite && o && typeof o === 'object' ? { ...o, behavior: 'auto' } : o); };
    Element.prototype.scrollTo = function (...a) { if (lite && a[0] && typeof a[0] === 'object') a[0] = { ...a[0], behavior: 'auto' }; return nativeScrollTo.apply(this, a); };
    document.querySelectorAll('[data-perf-choice]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.perfChoice === mode)));
    const l = document.getElementById('current-perf-label'); if (l) l.textContent = lite ? 'Lite · 60 Hz' : 'Smooth · 120 Hz';
  }
  function save(mode) { try { localStorage.setItem(KEY, mode); } catch (_) {} apply(mode); }
  function measureHz() {
    const out = document.getElementById('perf-hz-readout'); if (!out || !window.requestAnimationFrame) return;
    let n = 0, t0 = 0;
    const tick = t => { if (!t0) t0 = t; if (++n < 40) return requestAnimationFrame(tick);
      const hz = Math.round(1000 / ((t - t0) / (n - 1)) / 5) * 5; out.textContent = 'Layar terdeteksi ±' + hz + ' Hz'; };
    requestAnimationFrame(tick);
  }
  apply(get());
  window.ndiflyPerf = { get, set: save };
  window.addEventListener('storage', e => { if (e.key === KEY) apply(get()); });
  document.addEventListener('DOMContentLoaded', () => {
    apply(get()); measureHz();
    document.querySelectorAll('[data-perf-choice]').forEach(b => b.addEventListener('click', () => save(b.dataset.perfChoice)));
  });
})();
