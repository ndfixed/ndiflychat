/* Nada panggilan dibuat langsung dengan WebAudio (tanpa file audio). Bila browser memblokir suara
   sebelum ada interaksi, perangkat tetap bergetar (jika didukung). */
window.NdiflyTones = (() => {
  let ctx = null, timer = null, vibTimer = null;
  const ac = () => {
    try {
      ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      return ctx;
    } catch (_) { return null; }
  };
  const beep = (freq, start, dur, vol = 0.11) => {
    const c = ac(); if (!c || c.state !== 'running') return;
    const t0 = c.currentTime + start;
    const osc = c.createOscillator(), gain = c.createGain();
    osc.type = 'sine'; osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain).connect(c.destination);
    osc.start(t0); osc.stop(t0 + dur + 0.05);
  };
  const stop = () => {
    clearInterval(timer); timer = null; clearInterval(vibTimer); vibTimer = null;
    try { if (navigator.vibrate && navigator.userActivation && navigator.userActivation.hasBeenActive) navigator.vibrate(0); } catch (_) {}
  };
  const loop = (fn, periodMs, vibrate) => {
    stop(); fn(); timer = setInterval(fn, periodMs);
    if (vibrate) { const v = () => { try { if (navigator.vibrate && navigator.userActivation && navigator.userActivation.hasBeenActive) navigator.vibrate([420, 180, 420]); } catch (_) {} }; v(); vibTimer = setInterval(v, periodMs); }
  };
  return {
    /* Dering masuk: dua nada naik-turun, diulang. */
    ringStart() { loop(() => { beep(784, 0, .22); beep(988, .26, .22); beep(784, .72, .22); beep(988, .98, .22); }, 2600, true); },
    /* Nada tunggu untuk penelepon. */
    ringbackStart() { loop(() => { beep(440, 0, 1.0, .07); beep(480, 0, 1.0, .07); }, 3200, false); },
    stop,
    /* Notifikasi singkat (panggilan Global, tersambung, berakhir). */
    chime() { beep(659, 0, .16); beep(880, .17, .16); beep(1175, .34, .24); },
    pop() { beep(988, 0, .09, .06); beep(1319, .09, .12, .06); },
    connected() { beep(880, 0, .12); beep(1318, .13, .2); },
    ended() { beep(520, 0, .16); beep(392, .17, .26); },
    unlock() { ac(); },
  };
})();
['pointerdown', 'keydown', 'touchstart'].forEach(ev => window.addEventListener(ev, () => window.NdiflyTones.unlock(), { once: true, passive: true }));
