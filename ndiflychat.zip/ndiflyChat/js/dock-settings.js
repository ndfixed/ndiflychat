/* ndiflyChat · Settings → Tampilan docbar: slider buram & transparansi (tersimpan di perangkat, berlaku di semua halaman). */
(() => {
  'use strict';
  const D = window.ndiflyDock, $ = id => document.getElementById(id);
  const blur = $('dock-blur'), clear = $('dock-clear');
  if (!D || !blur || !clear) return;
  const PRESETS = { clear: [6, 85], balanced: [9, 65], frosted: [20, 30] };
  const paint = v => {
    blur.value = v.blur; clear.value = v.clear;
    $('dock-blur-out').textContent = String(v.blur);
    $('dock-clear-out').textContent = v.clear + '%';
    document.querySelectorAll('[data-dock-preset]').forEach(b => {
      const p = PRESETS[b.dataset.dockPreset];
      b.setAttribute('aria-pressed', String(p[0] === v.blur && p[1] === v.clear));
    });
  };
  const onInput = () => paint(D.set(+blur.value, +clear.value));
  blur.addEventListener('input', onInput);
  clear.addEventListener('input', onInput);
  document.querySelectorAll('[data-dock-preset]').forEach(b => b.addEventListener('click', () => { const p = PRESETS[b.dataset.dockPreset]; paint(D.set(p[0], p[1])); }));
  $('dock-reset').addEventListener('click', () => paint(D.reset()));
  paint(D.get());
})();
