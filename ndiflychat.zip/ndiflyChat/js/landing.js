// Gerak halus: header berubah saat di-scroll + kartu muncul perlahan. Konten tetap tampil penuh bila JS/animasi mati.
(() => {
  const root = document.documentElement;
  // Urutan pesan pada pratinjau chat (dipakai animasi CSS).
  document.querySelectorAll('.preview-msg').forEach((m, i) => m.style.setProperty('--n', i));
  const nav = document.querySelector('.home-nav-wrap');
  const onScroll = () => nav && nav.classList.toggle('is-scrolled', window.scrollY > 12);
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });
  const calm = root.dataset.perf === 'lite' || window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (calm || !('IntersectionObserver' in window)) return;
  const items = document.querySelectorAll('.home-feature-card,.steps-list li,.team-card,.faq-item,.point-card,.home-end-cta,.section-intro');
  items.forEach((el, i) => { el.classList.add('reveal'); el.style.setProperty('--rv-delay', (i % 4) * 70 + 'ms'); });
  const io = new IntersectionObserver(entries => entries.forEach(e => {
    if (!e.isIntersecting) return;
    const el = e.target; el.classList.add('is-in'); io.unobserve(el);
    setTimeout(() => { el.classList.remove('reveal', 'is-in'); el.style.removeProperty('--rv-delay'); }, 900);
  }), { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
  items.forEach(el => io.observe(el));
})();

// Tab "Intip dalamnya": satu panel tampil, mendukung klik dan tombol panah.
(() => {
  const tabs = [...document.querySelectorAll('.lp-tab')];
  if (!tabs.length) return;
  const title = document.getElementById('lp-device-title');
  const names = { 'tab-chat': 'Obrolan ndifly', 'tab-status': 'Status teman', 'tab-call': 'Panggilan suara' };
  const show = tab => {
    tabs.forEach(t => {
      const on = t === tab;
      t.classList.toggle('is-active', on);
      t.setAttribute('aria-selected', on);
      t.tabIndex = on ? 0 : -1;
      const panel = document.getElementById(t.getAttribute('aria-controls'));
      if (panel) { panel.hidden = !on; panel.classList.toggle('is-active', on); }
    });
    if (title) title.textContent = names[tab.id] || '';
  };
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => show(t));
    t.addEventListener('keydown', e => {
      const k = { ArrowRight: 1, ArrowDown: 1, ArrowLeft: -1, ArrowUp: -1 }[e.key];
      if (!k) return;
      e.preventDefault();
      const next = tabs[(i + k + tabs.length) % tabs.length];
      next.focus(); show(next);
    });
  });
})();

(() => {
  const client = window.ndiflySupabase;
  if (!client?.auth) {
    console.warn('[ndiflyChat] Supabase belum siap; tombol Masuk/Daftar tetap dapat digunakan.');
    return;
  }
  client.auth.getSession()
    .then(({ data, error }) => {
      if (error) { console.warn('[ndiflyChat] Gagal memeriksa sesi awal:', error.message); return; }
      if (data?.session) location.replace('chat.html');
    })
    .catch(error => console.warn('[ndiflyChat] Gagal memeriksa sesi awal:', error));
})();
