/* Loading screen: terangkat begitu halaman benar-benar siap, tanpa jeda buatan.
   Yang dicek: stylesheet lokal, DOM, font (singkat), stylesheet CDN (singkat), dan khusus chat: data awal.
   Stylesheet CDN (Google Fonts, Font Awesome) memakai font-display swap, jadi hanya ditunggu sebentar.
   Pengaman: error -> angkat, batas waktu -> angkat, dan CSS sendiri mengangkatnya setelah 6,5 detik.
   Loading screen baru tampil bila memuat lebih dari ~0,15 detik (lihat splash.css), jadi halaman yang cepat siap
   tidak pernah memperlihatkannya sama sekali. */
(()=>{
 const root=document.documentElement,el=document.getElementById('ndifly-splash');
 if(!el){root.classList.remove('is-loading');return;}
 let seen=false;try{seen=sessionStorage.getItem('ndifly_splash_seen')==='1';}catch(_){}
 if(seen)el.classList.add('is-quick');
 const isApp=el.dataset.wait==='app';
 const MAX=isApp?(seen?3000:5000):(seen?1800:3500);
 const sleep=ms=>new Promise(r=>setTimeout(r,ms));
 let done=false;
 const msgs=(el.dataset.msgs||'Menyiapkan tampilan…').split('|'),sub=el.querySelector('.sp-sub');let i=0;
 if(sub)sub.textContent=msgs[0];
 const tick=setInterval(()=>{if(!sub||msgs.length<2)return;i=(i+1)%msgs.length;sub.style.opacity='0';setTimeout(()=>{sub.textContent=msgs[i];sub.style.opacity='1';},200);},1300);
 /* "Muat ulang" hanya muncul bila memuat terlalu lama */
 const retryT=setTimeout(()=>{if(done||seen)return;const b=document.createElement('button');b.type='button';b.className='sp-retry';b.textContent='Terlalu lama? Muat ulang';b.addEventListener('click',()=>location.reload());el.querySelector('.sp-wrap')?.appendChild(b);},3500);

 const sameOrigin=l=>{try{return new URL(l.href,location.href).origin===location.origin;}catch(_){return true;}};
 const settle=l=>new Promise(r=>{if(l.sheet)return r();l.addEventListener('load',r,{once:true});l.addEventListener('error',r,{once:true});});
 const links=[...document.querySelectorAll('link[rel="stylesheet"]')];
 const local=links.filter(sameOrigin).map(settle),remote=links.filter(l=>!sameOrigin(l)).map(settle);

 const waits=[
  Promise.all(local),                                              /* CSS milik sendiri: wajib siap */
  Promise.race([Promise.all(remote),sleep(seen?120:400)]),         /* CSS CDN: tunggu sebentar saja */
  document.fonts&&document.fonts.ready?Promise.race([document.fonts.ready,sleep(seen?80:250)]):Promise.resolve(),
  /* DOM siap = parser sudah sampai bagian script (penanda ndifly:parsed), bukan menunggu library CDN yang memblokir DOMContentLoaded */
  new Promise(r=>{if(window.__ndiflyParsed||document.readyState!=='loading')return r();document.addEventListener('ndifly:parsed',r,{once:true});document.addEventListener('DOMContentLoaded',r,{once:true});})
 ];
 if(isApp)waits.push(new Promise(r=>{if(window.__ndiflyReady)r();else document.addEventListener('ndifly:ready',r,{once:true});}));

 function finish(){
  if(done)return;done=true;clearTimeout(retryT);clearInterval(tick);
  requestAnimationFrame(()=>{
   try{sessionStorage.setItem('ndifly_splash_seen','1');}catch(_){}
   root.classList.remove('is-loading');root.classList.add('just-ready');el.classList.add('is-out');
   let gone=false;const rm=()=>{if(gone)return;gone=true;el.remove();root.classList.remove('just-ready');};
   el.addEventListener('transitionend',e=>{if(e.target===el)rm();});
   setTimeout(rm,seen?260:380);
  });
 }
 Promise.all(waits).then(finish,finish);setTimeout(finish,MAX);
 /* chat saja: bila klien backend tidak pernah aktif, tidak akan ada sinyal siap, jadi jangan menggantung */
 if(isApp)setTimeout(()=>{if(!window.ndiflySupabase)finish();},1500);
 window.addEventListener('error',()=>setTimeout(finish,400));
 window.addEventListener('unhandledrejection',()=>setTimeout(finish,800));
})();
