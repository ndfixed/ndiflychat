/* Legacy bundle retired. Current pages use js/chat.js, js/auth.js, and js/landing.js.
   This file intentionally does not initialize a second Supabase client. */
console.info('[ndiflyChat] js/script.js is legacy; use the page-specific script entry point.');
