/* Private Realtime channel helper for ndiflyChat calls.
   Call signaling always fails closed: it never falls back to a public channel. */
window.NdiflyCallChannel = (() => {
  let lastError = '';
  let authSubscription = null;

  async function ensureAuth(sb) {
    const { data, error } = await sb.auth.getSession();
    if (error) throw error;
    const token = data?.session?.access_token;
    if (!token) throw new Error('Sesi login tidak tersedia untuk koneksi panggilan.');
    if (sb.realtime && typeof sb.realtime.setAuth === 'function') {
      await sb.realtime.setAuth(token);
    }
    if (!authSubscription && typeof sb.auth.onAuthStateChange === 'function') {
      const result = sb.auth.onAuthStateChange((_event, session) => {
        const freshToken = session?.access_token;
        if (freshToken && sb.realtime?.setAuth) {
          Promise.resolve(sb.realtime.setAuth(freshToken)).catch(err =>
            console.warn('[Realtime auth refresh]', err)
          );
        }
      });
      authSubscription = result?.data?.subscription || null;
    }
  }

  async function open(sb, topic, opts = {}) {
    try {
      await ensureAuth(sb);
    } catch (error) {
      lastError = error?.message || 'Autentikasi Realtime gagal.';
      return { channel: null, mode: 'none', error: lastError };
    }

    return new Promise(resolve => {
      const config = { private: true, broadcast: { self: false } };
      if (opts.presenceKey) config.presence = { key: String(opts.presenceKey) };
      let channel;
      try {
        channel = sb.channel(topic, { config });
        if (typeof opts.bind === 'function') opts.bind(channel);
      } catch (error) {
        lastError = error?.message || 'Channel panggilan gagal disiapkan.';
        if (channel) Promise.resolve(sb.removeChannel(channel)).catch(() => {});
        resolve({ channel: null, mode: 'none', error: lastError });
        return;
      }

      let settled = false;
      const timer = setTimeout(() => finish(false, 'Waktu koneksi Realtime habis.'), 12000);
      const finish = (ok, reason) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (ok) {
          lastError = '';
          resolve({ channel, mode: 'private', error: null });
        } else {
          lastError = reason || 'Supabase menolak channel privat.';
          Promise.resolve(sb.removeChannel(channel)).catch(() => {});
          resolve({ channel: null, mode: 'none', error: lastError });
        }
      };

      try {
        channel.subscribe((status, error) => {
          if (status === 'SUBSCRIBED') finish(true);
          else if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || status === 'CLOSED') {
            finish(false, error?.message || `Realtime ${status.toLowerCase()}.`);
          }
        });
      } catch (error) {
        finish(false, error?.message || 'Tidak dapat berlangganan channel panggilan.');
      }
    });
  }

  return {
    open,
    ensureAuth,
    get mode() { return 'private'; },
    get lastError() { return lastError; },
    reset() { lastError = ''; }
  };
})();
