;(()=>{
/* ndiflyChat chat client. Auth guard is mandatory on this page. */
const supabase=window.ndiflySupabase;
if(!supabase){
  const notice=document.getElementById('toast');
  if(notice){notice.textContent='Koneksi belum siap. Periksa internetmu lalu muat ulang halaman.';notice.className='toast show error';}
  console.error('[ndiflyChat] Supabase client belum diinisialisasi.');
  return;
}
const GLOBAL_ROOM_ID='00000000-0000-4000-8000-000000000001';
let pendingImage=null, attachUrl=null, chatStick=true, renderedCount=0, unseenCount=0;
const seenMsgIds=new Set();
let session=null, profile=null, activeRoom={id:GLOBAL_ROOM_ID,name:'Global Community'}, messageChannel=null, roomChannel=null, readChannel=null, callChannel=null, messagesCache=[], roomsCache=[], sending=false, replyTo=null, toastTimer=null, roomSearchTimer=null, roomSearchSequence=0, roomOpenSequence=0, remoteVideoPeerId=null;
const roomSummaries=new Map();
let inboxRefreshTimer=null, inboxRpcFailed=false, inboxFallbackWarned=false;
const readersByMessage=new Map();
const readReceiptInFlight=new Set();
const readMessagesHandled=new Set();
let messageReadObserver=null;
let readReceiptErrorShown=false;
let modalAction=null, modalActionType='logout', modalBusy=false;
const $=id=>document.getElementById(id);
const safe=(value='')=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function renderProfileAvatar(el,url,name){if(!el)return;if(url){el.innerHTML=`<img src="${safe(url)}" alt="Foto profil" loading="lazy">`;el.classList.add("has-profile-photo");}else{el.textContent=String(name||"?").charAt(0).toUpperCase();el.classList.remove("has-profile-photo");}}
const isVerified=username=>String(username||'').trim().toLowerCase()==='andif_dev';
const verifiedBadge=username=>isVerified(username)?'<span class="verified-badge" title="Akun terverifikasi" aria-label="Akun terverifikasi"><i class="fa-solid fa-check"></i></span><span class="developer-king-badge" title="Developer" aria-label="Developer"><img src="assets-developer-badge.png" alt="" aria-hidden="true"></span>':'';
function toast(message,type=''){const el=$('toast');if(!el){console.warn('[ndiflyChat]',message);return;}el.textContent=message;el.className=`toast show ${type}`;clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.className='toast',3200);}
let dbNoticeShown=false;
window.ndiflyDbNotice=function(why){console.warn('[ndiflyChat · database belum lengkap]',why);if(dbNoticeShown)return;dbNoticeShown=true;try{toast('Database belum lengkap ('+why+'). Jalankan NDIFLYCHAT-ALL-IN-ONE.sql di Supabase SQL Editor, lalu muat ulang.','error');}catch(_){}};
async function hydrateMessageMedia(rows){
 const list=Array.isArray(rows)?rows:[];
 const paths=[...new Set(list.flatMap(m=>[m.image_path,m.audio_path]).filter(Boolean))];
 if(!paths.length)return list;
 try{
   const {data,error}=await supabase.storage.from('chat-media').createSignedUrls(paths,3600);
   if(error)throw error;
   const signed=new Map((data||[]).filter(x=>x?.path&&x?.signedUrl).map(x=>[x.path,x.signedUrl]));
   return list.map(m=>({...m,image_url:m.image_url||(m.image_path?signed.get(m.image_path):null)||null,audio_url:m.audio_url||(m.audio_path?signed.get(m.audio_path):null)||null}));
 }catch(error){
   console.warn('[private media signing]',error?.message||error);
   return list;
 }
}
async function enterApp(){
 const {data:userData,error:userError}=await supabase.auth.getUser(); if(userError)throw userError; if(!userData.user){location.replace('login.html');return;}
 session={user:userData.user};
 const uid=session.user.id, fullCols='id,username,display_name,avatar_url,bio,last_seen', baseCols='id,username,display_name,avatar_url';
 let {data:profileData,error}=await supabase.from('profiles').select(fullCols).eq('id',uid).maybeSingle();
 // bio/last_seen come from profile-presence-setup.sql; an older database must not block the whole app.
 if(error&&/bio|last_seen|column|42703/i.test(`${error.code||''} ${error.message||''}`)){
  console.warn('[profiles] Kolom bio/last_seen belum ada. Jalankan profile-presence-setup.sql.',error.message);ndiflyDbNotice('kolom profil bio/last_seen');
  ({data:profileData,error}=await supabase.from('profiles').select(baseCols).eq('id',uid).maybeSingle());
 }
 if(error)throw error;
 const fallbackName=session.user.user_metadata?.username||session.user.email?.split('@')[0]||'pengguna';
 if(!profileData){
  const result=await supabase.from('profiles').upsert({id:uid,username:fallbackName,display_name:fallbackName},{onConflict:'id'}).select(baseCols).single();
  if(result.error){console.warn('[profiles] Profil tidak bisa dibuat:',result.error.message);toast('Profilmu belum tersimpan di database. Jalankan supabase-setup.sql.','error');profileData={id:uid,username:fallbackName,display_name:fallbackName,avatar_url:null};}
  else profileData=result.data;
 }
 profile=profileData; startPresenceHeartbeat(); $('my-name').innerHTML=safe(profile.username||profile.display_name)+verifiedBadge(profile.username); renderProfileAvatar($('my-avatar'),profile.avatar_url,profile.username||profile.display_name);
 // Each step is isolated so one failing table or policy cannot leave the screen empty.
 try{await loadRooms();}catch(e){console.error('[startup rooms]',e);}
 try{await openRoom(GLOBAL_ROOM_ID,'Global Community',{auto:true});}catch(e){console.error('[startup room]',e);toast('Pesan belum bisa dimuat. Coba lagi sebentar lagi.','error');}
 listenForRooms();
 try{const q=new URLSearchParams(location.search),rid=q.get('room');if(rid&&/^[0-9a-f-]{36}$/i.test(rid)){await openRoomById(rid);$('app-screen').classList.add('chat-open');const cm=q.get('call');history.replaceState(null,'','chat.html');if(cm==='audio'||cm==='video')setTimeout(()=>startCall(cm),700);}}catch(e){console.warn('[deep link]',e);}
 try{syncCallListeners(roomsCache);}catch(_){}
 showWelcomePopup();startGreetingClock();
}
async function loadRooms(){
  const {data,error}=await supabase.from('rooms').select('id,name,description,is_public,created_at').order('created_at',{ascending:true});
  if(error){console.error(error);toast('Daftar ruang belum bisa dimuat. Muat ulang halaman sebentar lagi.','error');return;}
  roomsCache=data||[];
  await refreshInboxSummaries(false);
  renderRoomList(roomsCache);
}
function displayRoomName(room){
  if(room?.is_public || room?.id===GLOBAL_ROOM_ID) return room?.id===GLOBAL_ROOM_ID?'Global Community':(room?.name||'Ruang komunitas');
  const match=String(room?.name||'').match(/^DM\s*-\s*@([^/]+)\s*\/\s*@(.+)$/i);
  if(match){const me=String(profile?.username||'').trim().toLowerCase();const a=match[1].trim(),b=match[2].trim();return '@'+(a.toLowerCase()===me?b:a);}
  return room?.name||'Percakapan pribadi';
}
function inboxTime(value){
  if(!value)return '';
  const date=new Date(value);if(Number.isNaN(date.getTime()))return '';
  const now=new Date();
  if(date.toDateString()===now.toDateString())return date.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit',hour12:false});
  const yesterday=new Date(now);yesterday.setDate(now.getDate()-1);
  if(date.toDateString()===yesterday.toDateString())return 'Kemarin';
  return date.toLocaleDateString('id-ID',{day:'2-digit',month:'short'});
}
function inboxPreview(summary){
  if(!summary?.latest_message_id)return 'Belum ada pesan. Mulai percakapan';
  const mine=String(summary.latest_sender_id)===String(session?.user?.id);
  let text=String(summary.latest_content||'').trim();
  if(!text&&(summary.latest_image_url||summary.latest_image_path))text='📷 Foto';
  if(!text&&(summary.latest_audio_url||summary.latest_audio_path))text='🎙️ Pesan suara';
  if(summary.latest_reply_to)text='↪ Balasan · '+(text||'Pesan');
  if(mine)text='Anda: '+(text||'Pesan');
  return text||'Pesan';
}
async function refreshInboxSummaries(repaint=true){
  if(!session?.user?.id||!roomsCache.length)return;
  let next=new Map();
  if(!inboxRpcFailed){
    try{
      const {data,error}=await supabase.rpc('get_room_inbox_summaries');
      if(error)throw error;
      (data||[]).forEach(row=>next.set(String(row.room_id),row));
    }catch(error){
      inboxRpcFailed=true;
      if(!inboxFallbackWarned){inboxFallbackWarned=true;console.info('[inbox] Menjalankan fallback preview. Untuk hitungan belum dibaca yang presisi, jalankan room-inbox-setup.sql.',error?.message||error);ndiflyDbNotice('fungsi inbox');}
    }
  }
  if(inboxRpcFailed){
    try{
      const roomIds=roomsCache.map(r=>r.id);
      const {data:messages,error}=await supabase.from('chat_messages').select('*,profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').in('room_id',roomIds).order('created_at',{ascending:false}).limit(1000);
      if(error)throw error;
      const all=messages||[],ids=all.map(m=>m.id);
      let readSet=new Set();
      for(let i=0;i<ids.length;i+=150){const chunk=ids.slice(i,i+150);if(!chunk.length)continue;const {data:reads,error:readError}=await supabase.from('message_reads').select('message_id').eq('reader_id',session.user.id).in('message_id',chunk);if(readError)throw readError;(reads||[]).forEach(row=>readSet.add(String(row.message_id)));}
      const unreadByRoom=new Map();
      all.forEach(m=>{const key=String(m.room_id);if(!next.has(key))next.set(key,{room_id:key,latest_message_id:m.id,latest_sender_id:m.sender_id,latest_content:m.content,latest_image_url:m.image_url,latest_audio_url:m.audio_url,latest_image_path:m.image_path,latest_audio_path:m.audio_path,latest_reply_to:m.reply_to,latest_created_at:m.created_at,latest_sender_username:m.profiles?.username,latest_sender_display_name:m.profiles?.display_name,unread_count:0});if(String(m.sender_id)!==String(session.user.id)&&!readSet.has(String(m.id)))unreadByRoom.set(key,(unreadByRoom.get(key)||0)+1);});
      next.forEach((summary,key)=>summary.unread_count=unreadByRoom.get(key)||0);
    }catch(error){console.warn('[inbox fallback]',error);}
  }
  roomSummaries.clear();next.forEach((value,key)=>roomSummaries.set(String(key),value));
  try{const total=[...roomSummaries.values()].reduce((n,x)=>n+Number(x.unread_count||0),0);document.title=(total>0?`(${total>99?'99+':total}) `:'')+'Chat — ndiflyChat';}catch(_){}
  if(repaint)renderRoomList(roomsCache);
}
function scheduleInboxRefresh(){clearTimeout(inboxRefreshTimer);inboxRefreshTimer=setTimeout(()=>refreshInboxSummaries(true),350);}
function renderRoomList(rooms){
  syncCallListeners(rooms);
  const list=$('conversation-list');
  if(!list.dataset.animated){list.dataset.animated='1';list.classList.add('stagger-in');setTimeout(()=>list.classList.remove('stagger-in'),1200);}
  const query=($('room-search')?.value||'').trim().toLowerCase();
  const sorted=[...(rooms||[])].sort((a,b)=>{
    if(String(a.id)===GLOBAL_ROOM_ID)return -1;if(String(b.id)===GLOBAL_ROOM_ID)return 1;
    const as=roomSummaries.get(String(a.id))?.latest_created_at||a.created_at||'';
    const bs=roomSummaries.get(String(b.id))?.latest_created_at||b.created_at||'';
    return new Date(bs)-new Date(as);
  });
  const visible=sorted.filter(r=>{const s=roomSummaries.get(String(r.id));const title=displayRoomName(r);const preview=inboxPreview(s);return !query||`${title} ${r.description||''} ${preview}`.toLowerCase().includes(query);});
  if(!visible.length){list.innerHTML=`<div class="system-message">${query?'Tidak ada ruang yang cocok.':'Belum ada ruang.'}</div>`;return;}
  list.innerHTML=visible.map(r=>{
    const summary=roomSummaries.get(String(r.id))||{};const title=displayRoomName(r);const unread=Number(summary.unread_count||0);const stamp=inboxTime(summary.latest_created_at);
    const preview=safe(inboxPreview(summary));const unreadBadge=unread>0?`<span class="unread-badge" aria-label="${unread} pesan belum dibaca">${unread>99?'99+':unread}</span>`:'';
    const roomIcon=r.id===GLOBAL_ROOM_ID?'fa-earth-asia':(r.is_public?'fa-users':'fa-user');
    return `<button type="button" class="conversation ${String(r.id)===String(activeRoom.id)?'active':''} ${unread?'has-unread':''}" data-room="${safe(r.id)}" data-name="${safe(title)}"><span class="room-avatar ${r.id===GLOBAL_ROOM_ID?'global-avatar':''}">${r.id===GLOBAL_ROOM_ID?`<i class="fa-solid ${roomIcon}"></i>`:(summary.latest_sender_id&&String(summary.latest_sender_id)!==String(session?.user?.id)&&summary.latest_sender_avatar_url?`<img src="${safe(summary.latest_sender_avatar_url)}" alt="" loading="lazy">`:`<span>${safe(title.replace(/^@/,'').charAt(0).toUpperCase()||'U')}</span>`)}</span><span class="conversation-copy"><span class="conversation-line"><span class="conversation-title-wrap"><b>${safe(title)}</b>${!r.is_public?verifiedBadge(title.replace(/^@/,'') ):''}</span>${stamp?`<time class="conversation-date">${safe(stamp)}</time>`:''}</span><span class="conversation-subline"><span class="conversation-preview">${preview}</span><span class="conversation-trailing">${r.id===GLOBAL_ROOM_ID?'<span class="live-pill">LIVE</span>':''}${unreadBadge}</span></span></span></button>`;
  }).join('');
  list.querySelectorAll('[data-room]').forEach(btn=>btn.addEventListener('click',()=>openRoom(btn.dataset.room,btn.dataset.name)));
  const peerNames=visible.filter(r=>!r.is_public&&String(r.id)!==GLOBAL_ROOM_ID).map(r=>{const m=String(r.name||'').match(/^DM\s*-\s*@([^/]+)\s*\/\s*@(.+)$/i);if(!m)return null;const me=String(profile?.username||'').toLowerCase();return [m[1].trim(),m[2].trim()].find(n=>n.toLowerCase()!==me)?.toLowerCase();}).filter(Boolean);
  if(peerNames.length){supabase.from('profiles').select('username,avatar_url').in('username',[...new Set(peerNames)]).then(({data,error})=>{if(error||!data)return;const photos=new Map(data.map(u=>[String(u.username).toLowerCase(),u.avatar_url]));list.querySelectorAll('[data-room]').forEach(btn=>{const room=roomsCache.find(r=>String(r.id)===String(btn.dataset.room));if(!room||room.is_public)return;const m=String(room.name||'').match(/^DM\s*-\s*@([^/]+)\s*\/\s*@(.+)$/i);if(!m)return;const me=String(profile?.username||'').toLowerCase(),peer=[m[1].trim(),m[2].trim()].find(n=>n.toLowerCase()!==me);const url=photos.get(String(peer||'').toLowerCase());const avatar=btn.querySelector('.room-avatar');if(avatar&&url)avatar.innerHTML=`<img src="${safe(url)}" alt="Foto profil" loading="lazy">`;});});}
}
async function searchUsers(rawQuery){
  const box=$('user-search-results');if(!box)return;
  const query=String(rawQuery||'').trim().replace(/^@/,'').toLowerCase();
  const sequence=++roomSearchSequence;
  if(query.length<2){box.classList.add('hidden');box.replaceChildren();return;}
  if(!/^[a-z0-9_]{2,24}$/.test(query)){box.classList.remove('hidden');box.innerHTML='<div class="system-message">Gunakan huruf, angka, atau underscore.</div>';return;}
  box.classList.remove('hidden');box.innerHTML='<div class="system-message">Mencari username…</div>';
  try{
    const escapedQuery=query.replace(/[\\%_]/g,'\\$&');
    const {data,error}=await supabase.from('profiles').select('id,username,display_name,avatar_url').ilike('username',`${escapedQuery}%`).neq('id',session.user.id).order('username',{ascending:true}).limit(8);
    if(sequence!==roomSearchSequence)return;
    if(error)throw error;
    const users=data||[];
    if(!users.length){box.innerHTML='<div class="system-message">Username tidak ditemukan.</div>';return;}
    box.innerHTML=users.map(u=>`<button type="button" class="user-search-result" data-user-id="${safe(u.id)}" data-username="${safe(u.username)}"><span class="user-search-avatar ${u.avatar_url?'has-profile-photo':''}" data-view-profile="${safe(u.id)}" data-profile-name="${safe(u.username)}">${u.avatar_url?`<img src="${safe(u.avatar_url)}" alt="" loading="lazy">`:safe((u.username||'?').charAt(0).toUpperCase())}</span><span class="user-search-copy"><b>@${safe(u.username)}${verifiedBadge(u.username)}</b><small>Mulai percakapan pribadi</small></span><i class="fa-solid fa-comment-dots"></i></button>`).join('');
    box.querySelectorAll('[data-user-id]').forEach(btn=>btn.addEventListener('click',e=>{if(e.target.closest('[data-view-profile]'))return;startDirectChat(btn.dataset.userId,btn.dataset.username);}));box.querySelectorAll('[data-view-profile]').forEach(avatar=>avatar.addEventListener('click',e=>{e.stopPropagation();showUserProfile(avatar.dataset.viewProfile,avatar.dataset.profileName);}));
  }catch(error){
    if(sequence!==roomSearchSequence)return;
    console.error('[username search]',error);box.innerHTML='<div class="system-message">Pencarian belum berhasil. Coba lagi sebentar lagi.</div>';
  }
}
async function startDirectChat(targetUserId,username){
  if(!targetUserId||!session?.user?.id)return;
  clearTimeout(roomSearchTimer);roomSearchSequence++;
  const box=$('user-search-results');if(box)box.innerHTML='<div class="system-message">Membuka percakapan…</div>';
  try{
    const {data,error}=await supabase.rpc('start_direct_chat',{p_target_user:targetUserId});
    if(error)throw error;
    const roomId=Array.isArray(data)?data[0]:data;
    if(!roomId)throw new Error('Backend tidak mengembalikan ruang percakapan.');
    if($('room-search'))$('room-search').value='';
    if(box){box.classList.add('hidden');box.replaceChildren();}
    await loadRooms();await openRoom(String(roomId),`@${username}`);
    $('app-screen').classList.add('chat-open');
  }catch(error){
    console.error('[start direct chat]',error);
    const message=/start_direct_chat|schema cache|function.*not found|PGRST202/i.test(error?.message||'')?'Chat pribadi belum bisa dibuka. Kabari andif_dev ya.':(error?.message||'Percakapan pribadi gagal dibuka.');
    toast(message,'error');
  }
}

async function syncLatestRoomMessages(roomId,requestId){
  const {data,error}=await supabase.from('chat_messages').select('*,profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').eq('room_id',roomId).order('created_at',{ascending:false}).limit(100);
  if(error){console.warn('[room message resync]',error);return;}
  if(requestId!==roomOpenSequence||String(activeRoom.id)!==String(roomId))return;
  const hydrated=await hydrateMessageMedia(data||[]);
  if(requestId!==roomOpenSequence||String(activeRoom.id)!==String(roomId))return;
  const merged=new Map(messagesCache.map(message=>[String(message.id),message]));
  hydrated.forEach(message=>merged.set(String(message.id),message));
  messagesCache=[...merged.values()].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)).slice(-100);
  renderMessages(messagesCache);$('info-message-count').textContent=String(messagesCache.length);
  await refreshReadReceipts(messagesCache.filter(message=>message.sender_id===session.user.id).map(message=>message.id),false);
}

/* opts.auto = dibuka otomatis saat start: siapkan ruangnya, tapi di layar kecil tetap tampilkan daftar chat (jangan langsung masuk). */
async function openRoom(id,name,opts){
  const requestId=++roomOpenSequence;
  if(String(id)!==String(activeRoom.id)){
    replyTo=null;$('reply-preview').classList.add('hidden');
    clearAttachment();
  }
  if(messageReadObserver){ messageReadObserver.disconnect(); messageReadObserver=null; }
  activeRoom={id,name}; $('header-room-name').textContent=name;
  const roomMeta=roomsCache.find(r=>String(r.id)===String(id));
  const headerAvatar=document.querySelector('.header-avatar');if(headerAvatar){headerAvatar.innerHTML=id===GLOBAL_ROOM_ID?'<i id="header-room-icon" class="fa-solid fa-earth-asia"></i>':'<i id="header-room-icon" class="fa-solid fa-user"></i>';headerAvatar.classList.toggle('global-avatar',id===GLOBAL_ROOM_ID);delete headerAvatar.dataset.peerId;delete headerAvatar.dataset.peerName;}
  if(roomMeta&&!roomMeta.is_public&&String(id)!==GLOBAL_ROOM_ID){const dm=String(roomMeta.name||'').match(/^DM\s*-\s*@([^/]+)\s*\/\s*@(.+)$/i);if(dm){const me=String(profile?.username||'').toLowerCase(),peer=[dm[1].trim(),dm[2].trim()].find(n=>n.toLowerCase()!==me);if(peer){const {data:peerProfile}=await supabase.from('profiles').select('id,username,avatar_url').eq('username',peer.toLowerCase()).maybeSingle();if(peerProfile&&String(activeRoom.id)===String(id)){if(headerAvatar)headerAvatar.innerHTML=peerProfile.avatar_url?`<img src="${safe(peerProfile.avatar_url)}" alt="Foto profil">`:`<span>${safe(peerProfile.username.charAt(0).toUpperCase())}</span>`;if(headerAvatar){headerAvatar.dataset.peerId=peerProfile.id;headerAvatar.dataset.peerName=peerProfile.username;}}}}}
  const isPublic=id===GLOBAL_ROOM_ID||roomMeta?.is_public===true;
  $('header-room-kicker').textContent=id===GLOBAL_ROOM_ID?'RUANG BERSAMA':(isPublic?'RUANG KOMUNITAS':'OBROLAN PRIBADI');
  $('info-title').textContent=name;
  $('info-description').textContent=roomMeta?.description||(id===GLOBAL_ROOM_ID?'Ruang obrolan publik ndiflyChat':(isPublic?'Ruang komunitas ndiflyChat':'Percakapan pribadi antar pengguna'));
  $('info-type').textContent=isPublic?'Publik':'Pribadi';
  if($('info-my-username'))$('info-my-username').textContent='@'+(profile?.username||'pengguna');
  {const hi=$('header-room-icon');if(hi)hi.className=`fa-solid ${id===GLOBAL_ROOM_ID?'fa-earth-asia':'fa-comments'}`;}
  $('header-room-name').classList.toggle('profile-name-clickable',!isPublic); $('header-room-name').title=!isPublic?'Lihat informasi akun':'';
  if(!opts?.auto)$('app-screen').classList.add('chat-open');
  $('welcome-banner')?.classList.toggle('hidden',id!==GLOBAL_ROOM_ID||sessionHidden('ndifly_hide_global_welcome'));
  if($('message-search')?.value){$('message-search').value='';$('search-strip').classList.add('hidden');}
  $('info-read-count').textContent='—';chatStick=true;renderedCount=0;unseenCount=0;seenMsgIds.clear();updateJump();
  $('chat-messages').innerHTML='<div class="loading-state"><span class="spinner"></span><p>Memuat pesan...</p></div>';
  document.querySelectorAll('[data-room]').forEach(b=>b.classList.toggle('active',b.dataset.room===id));
  if(messageChannel){await supabase.removeChannel(messageChannel);messageChannel=null;}
  if(readChannel){await supabase.removeChannel(readChannel);readChannel=null;}
  readersByMessage.clear();
  let {data,error}=await supabase.from('chat_messages').select('*,profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').eq('room_id',id).order('created_at',{ascending:false}).limit(100);
  if(error&&/column|42703|PGRST204|schema cache/i.test(`${error.code||''} ${error.message||''}`)){
    ndiflyDbNotice('kolom pesan image_path/audio_path');
    for(const cols of ['id,room_id,sender_id,content,image_url,audio_url,reply_to,created_at','id,room_id,sender_id,content,created_at']){
      const retry=await supabase.from('chat_messages').select(cols+',profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').eq('room_id',id).order('created_at',{ascending:false}).limit(100);
      if(!retry.error){data=retry.data;error=null;break;}
    }
  }
  if(requestId!==roomOpenSequence)return;
  if(error){console.error(error);$('chat-messages').innerHTML='<div class="system-message">Pesan belum bisa dimuat. Coba lagi sebentar lagi.</div>';return;}
  messagesCache=await hydrateMessageMedia((data||[]).reverse());
  if(requestId!==roomOpenSequence)return;
  renderMessages(messagesCache);
  scheduleInboxRefresh();
  $('info-message-count').textContent=String(messagesCache.length);
  await refreshReadReceipts(messagesCache.filter(m=>m.sender_id===session.user.id).map(m=>m.id),false);
  if(requestId!==roomOpenSequence)return;
  messageChannel=supabase.channel('room-'+id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'chat_messages',filter:`room_id=eq.${id}`},async payload=>{
      if(messagesCache.some(m=>m.id===payload.new.id))return;
      const {data:msg}=await supabase.from('chat_messages').select('*,profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').eq('id',payload.new.id).maybeSingle();
      if(msg){const [hydrated]=await hydrateMessageMedia([msg]);messagesCache=[...messagesCache.filter(item=>String(item.id)!==String(hydrated.id)),hydrated].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)).slice(-100);renderMessages(messagesCache);$('info-message-count').textContent=String(messagesCache.length);}
    })
    .on('postgres_changes',{event:'DELETE',schema:'public',table:'chat_messages'},payload=>{
      const goneId=payload.old?.id;if(!goneId||!messagesCache.some(m=>String(m.id)===String(goneId)))return;
      messagesCache=messagesCache.filter(m=>String(m.id)!==String(goneId));renderMessages(messagesCache,false);$('info-message-count').textContent=String(messagesCache.length);scheduleInboxRefresh();
    }).subscribe(status=>{setConnection(status);if(requestId!==roomOpenSequence)return;if(status==='SUBSCRIBED')syncLatestRoomMessages(id,requestId).catch(error=>console.warn('[room message resync]',error));});
  readChannel=supabase.channel('read-receipts-'+id)
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'message_reads'},payload=>{
      const msg=messagesCache.find(m=>m.id===payload.new.message_id);
      if(msg&&msg.sender_id===session.user.id)refreshReadReceipts([msg.id],true);
    }).subscribe();
}
function setConnection(status){
  const el=$('connection-status');
  if(status==='SUBSCRIBED')el.innerHTML='<span class="online-dot"></span> Terhubung';
  else if(status==='CHANNEL_ERROR'||status==='TIMED_OUT')el.textContent='Koneksi terganggu · mencoba ulang';
  else el.textContent='Menghubungkan...';
}

// Kembali lewat tombol browser (mis. dari halaman telepon) bisa memulihkan halaman lama dengan koneksi realtime yang sudah putus.
window.addEventListener('pageshow',e=>{if(e.persisted)location.reload();});
function resyncActiveRoom(){
  if(!session?.user?.id||!activeRoom?.id)return;
  syncLatestRoomMessages(activeRoom.id,roomOpenSequence).catch(()=>{});scheduleInboxRefresh();
}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='visible')resyncActiveRoom();});
window.addEventListener('online',()=>{toast('Kembali online.','success');resyncActiveRoom();});
window.addEventListener('offline',()=>toast('Kamu sedang offline. Pesan dimuat ulang saat tersambung.','error'));

// ===== Panggilan: notifikasi di chat + jembatan ke halaman telepon (call.html) =====
// Media & sinyal diurus call.js. Di sini hanya: tombol telepon, banner "Bergabung", dan layar panggilan masuk.
const CALL_ROOM_LIMIT=40, RING_SILENCE_MS=10000;
const callListeners=new Map();          // roomId -> {channel, people:Map}
const chimedCalls=new Set(), dismissedCalls=new Set(), declinedCalls=new Set();
let incoming=null, callsUnavailableWarned=false;
function callUrl(roomId,mode,act,callId){return `call.html?room=${encodeURIComponent(roomId)}&mode=${mode==='video'?'video':'audio'}&act=${act}${callId?'&callId='+encodeURIComponent(callId):''}`;}
function startCall(mode){
  if(!activeRoom?.id){toast('Pilih ruang dulu.','error');return;}
  if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia){toast('Panggilan butuh koneksi aman. Buka ndiflyChat lewat alamat https://.','error');return;}
  const entry=callListeners.get(String(activeRoom.id));
  if(entry&&entry.people.size){const p=[...entry.people.values()][0];window.NdiflyTones?.stop();openCallFrame(callUrl(activeRoom.id,p.mode,'join',p.callId));return;}
  window.NdiflyTones?.stop();openCallFrame(callUrl(activeRoom.id,mode,'start'));
}
let callListenQueue=Promise.resolve();
function syncCallListeners(rooms){
  if(!supabase||!session?.user)return;
  const ids=[GLOBAL_ROOM_ID,...(rooms||[]).map(r=>String(r.id)).filter(id=>id!==GLOBAL_ROOM_ID)].slice(0,CALL_ROOM_LIMIT);
  ids.forEach(id=>{if(callListeners.has(id))return;callListeners.set(id,{channel:null,people:new Map(),pending:true});callListenQueue=callListenQueue.then(()=>listenCalls(id)).catch(()=>{});});
}
async function listenCalls(roomId){
  roomId=String(roomId);const entry=callListeners.get(roomId);if(!entry)return;
  const bind=ch=>ch
    .on('broadcast',{event:'ring'},({payload})=>onRing(roomId,payload))
    .on('broadcast',{event:'cancel'},({payload})=>onRingCancel(roomId,payload))
    .on('presence',{event:'sync'},()=>onCallPresence(roomId));
  const r=await window.NdiflyCallChannel.open(supabase,'call:'+roomId,{bind});
  if(!r.channel){
    callListeners.delete(roomId);
    if(!callsUnavailableWarned){callsUnavailableWarned=true;console.warn('[ndiflyChat · catatan untuk andif_dev] Notifikasi panggilan tidak aktif ('+r.error+'). Jalankan calls-setup.sql di Supabase SQL Editor dan pastikan Realtime aktif.');ndiflyDbNotice('izin panggilan realtime');}
    return;
  }
  entry.pending=false;
  if(!callListeners.has(roomId)){try{supabase.removeChannel(r.channel);}catch(_){}return;}
  entry.channel=r.channel;
}
function onCallPresence(roomId){
  const entry=callListeners.get(roomId);if(!entry?.channel)return;
  const people=new Map();
  Object.values(entry.channel.presenceState()||{}).forEach(list=>{const m=list[list.length-1];if(m?.uid&&m.uid!==session.user.id)people.set(m.uid,m);});
  entry.people=people;updateCallBanner();
}
function pickCallBanner(){
  if(callFrameOpen)return null;
  const order=[String(activeRoom?.id),GLOBAL_ROOM_ID,...callListeners.keys()];
  for(const id of order){
    const e=callListeners.get(id);if(!e||!e.people.size)continue;
    if(incoming&&incoming.roomId===id)continue;
    const first=[...e.people.values()][0];
    if(dismissedCalls.has(id+':'+(first.callId||'')))continue;
    return {id,e,first};
  }
  return null;
}
function updateCallBanner(){
  const b=$('call-banner');if(!b)return;
  const pick=pickCallBanner();
  if(!pick){
    // Presence bisa berkedip sesaat: tunggu sebentar sebelum menyembunyikan banner.
    if(b._hideT)return;
    b._hideT=setTimeout(()=>{b._hideT=null;if(pickCallBanner())return;b.classList.remove('show');clearTimeout(b._t);b._t=setTimeout(()=>{if(!b.classList.contains('show'))b.classList.add('hidden');},450);},2500);
    return;
  }
  clearTimeout(b._hideT);b._hideT=null;
  const {id,e,first}=pick;const people=[...e.people.values()];
  const mode=people.some(p=>p.mode==='video')?'video':'audio';const isGlobal=id===GLOBAL_ROOM_ID;
  const names=people.slice(0,3).map(p=>p.name||'Seseorang').join(', ')+(people.length>3?` +${people.length-3}`:'');
  $('banner-title').textContent=isGlobal?`Panggilan ${mode==='video'?'video':'suara'} di Global Community`:`${first.name||'Temanmu'} sedang menelepon`;
  $('banner-sub').textContent=`${names} · ${people.length} peserta di panggilan`;
  $('banner-icon').innerHTML=`<i class="fa-solid ${mode==='video'?'fa-video':'fa-phone-volume'}"></i>`;
  b.dataset.callRoom=id;b.dataset.mode=mode;b.dataset.callId=first.callId||'';
  clearTimeout(b._t);b.classList.remove('hidden');requestAnimationFrame(()=>b.classList.add('show'));
  const key=id+':'+(first.callId||'');
  if(!chimedCalls.has(key)){chimedCalls.add(key);window.NdiflyTones?.chime();try{if(navigator.vibrate&&navigator.userActivation?.hasBeenActive)navigator.vibrate([200,100,200]);}catch(_){}}
}
$('join-call-btn')?.addEventListener('click',()=>{const b=$('call-banner');window.NdiflyTones?.stop();openCallFrame(callUrl(b.dataset.callRoom,b.dataset.mode,'join',b.dataset.callId));});
$('dismiss-call-btn')?.addEventListener('click',()=>{const b=$('call-banner');dismissedCalls.add(b.dataset.callRoom+':'+(b.dataset.callId||''));updateCallBanner();});

// ===== Panggilan sebagai layar penuh DI DALAM halaman chat (chat tetap hidup di belakang) =====
let callFrameOpen=false, callInfo=null;
function openCallFrame(url){
  const wrap=$('call-frame-wrap'),frame=$('call-frame');if(!wrap||!frame){location.href=url;return;}
  if(callFrameOpen){toast('Kamu sedang dalam panggilan.');expandCall();return;}
  callFrameOpen=true;callInfo=null;
  frame.src=url+(url.includes('?')?'&':'?')+'embed=1';
  wrap.classList.remove('hidden','minimized');void wrap.offsetWidth;wrap.classList.add('open');
  $('call-mini')?.classList.add('hidden');document.body.classList.add('in-call');
  try{history.pushState({ndiCall:1},'');}catch(_){}
  updateCallBanner();
}
function closeCallFrame(){
  if(!callFrameOpen)return;callFrameOpen=false;callInfo=null;
  const wrap=$('call-frame-wrap');wrap.classList.remove('open','minimized');$('call-mini')?.classList.add('hidden');
  document.body.classList.remove('in-call');
  setTimeout(()=>{if(!callFrameOpen){$('call-frame').src='about:blank';wrap.classList.add('hidden');}},400);
  try{if(history.state&&history.state.ndiCall)history.back();}catch(_){}
  updateCallBanner();
}
function minimizeCall(){
  if(!callFrameOpen)return;
  $('call-frame-wrap').classList.add('minimized');$('call-mini').classList.remove('hidden');renderMini();
}
function expandCall(){
  if(!callFrameOpen)return;
  $('call-frame-wrap').classList.remove('minimized');$('call-mini')?.classList.add('hidden');
  try{if(!(history.state&&history.state.ndiCall))history.pushState({ndiCall:1},'');}catch(_){}
}
function renderMini(){
  const m=$('call-mini');if(!m||!callInfo)return;
  $('mini-name').textContent=callInfo.name||'Panggilan';
  $('mini-time').textContent=callInfo.timer||callInfo.status||'Menghubungkan…';
  const mic=$('mini-mic');mic.setAttribute('aria-pressed',String(!!callInfo.muted));mic.innerHTML=`<i class="fa-solid ${callInfo.muted?'fa-microphone-slash':'fa-microphone'}"></i>`;
  m.dataset.state=callInfo.state||'';
}
function sendToCall(type){try{$('call-frame').contentWindow.postMessage({ndifly:'call',type},location.origin);}catch(_){}}
window.addEventListener('message',e=>{
  if(e.origin!==location.origin||!e.data||e.data.ndifly!=='call')return;
  if(e.data.type==='ended')closeCallFrame();
  else if(e.data.type==='minimize')minimizeCall();
  else if(e.data.type==='state'){callInfo=e.data;if(!$('call-mini').classList.contains('hidden'))renderMini();}
});
window.addEventListener('popstate',()=>{if(callFrameOpen&&!$('call-frame-wrap').classList.contains('minimized'))minimizeCall();});
$('mini-expand')?.addEventListener('click',expandCall);
$('mini-mic')?.addEventListener('click',()=>sendToCall('toggle-mic'));
$('mini-end')?.addEventListener('click',()=>sendToCall('end'));

// Telepon pribadi: layar panggilan masuk (Terima / Tolak)
function paintCallAvatar(el,name,url){
  if(!el)return;let h=0;for(const ch of String(name))h=(h*31+ch.charCodeAt(0))>>>0;
  const P=[['#6f8bff','#3552e0'],['#a78bfa','#7c5cf0'],['#34d399','#0f9d6b'],['#f59e0b','#d97706'],['#fb7185','#e11d48'],['#22d3ee','#0e8fb0']][h%6];
  el.style.setProperty('--c1',P[0]);el.style.setProperty('--c2',P[1]);
  el.innerHTML=url?`<img src="${safe(url)}" alt="">`:safe((String(name||'?').trim().charAt(0)||'?').toUpperCase());
}
function onRing(roomId,p){
  if(!p||p.fromId===session?.user?.id||roomId===GLOBAL_ROOM_ID||callFrameOpen)return;
  if(declinedCalls.has(p.callId))return;
  if(incoming&&incoming.callId===p.callId){incoming.lastRing=Date.now();return;}
  if(incoming)return; // sudah ada panggilan masuk lain
  incoming={roomId,callId:p.callId,mode:p.mode==='video'?'video':'audio',fromId:p.fromId,fromName:p.fromName||'Temanmu',fromAvatar:p.fromAvatar||null,lastRing:Date.now(),prevTitle:document.title};
  $('incoming-name').textContent=incoming.fromName;
  $('incoming-kind').textContent=incoming.mode==='video'?'Panggilan video masuk…':'Panggilan suara masuk…';
  $('incoming-accept-ico').className=`fa-solid ${incoming.mode==='video'?'fa-video':'fa-phone'}`;
  paintCallAvatar($('incoming-avatar'),incoming.fromName,incoming.fromAvatar);
  $('incoming-call').classList.add('show');document.body.classList.add('has-incoming-call');
  document.title='📞 '+incoming.fromName+' menelepon…';
  window.NdiflyTones?.ringStart();
  incoming.watch=setInterval(()=>{if(incoming&&Date.now()-incoming.lastRing>RING_SILENCE_MS){toast(`Panggilan tak terjawab dari ${incoming.fromName}`);closeIncoming();}},1500);
  try{if(document.hidden&&'Notification' in window&&Notification.permission==='granted')new Notification(incoming.fromName+' menelepon',{body:'Buka ndiflyChat untuk menjawab.',tag:'ndifly-call'});}catch(_){}
  updateCallBanner();
}
function onRingCancel(roomId,p){
  if(!incoming||incoming.roomId!==roomId||(p?.callId&&p.callId!==incoming.callId))return;
  const who=incoming.fromName;closeIncoming();toast(`Panggilan tak terjawab dari ${who}`);
}
function closeIncoming(){
  if(!incoming)return;
  clearInterval(incoming.watch);document.title=incoming.prevTitle||document.title;incoming=null;
  $('incoming-call')?.classList.remove('show');document.body.classList.remove('has-incoming-call');
  window.NdiflyTones?.stop();updateCallBanner();
}
function declineIncoming(){
  if(!incoming)return;
  const entry=callListeners.get(incoming.roomId);declinedCalls.add(incoming.callId);
  try{entry?.channel?.send({type:'broadcast',event:'decline',payload:{callId:incoming.callId,from:session.user.id,name:profile?.username||''}});}catch(_){}
  closeIncoming();
}
function acceptIncoming(){
  if(!incoming)return;const {roomId,mode,callId}=incoming;window.NdiflyTones?.stop();
  closeIncoming();openCallFrame(callUrl(roomId,mode,'join',callId));
}
$('incoming-accept')?.addEventListener('click',acceptIncoming);
$('incoming-decline')?.addEventListener('click',declineIncoming);

// ===== Salam sesuai jam WIB + popup selamat datang =====
function wibNow(){
  const p=Object.fromEntries(new Intl.DateTimeFormat('id-ID',{timeZone:'Asia/Jakarta',hour:'2-digit',minute:'2-digit',hourCycle:'h23',weekday:'long',day:'numeric',month:'long'}).formatToParts(new Date()).map(x=>[x.type,x.value]));
  return {hour:Number(p.hour),text:`${p.weekday}, ${p.day} ${p.month} · ${p.hour}.${p.minute} WIB`,clock:`${p.hour}.${p.minute} WIB`};
}
function greetingFor(hour){
  if(hour>=5&&hour<12)return {text:'Good morning',icon:'fa-sun'};
  if(hour>=12&&hour<18)return {text:'Good afternoon',icon:'fa-cloud-sun'};
  if(hour>=18&&hour<21)return {text:'Good evening',icon:'fa-cloud-moon'};
  return {text:'Good night',icon:'fa-moon'};
}
let welcomeTimer=null;
function showWelcomePopup(){
  const el=$('welcome-toast');if(!el||!profile)return;
  try{if(sessionStorage.getItem('ndifly_welcome_shown')==='1')return;sessionStorage.setItem('ndifly_welcome_shown','1');}catch(_){}
  const now=wibNow(),g=greetingFor(now.hour),name=profile.display_name||profile.username||'teman';
  $('wt-greet').textContent=g.text;$('wt-title').textContent='Selamat datang, '+name;$('wt-time').textContent=now.text;
  $('wt-icon').className=`fa-solid ${g.icon}`;
  el.classList.remove('hidden','leaving');void el.offsetWidth;el.classList.add('show');
  clearTimeout(welcomeTimer);welcomeTimer=setTimeout(hideWelcomePopup,5000);
}
function hideWelcomePopup(){
  const el=$('welcome-toast');if(!el||el.classList.contains('hidden'))return;
  clearTimeout(welcomeTimer);el.classList.remove('show');el.classList.add('leaving');
  setTimeout(()=>{el.classList.add('hidden');el.classList.remove('leaving');},450);
}
$('wt-close')?.addEventListener('click',hideWelcomePopup);
function startGreetingClock(){
  const tick=()=>{const chip=$('my-greeting');if(!chip)return;const n=wibNow(),g=greetingFor(n.hour);chip.innerHTML=`<i class="fa-solid ${g.icon}"></i> ${g.text} · ${n.clock}`;};
  tick();setInterval(tick,30000);
}

// Search, panel and mobile navigation controls.
$('room-search').addEventListener('input',()=>{
  roomSearchSequence++;renderRoomList(roomsCache);clearTimeout(roomSearchTimer);
  const query=$('room-search').value.trim();
  if(!query){$('user-search-results').classList.add('hidden');$('user-search-results').replaceChildren();roomSearchSequence++;return;}
  roomSearchTimer=setTimeout(()=>searchUsers(query),250);
});
$('message-search').addEventListener('input',()=>renderMessages(messagesCache,false));
$('search-toggle').addEventListener('click',()=>{$('search-strip').classList.toggle('hidden');if(!$('search-strip').classList.contains('hidden'))$('message-search').focus();else{$('message-search').value='';renderMessages(messagesCache,false);}});
$('close-search').addEventListener('click',()=>{$('message-search').value='';$('search-strip').classList.add('hidden');renderMessages(messagesCache,false);});
$('info-btn').addEventListener('click',()=>$('info-panel').classList.toggle('hidden'));
function sessionHidden(key){try{return sessionStorage.getItem(key)==='1';}catch(_){return false;}}
const closeWelcome=$('close-welcome');if(closeWelcome)closeWelcome.addEventListener('click',()=>{$('welcome-banner').classList.add('hidden');try{sessionStorage.setItem('ndifly_hide_global_welcome','1');}catch(_){}});
try{if(sessionStorage.getItem('ndifly_hide_global_welcome')==='1')$('welcome-banner')?.classList.add('hidden');}catch(_){}
$('close-info').addEventListener('click',()=>$('info-panel').classList.add('hidden'));
$('mobile-back').addEventListener('click',()=>{$('app-screen').classList.remove('chat-open');$('sidebar').classList.remove('mobile-hidden');$('info-panel').classList.add('hidden');});
$('room-search').addEventListener('keydown',event=>{if(event.key==='Escape'){$('room-search').value='';renderRoomList(roomsCache);$('user-search-results').classList.add('hidden');roomSearchSequence++;}});
document.addEventListener('keydown',event=>{if(event.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement?.tagName)&&!event.ctrlKey&&!event.metaKey){event.preventDefault();$('room-search').focus();}});
$('voice-call-btn').addEventListener('click',()=>startCall('audio'));
$('video-call-btn').addEventListener('click',()=>startCall('video'));
const URL_RE=/\bhttps?:\/\/[^\s<]+/gi;
function linkify(escaped){
  return escaped.replace(URL_RE,raw=>{
    let url=raw,tail='';const m=url.match(/(?:[.,!?;:)\]]|&quot;|&#39;|&gt;)+$/);
    if(m){tail=m[0];url=url.slice(0,-tail.length);}
    if(url.length<10)return raw;
    return `<a href="${url}" target="_blank" rel="noopener noreferrer nofollow">${url}</a>${tail}`;
  });
}
function dayLabel(d){
  const now=new Date(),y=new Date(now);y.setDate(now.getDate()-1);
  if(d.toDateString()===now.toDateString())return 'Hari ini';
  if(d.toDateString()===y.toDateString())return 'Kemarin';
  return d.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:d.getFullYear()===now.getFullYear()?undefined:'numeric'});
}
// scroll: true = follow only when already near the bottom, 'force' = always jump down, false = keep position.

/* ===== Log panggilan & kutipan balasan status di dalam chat ===== */
function fmtDuration(sec){sec=Math.max(0,Math.round(Number(sec)||0));const h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;if(h)return `${h} jam ${m} mnt`;if(m)return `${m} mnt ${s} dtk`;return `${s} dtk`;}
function callLogHtml(m,mine,d,isNew){
  const meta=m.meta||{},mode=meta.mode==='video'?'video':'audio',st=meta.status||'completed';
  const kind=mode==='video'?'Panggilan video':'Panggilan suara';
  const labels={completed:fmtDuration(meta.duration),missed:mine?'Tidak dijawab':'Tak terjawab',declined:mine?'Ditolak':'Kamu menolak',canceled:mine?'Dibatalkan':'Tak terjawab',failed:'Gagal tersambung'};
  const bad=st!=='completed'&&(!mine||st==='failed'),icon=mode==='video'?'fa-video':'fa-phone',arrow=mine?'fa-arrow-up-right':'fa-arrow-down-left';
  const date=d.toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'}),time=d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}).replace(':','.');
  return `<article class="message-row call-log-row ${mine?'mine':''} ${isNew?'msg-in':''}" data-id="${safe(m.id)}"><div class="call-log-card ${st} ${bad?'is-bad':''}"><span class="call-log-ico"><i class="fa-solid ${icon}"></i></span><div class="call-log-body"><b>${kind}</b><span class="call-log-state"><i class="fa-solid ${arrow}"></i> ${mine?'Keluar':'Masuk'} · ${safe(labels[st]||'')}</span><small>${safe(date)} · ${safe(time)}</small></div><button type="button" class="call-log-again" data-call-again="${mode}" aria-label="Panggil lagi"><i class="fa-solid ${icon}"></i></button></div></article>`;
}
function statusQuoteHtml(m,mine){
  const meta=m.meta||{},ownerMine=String(meta.owner_id||'')===String(session?.user?.id||''),video=meta.media_type==='video';
  const who=ownerMine?'Status kamu':`Status ${meta.owner_name?'@'+safe(meta.owner_name):''}`;
  const cap=(meta.caption||'').trim()||(video?'Video':'Foto');
  return `<button type="button" class="status-quote" data-status-open="${safe(meta.status_id||'')}" data-status-owner="${safe(meta.owner_id||'')}"><span class="status-quote-text"><b><i class="fa-solid fa-circle-dot"></i> ${who}</b><small>${safe(cap.slice(0,90))}</small></span><span class="status-quote-thumb" ${meta.media_path&&!video?`data-status-thumb="${safe(meta.media_path)}"`:''}><i class="fa-solid ${video?'fa-video':'fa-image'}"></i></span></button>`;
}
const statusThumbCache=new Map();
async function hydrateStatusThumbs(root){
  const nodes=[...root.querySelectorAll('[data-status-thumb]:not([data-done])')];
  for(const el of nodes){
    el.dataset.done='1';const path=el.dataset.statusThumb;let url=statusThumbCache.get(path);
    if(url===undefined){try{const {data,error}=await supabase.storage.from('chat-status').createSignedUrl(path,3600);url=error?null:data?.signedUrl||null;}catch(_){url=null;}statusThumbCache.set(path,url);}
    if(url){el.style.backgroundImage=`url("${url}")`;el.classList.add('has-img');el.replaceChildren();}else{el.classList.add('is-expired');}
  }
}
function renderMessages(messages,scroll=true){
  const container=$('chat-messages');
  const prevTop=container.scrollTop;
  // `chatStick` is tracked by the scroll listener, so a re-render during a smooth-scroll animation cannot drop the user off the bottom.
  const stick=scroll==='force'||(scroll===true&&chatStick);
  if(scroll==='force')chatStick=true;
  const query=$('message-search').value.trim().toLowerCase();
  const filtered=query?messages.filter(m=>(m.content||'').toLowerCase().includes(query)||(m.profiles?.username||'').toLowerCase().includes(query)):messages;
  if(!filtered.length){container.innerHTML=`<div class="loading-state empty-conversation"><div class="empty-chat-icon"><i class="fa-regular fa-comments"></i></div><p>${query?'Pesan tidak ditemukan.':'Belum ada pesan. Mulai percakapan pertama!'}</p><small>${query?'Coba kata kunci lain.':'Jadilah orang pertama yang menyapa ruang ini.'}</small></div>`;return;}
  let lastDay='',prevMsg=null;
  const animateNew=!query&&seenMsgIds.size>0; // only messages that arrive after the first paint pop in
  container.innerHTML=filtered.map(m=>{
    const mine=m.sender_id===session?.user?.id, usernameRaw=m.profiles?.username||'', username=m.profiles?.username||m.profiles?.display_name||'Pengguna';
    const d=new Date(m.created_at), time=d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
    const date=d.toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'});
    const img=m.image_url?`<img src="${safe(m.image_url)}" alt="Gambar yang dibagikan" loading="lazy">`:'';
    const audio=m.audio_url?`<div class="vn-player"><span class="vn-player-icon"><i class="fa-solid fa-microphone-lines"></i></span><audio controls preload="metadata" src="${safe(m.audio_url)}"></audio><span class="vn-player-label">Pesan suara</span></div>`:'';
    const content=linkify(safe(m.content||''));
    const repliedMessage=m.reply_to?messagesCache.find(item=>String(item.id)===String(m.reply_to)):null;
    const repliedName=repliedMessage?(repliedMessage.profiles?.username||repliedMessage.profiles?.display_name||'Pengguna'):'Pesan sebelumnya';
    const repliedText=repliedMessage?(repliedMessage.content|| (repliedMessage.image_url?'Foto':'Pesan')):'Pesan yang dibalas';
    const replyBase=m.reply_to?`<div class="reply-quote"><span class="reply-quote-line"></span><div class="reply-quote-body"><strong><i class="fa-solid fa-reply"></i> ${safe(repliedName)}</strong><span>${safe(String(repliedText).slice(0,110))}</span></div></div>`:'';
    const reply=(m.kind==='status_reply'?statusQuoteHtml(m,mine):'')+replyBase;
    const readers=mine?(readersByMessage.get(String(m.id))||[]):[];
    const readerCount=readers.length;
    const initials=readers.slice(0,3).map(r=>safe((r.profiles?.username||r.profiles?.display_name||'?' ).charAt(0).toUpperCase())).map(ch=>`<span class="reader-mini-avatar">${ch}</span>`).join('');
    const status=mine?`<button type="button" class="message-status read-status ${readerCount?'is-read':''}" data-readers="${safe(m.id)}" title="Lihat siapa yang membaca"><span class="reader-stack">${initials}</span><span>${readerCount?`Dibaca oleh ${readerCount}`:'Terkirim'}</span><i class="fa-solid ${readerCount?'fa-check-double':'fa-check'}"></i></button>`:'';
    const dayKey=d.toDateString();
    const divider=(!query&&dayKey!==lastDay)?`<div class="day-divider" role="separator"><span>${safe(dayLabel(d))}</span></div>`:'';
    const grouped=!query&&!divider&&prevMsg&&prevMsg.sender_id===m.sender_id&&prevMsg.kind!=='call'&&m.kind!=='status_reply'&&(d-new Date(prevMsg.created_at))<5*60*1000&&!m.reply_to;
    lastDay=dayKey;prevMsg=m;
    const isNew=animateNew&&!seenMsgIds.has(String(m.id));
    if(m.kind==='call')return divider+callLogHtml(m,mine,d,isNew);
    return divider+`<article class="message-row ${mine?'mine':''} ${grouped?'is-grouped':''} ${isNew?'msg-in':''}" data-id="${safe(m.id)}"><div class="message-avatar ${m.profiles?.avatar_url?'has-profile-photo':''}" title="@${safe(m.profiles?.username||username)}">${m.profiles?.avatar_url?`<img src="${safe(m.profiles.avatar_url)}" alt="Foto profil" loading="lazy">`:safe(username.charAt(0).toUpperCase())}</div><div class="message-content"><div class="message-meta"><b>${mine?(isVerified(profile?.username)?'Kamu'+verifiedBadge(profile.username):'Kamu'):safe(username)+verifiedBadge(usernameRaw)}</b><span title="${safe(date)}">${time}</span></div><div class="bubble">${reply}${img}${audio}${content}</div><div class="message-actions"><button type="button" data-reply="${safe(m.id)}" data-content="${safe((m.content||(m.audio_url?'Pesan suara':m.image_url?'Gambar':'Pesan')).slice(0,120))}"><i class="fa-solid fa-reply"></i> Balas</button>${mine?`<button type="button" data-delete="${safe(m.id)}"><i class="fa-regular fa-trash-can"></i> Hapus</button>`:''}</div>${status}</div></article>`;
  }).join('');
  container.querySelectorAll('[data-reply]').forEach(b=>b.addEventListener('click',()=>setReply(b.dataset.reply,b.dataset.content)));
  container.querySelectorAll('[data-status-open]').forEach(b=>b.addEventListener('click',()=>window.ndiflyOpenStatus?window.ndiflyOpenStatus(b.dataset.statusOwner,b.dataset.statusOpen):toast('Status belum siap.','error')));
  container.querySelectorAll('[data-call-again]').forEach(b=>b.addEventListener('click',()=>startCall(b.dataset.callAgain)));
  hydrateStatusThumbs(container);
  container.querySelectorAll('[data-delete]').forEach(b=>b.addEventListener('click',()=>deleteMessage(b.dataset.delete)));
  container.querySelectorAll('[data-readers]').forEach(b=>b.addEventListener('click',()=>showReaders(b.dataset.readers)));
  $('info-message-count').textContent=String(messagesCache.length);
  if(!query)messages.forEach(m=>seenMsgIds.add(String(m.id)));
  if(!query){ if(!stick&&scroll===true&&renderedCount>0&&messages.length>renderedCount)unseenCount+=messages.length-renderedCount; renderedCount=messages.length; }
  if(stick)unseenCount=0;
  observeIncomingMessages(filtered);
  if(stick){
    jumpScroll(container,container.scrollHeight);
    // Images change the height after they load; keep following the bottom.
    container.querySelectorAll('.bubble img').forEach(img=>{if(!img.complete)img.addEventListener('load',()=>{if(chatStick)jumpScroll(container,container.scrollHeight);},{once:true});});
  }else jumpScroll(container,prevTop);
  updateJump();
}
function updateJump(){const b=$('jump-latest');if(!b)return;b.classList.toggle('hidden',chatStick);b.classList.toggle('has-new',unseenCount>0);const n=$('jump-count');if(n)n.textContent=unseenCount>0?(unseenCount>99?'99+':String(unseenCount)):'';}
$('jump-latest')?.addEventListener('click',()=>{const c=$('chat-messages');chatStick=true;unseenCount=0;c.scrollTo({top:c.scrollHeight,behavior:'smooth'});updateJump();});
function jumpScroll(el,top){const prev=el.style.scrollBehavior;el.style.scrollBehavior='auto';el.scrollTop=top;el.style.scrollBehavior=prev;}
$('chat-messages').addEventListener('scroll',()=>{const c=$('chat-messages');chatStick=c.scrollHeight-c.scrollTop-c.clientHeight<160;if(chatStick)unseenCount=0;updateJump();},{passive:true});

async function refreshReadReceipts(messageIds,rerender=true){
  const ids=[...new Set((messageIds||[]).filter(Boolean).map(String))];
  if(!ids.length||!session?.user?.id)return;
  try{
    const {data,error}=await supabase.from('message_reads')
      .select('message_id,reader_id,read_at,profiles:profiles!message_reads_reader_id_fkey(username,display_name,avatar_url)')
      .in('message_id',ids);
    if(error)throw error;
    ids.forEach(id=>readersByMessage.set(id,[]));
    (data||[]).forEach(row=>{
      const id=String(row.message_id);
      if(!readersByMessage.has(id))readersByMessage.set(id,[]);
      readersByMessage.get(id).push(row);
    });
    const totalRead=[...readersByMessage.values()].filter(rows=>rows.length>0).length;
    $('info-read-count').textContent=String(totalRead);
    if(rerender)renderMessages(messagesCache,false);
  }catch(error){
    console.warn('READ_RECEIPTS_LOAD_ERROR:',error);
    if(!readReceiptErrorShown){readReceiptErrorShown=true;toast('Status dibaca sedang disiapkan.','error');}
  }
}

function observeIncomingMessages(messages){
  if(!('IntersectionObserver' in window) || typeof messageReadObserver === 'undefined'){
    const visible=(messages||[]).filter(m=>m.sender_id!==session?.user?.id);
    if(visible.length)markMessagesRead(visible);
    return;
  }
  if(!messageReadObserver){
    messageReadObserver=new IntersectionObserver(entries=>{
      for(const entry of entries){
        if(entry.isIntersecting&&(entry.intersectionRatio>=0.5||entry.intersectionRect.height>=Math.min(entry.boundingClientRect.height,(entry.rootBounds?.height||600)*0.5))){
          const row=entry.target;
          const msg=messagesCache.find(m=>String(m.id)===String(row.dataset.id));
          if(msg&&msg.sender_id!==session?.user?.id){
            markMessagesRead([msg]).then(marked=>{if(marked)messageReadObserver?.unobserve(row);});
          }else{messageReadObserver.unobserve(row);}
        }
      }
    },{root:$('chat-messages'),threshold:[0.1,0.5,0.9]});
  }
  document.querySelectorAll('#chat-messages .message-row:not(.mine)').forEach(row=>{
    if(!readMessagesHandled.has(String(row.dataset.id)))messageReadObserver.observe(row);
  });
}

async function markMessagesRead(messages){
  const unread=(messages||[]).filter(m=>m&&m.id&&m.sender_id!==session?.user?.id&&!readReceiptInFlight.has(String(m.id))&&!readMessagesHandled.has(String(m.id)));
  if(!unread.length||!session?.user?.id)return;
  const ids=unread.map(m=>String(m.id));
  ids.forEach(id=>readReceiptInFlight.add(id));
  try{
    const {data:existing,error:checkError}=await supabase.from('message_reads').select('message_id').eq('reader_id',session.user.id).in('message_id',ids);
    if(checkError)throw checkError;
    const seen=new Set((existing||[]).map(row=>String(row.message_id)));
    const rows=unread.filter(m=>!seen.has(String(m.id))).map(m=>({message_id:m.id,reader_id:session.user.id}));
    if(rows.length){
      const {error}=await supabase.from('message_reads').insert(rows);
      if(error&&error.code!=='23505')throw error;
    }
    ids.forEach(id=>readMessagesHandled.add(id));
    scheduleInboxRefresh();
    return true;
  }catch(error){
    console.warn('MARK_READ_ERROR:',error);
    if(!readReceiptErrorShown){readReceiptErrorShown=true;toast('Status dibaca sedang disiapkan.','error');}
    return false;
  }finally{ids.forEach(id=>readReceiptInFlight.delete(id));}
}

async function showReaders(messageId){
  const message=messagesCache.find(m=>String(m.id)===String(messageId));
  if(!message||message.sender_id!==session?.user?.id)return;
  $('readers-modal').classList.remove('hidden');
  $('readers-modal-subtitle').textContent='Memuat daftar pembaca…';
  $('readers-list').innerHTML='<div class="readers-empty"><span class="spinner"></span><p>Memuat status baca…</p></div>';
  await refreshReadReceipts([messageId],false);
  const rows=readersByMessage.get(String(messageId))||[];
  $('readers-modal-subtitle').textContent=rows.length?`${rows.length} akun telah membaca pesan ini`:'Belum ada akun lain yang membaca pesan ini';
  $('readers-list').innerHTML=rows.length?rows.slice().sort((a,b)=>new Date(b.read_at)-new Date(a.read_at)).map(r=>{
    const username=r.profiles?.username||r.profiles?.display_name||'Pengguna';
    const time=new Date(r.read_at).toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
    return `<div class="reader-entry"><div class="reader-avatar ${r.profiles?.avatar_url?'has-profile-photo':''}">${r.profiles?.avatar_url?`<img src="${safe(r.profiles.avatar_url)}" alt="" loading="lazy">`:safe(username.charAt(0).toUpperCase())}</div><div class="reader-entry-copy"><b>${safe(username)}</b><small>@${safe(r.profiles?.username||'pengguna')}</small></div><div class="reader-entry-time"><i class="fa-solid fa-check-double"></i><span>${safe(time)}</span></div></div>`;
  }).join(''):'<div class="readers-empty"><div class="readers-empty-icon"><i class="fa-regular fa-eye-slash"></i></div><b>Belum dibaca</b><p>Daftar akan muncul ketika pengguna lain membuka ruang dan pesan ini terlihat.</p></div>';
}
$('close-readers').addEventListener('click',()=>$('readers-modal').classList.add('hidden'));
$('readers-modal').addEventListener('click',e=>{if(e.target===$('readers-modal'))$('readers-modal').classList.add('hidden');});

async function sendMessage(event){
  event?.preventDefault();
  if(sending)return;
  const input=$('message-input'), content=input.value.trim();
  if(!content&&!pendingImage&&!pendingVoiceBlob)return;
  if(content.length>4000){toast('Pesan terlalu panjang.','error');return;}
  sending=true;$('send-btn').disabled=true;
  let uploadedImagePath=null,uploadedVoicePath=null;
  try{
    let image_url=null,image_path=null;
    if(pendingImage){
      const file=pendingImage;
      const supportedTypes=['image/png','image/jpeg','image/webp'];
      if(!supportedTypes.includes(file.type))throw new Error('Format gambar harus PNG, JPG, atau WEBP.');
      if(file.size>5*1024*1024)throw new Error('Ukuran gambar maksimal 5 MB.');
      const ext=({ 'image/png':'png','image/jpeg':'jpg','image/webp':'webp' })[file.type]||'webp';
      const path=`${session.user.id}/${crypto.randomUUID()}.${ext}`;
      const {error:uploadError}=await supabase.storage.from('chat-media').upload(path,file,{upsert:false,contentType:file.type||'image/webp'});
      if(uploadError)throw uploadError;
      uploadedImagePath=path;
      image_path=path;
    }
    let audio_url=null,audio_path=null;
    if(pendingVoiceBlob){
      const blob=pendingVoiceBlob;const ext=blob.type.includes('mp4')?'mp4':blob.type.includes('ogg')?'ogg':'webm';
      const path=`${session.user.id}/${crypto.randomUUID()}.${ext}`;
      const {error:voiceError}=await supabase.storage.from('chat-media').upload(path,blob,{upsert:false,contentType:(blob.type||'audio/webm').split(';')[0]});
      if(voiceError)throw voiceError;uploadedVoicePath=path;
      audio_path=path;
    }
    const targetRoomId=activeRoom.id;
    const row={room_id:targetRoomId,sender_id:session.user.id,content,image_url,audio_url,image_path,audio_path,reply_to:replyTo};
    const {data,error}=await supabase.from('chat_messages').insert(row).select('*,profiles:profiles!chat_messages_sender_id_fkey(username,display_name,avatar_url)').single();
    if(error)throw error;
    const [hydratedMessage]=await hydrateMessageMedia([data]);
    // The user may have switched rooms while the upload was running; never paint this message into another room.
    if(String(activeRoom.id)===String(targetRoomId)&&!messagesCache.some(m=>String(m.id)===String(hydratedMessage.id))){messagesCache=[...messagesCache,hydratedMessage].sort((a,b)=>new Date(a.created_at)-new Date(b.created_at)).slice(-100);renderMessages(messagesCache,'force');}
    scheduleInboxRefresh();
    input.value='';resizeInput();clearAttachment();clearReply();clearVoicePreview();
    {const sb=$('send-btn');sb.classList.remove('sent');void sb.offsetWidth;sb.classList.add('sent');}$('char-count').textContent='0 / 4000';$('emoji-menu').classList.add('hidden');
  }catch(err){
    if(uploadedImagePath){try{await supabase.storage.from('chat-media').remove([uploadedImagePath]);}catch(cleanupError){console.warn('[image cleanup]',cleanupError);}}if(uploadedVoicePath){try{await supabase.storage.from('chat-media').remove([uploadedVoicePath]);}catch(cleanupError){console.warn('[voice cleanup]',cleanupError);}}
    console.error(err);toast(err.message||'Pesan gagal dikirim.','error');
  }
  finally{sending=false;$('send-btn').disabled=false;input.focus();}
}

// Voice notes: shared composer supports both private rooms and Global Community.
let voiceRecorder=null,voiceStream=null,voiceChunks=[],pendingVoiceBlob=null,voiceStartedAt=0,voiceClock=null;
const vnMime=()=>['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg'].find(type=>window.MediaRecorder&&MediaRecorder.isTypeSupported(type))||'';
function vnTime(seconds){const s=Math.max(0,Math.floor(seconds));return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`;}
function stopVoiceTracks(){voiceStream?.getTracks().forEach(track=>track.stop());voiceStream=null;}
function clearVoicePreview(){pendingVoiceBlob=null;const preview=$('vn-preview'),audio=$('vn-preview-audio');if(audio){audio.pause();audio.removeAttribute('src');audio.load();}preview?.classList.add('hidden');$('vn-recorder')?.classList.add('hidden');$('vn-btn')?.classList.remove('is-recording');}
$('vn-btn')?.addEventListener('click',async()=>{
  if(voiceRecorder?.state==='recording'){voiceRecorder.stop();return;}
  if(!navigator.mediaDevices?.getUserMedia||!window.MediaRecorder){toast('VN tidak didukung browser ini. Coba browser terbaru.','error');return;}
  try{
    if(pendingVoiceBlob)clearVoicePreview();
    voiceStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    voiceChunks=[];const mime=vnMime();voiceRecorder=new MediaRecorder(voiceStream,mime?{mimeType:mime}:undefined);
    voiceRecorder.ondataavailable=e=>{if(e.data?.size)voiceChunks.push(e.data);};
    voiceRecorder.onstop=()=>{stopVoiceTracks();clearInterval(voiceClock);$('vn-recorder')?.classList.add('hidden');$('vn-btn')?.classList.remove('is-recording');
      if(!voiceChunks.length)return;pendingVoiceBlob=new Blob(voiceChunks,{type:voiceRecorder.mimeType||'audio/webm'});
      const url=URL.createObjectURL(pendingVoiceBlob);$('vn-preview-audio').src=url;$('vn-preview').classList.remove('hidden');$('vn-recorder-label').textContent='VN siap dikirim';};
    voiceRecorder.start(250);voiceStartedAt=Date.now();$('vn-recorder').classList.remove('hidden');$('vn-btn').classList.add('is-recording');
    $('vn-recorder-label').textContent='Merekam suara';$('vn-recorder-time').textContent='00:00';
    voiceClock=setInterval(()=>{const elapsed=(Date.now()-voiceStartedAt)/1000;$('vn-recorder-time').textContent=vnTime(elapsed);if(elapsed>=180&&voiceRecorder?.state==='recording')voiceRecorder.stop();},250);
  }catch(error){stopVoiceTracks();console.error('[voice note]',error);toast(error.name==='NotAllowedError'?'Izinkan akses mikrofon untuk merekam VN.':'Mikrofon tidak dapat digunakan.','error');}
});
$('vn-stop')?.addEventListener('click',()=>{if(voiceRecorder?.state==='recording')voiceRecorder.stop();});
$('vn-cancel')?.addEventListener('click',()=>{if(voiceRecorder?.state==='recording'){voiceRecorder.onstop=null;voiceRecorder.stop();}stopVoiceTracks();clearInterval(voiceClock);clearVoicePreview();voiceChunks=[];});
$('vn-discard')?.addEventListener('click',clearVoicePreview);
$('vn-send')?.addEventListener('click',()=>{if(!pendingVoiceBlob)return;sendMessage();});

$('composer').addEventListener('submit',sendMessage);
$('message-input').addEventListener('input',()=>{resizeInput();$('char-count').textContent=`${$('message-input').value.length} / 4000`;});
$('message-input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey&&!e.isComposing&&e.keyCode!==229){e.preventDefault();sendMessage();}});
function resizeInput(){const el=$('message-input');el.style.height='auto';el.style.height=Math.min(el.scrollHeight,140)+'px';}
$('attach-btn').addEventListener('click',()=>$('file-input').click());
async function compressImageBeforeSend(file){
  if(!file||!String(file.type||'').startsWith('image/'))throw new Error('Pilih file gambar yang valid.');
  if(file.size>15*1024*1024)throw new Error('Foto asli maksimal 15 MB sebelum dikompres.');
  const objectUrl=URL.createObjectURL(file);
  try{
    const image=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Gambar tidak bisa dibuka. Pilih foto lain.'));img.src=objectUrl;});
    const originalWidth=image.naturalWidth||image.width,originalHeight=image.naturalHeight||image.height;
    if(!originalWidth||!originalHeight)throw new Error('Dimensi gambar tidak valid.');
    const maxSide=Math.max(originalWidth,originalHeight)>2000?1600:Math.max(originalWidth,originalHeight);
    const scale=Math.min(1,maxSide/Math.max(originalWidth,originalHeight));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(originalWidth*scale));canvas.height=Math.max(1,Math.round(originalHeight*scale));
    const ctx=canvas.getContext('2d',{alpha:true});if(!ctx)throw new Error('Browser tidak mendukung kompresi gambar.');
    ctx.drawImage(image,0,0,canvas.width,canvas.height);
    const toBlob=quality=>new Promise(resolve=>canvas.toBlob(resolve,'image/webp',quality));
    let blob=await toBlob(.82);if(!blob)throw new Error('Kompresi foto gagal.');
    if(blob.size>4.7*1024*1024)blob=await toBlob(.68);
    if(blob.size>4.7*1024*1024){const smaller=document.createElement('canvas');const factor=Math.min(1,1200/Math.max(canvas.width,canvas.height));smaller.width=Math.max(1,Math.round(canvas.width*factor));smaller.height=Math.max(1,Math.round(canvas.height*factor));smaller.getContext('2d').drawImage(canvas,0,0,smaller.width,smaller.height);blob=await new Promise(resolve=>smaller.toBlob(resolve,'image/webp',.62));}
    if(!blob)throw new Error('Kompresi foto gagal.');
    if(blob.size>5*1024*1024)throw new Error('Foto masih melebihi batas setelah dikompres.');
    const safeName=(file.name||'foto').replace(/\.[^.]+$/,'').replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,70)||'foto';
    return new File([blob],`${safeName}.webp`,{type:'image/webp',lastModified:Date.now()});
  }finally{URL.revokeObjectURL(objectUrl);}
}
$('file-input').addEventListener('change',async e=>{
  const file=e.target.files?.[0];if(!file)return;
  if(!['image/png','image/jpeg','image/webp'].includes(file.type)){toast('Format gambar harus PNG, JPG, atau WEBP.','error');e.target.value='';return;}
  const button=$('attach-btn');button.disabled=true;
  try{
    toast('Mengompres foto…');
    const compressed=await compressImageBeforeSend(file);
    pendingImage=compressed;showAttachment(compressed);
    const before=(file.size/1024).toFixed(0),after=(compressed.size/1024).toFixed(0);
    toast(`Foto dikompres · ${before} KB → ${after} KB`,'success');
  }catch(error){clearAttachment();console.error('[image compression]',error);toast(error.message||'Foto gagal diproses.','error');e.target.value='';}
  finally{button.disabled=false;}
});
$('emoji-btn').addEventListener('click',()=>$('emoji-menu').classList.toggle('hidden'));
$('emoji-menu').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{$('message-input').value += b.textContent;$('message-input').focus();resizeInput();$('char-count').textContent=`${$('message-input').value.length} / 4000`;$('emoji-menu').classList.add('hidden');}));
function showAttachment(file){
  const box=$('attach-preview');if(!box)return;
  if(attachUrl)URL.revokeObjectURL(attachUrl);
  attachUrl=URL.createObjectURL(file);
  $('attach-thumb').src=attachUrl;$('attach-name').textContent=file.name||'Foto';
  $('attach-size').textContent=Math.max(1,Math.round(file.size/1024))+' KB · siap dikirim';
  box.classList.remove('hidden');
}
function clearAttachment(){
  pendingImage=null;const fi=$('file-input');if(fi)fi.value='';
  if(attachUrl){URL.revokeObjectURL(attachUrl);attachUrl=null;}
  $('attach-preview')?.classList.add('hidden');
}
$('attach-remove')?.addEventListener('click',clearAttachment);
document.addEventListener('click',e=>{const menu=$('emoji-menu');if(menu&&!menu.classList.contains('hidden')&&!e.target.closest('#emoji-menu,#emoji-btn'))menu.classList.add('hidden');});
function openLightbox(src){
  const box=document.createElement('div');box.className='lightbox';box.setAttribute('role','dialog');box.setAttribute('aria-modal','true');box.setAttribute('aria-label','Pratinjau gambar');
  box.innerHTML='<button type="button" class="lightbox-close" aria-label="Tutup"><i class="fa-solid fa-xmark"></i></button><img alt="Gambar yang dibagikan">';
  box.querySelector('img').src=src;
  const onKey=e=>{if(e.key==='Escape'){e.stopPropagation();close();}};
  const close=()=>{box.remove();document.removeEventListener('keydown',onKey,true);};
  box.addEventListener('click',close);document.addEventListener('keydown',onKey,true);document.body.appendChild(box);
}
$('chat-messages').addEventListener('click',e=>{const img=e.target.closest?.('.bubble img');if(img&&img.src)openLightbox(img.currentSrc||img.src);});
function setReply(id,text){replyTo=id;$('reply-text').textContent=text;$('reply-preview').classList.remove('hidden');$('message-input').focus();}
function clearReply(){replyTo=null;$('reply-preview').classList.add('hidden');}
$('cancel-reply').addEventListener('click',clearReply);
function deleteMessage(id){
  openActionModal({
    type:'delete',
    eyebrow:'KONFIRMASI PESAN',
    icon:'fa-trash-can',
    title:'Hapus pesan ini?',
    description:'Pesan ini akan dihapus dari ruang percakapan. Tindakan ini tidak dapat dibatalkan.',
    confirmLabel:'Hapus pesan',
    safety:'<i class="fa-solid fa-circle-info"></i> Hanya pesanmu sendiri yang bisa dihapus.',
    onConfirm:async()=>{
      const target=messagesCache.find(m=>String(m.id)===String(id));
      const {data:removed,error}=await supabase.from('chat_messages').delete().eq('id',id).eq('sender_id',session.user.id).select('id');
      if(error||!removed?.length)throw new Error('Pesan tidak bisa dihapus. Coba lagi.');
      const paths=[target?.image_path,target?.audio_path].filter(Boolean);
      if(paths.length){const {error:mediaError}=await supabase.storage.from('chat-media').remove(paths);if(mediaError)console.warn('[deleted message media cleanup]',mediaError.message);}
      messagesCache=messagesCache.filter(m=>String(m.id)!==String(id));
      renderMessages(messagesCache);
      toast('Pesan berhasil dihapus.','success');
    }
  });
}
const lastMsgToast=new Map();
async function notifyNewMessage(m){
  try{
    if(!m||!session?.user||m.sender_id===session.user.id)return;
    const sameRoom=String(m.room_id)===String(activeRoom?.id);
    if(sameRoom&&!document.hidden)return;
    const now=Date.now();if(now-(lastMsgToast.get(m.room_id)||0)<6000)return;lastMsgToast.set(m.room_id,now);
    let name='Seseorang';
    const {data:p}=await supabase.from('profiles').select('username,display_name').eq('id',m.sender_id).maybeSingle();
    if(p)name=p.display_name||p.username||name;
    const isGlobal=String(m.room_id)===GLOBAL_ROOM_ID;
    const title=isGlobal?`${name} · Global Community`:name;
    const body=(m.content||'').trim().slice(0,140)||'Mengirim foto';
    window.NdiflyTones?.pop?.();
    showMsgNotice(title,body,m.room_id);
    if(document.hidden&&'Notification' in window&&Notification.permission==='granted'){
      const n=new Notification(title,{body,tag:'ndifly-msg-'+m.room_id,icon:'assets/icon-192.png'});
      n.onclick=()=>{window.focus();openRoomById(m.room_id);n.close();};
    }
  }catch(error){console.warn('[notify]',error);}
}
function openRoomById(id){const r=roomsCache.find(x=>String(x.id)===String(id));openRoom(id,r?displayRoomName(r):(String(id)===GLOBAL_ROOM_ID?'Global Community':'Obrolan'));}
let msgNoticeTimer=null;
function showMsgNotice(title,body,roomId){
  const el=$('msg-notice');if(!el)return;
  $('msg-notice-title').textContent=title;$('msg-notice-body').textContent=body;el.dataset.noticeRoom=roomId;
  el.classList.remove('hidden');void el.offsetWidth;el.classList.add('show');
  clearTimeout(msgNoticeTimer);msgNoticeTimer=setTimeout(hideMsgNotice,5500);
}
function hideMsgNotice(){const el=$('msg-notice');if(!el)return;el.classList.remove('show');setTimeout(()=>{if(!el.classList.contains('show'))el.classList.add('hidden');},350);}
$('msg-notice')?.addEventListener('click',e=>{const el=$('msg-notice');if(e.target.closest('.msg-notice-x')){hideMsgNotice();return;}const id=el.dataset.noticeRoom;hideMsgNotice();if(id)openRoomById(id);});
function listenForRooms(){
  if(roomChannel)supabase.removeChannel(roomChannel);
  roomChannel=supabase.channel('room-list')
    .on('postgres_changes',{event:'*',schema:'public',table:'rooms'},()=>loadRooms())
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'chat_messages'},payload=>{scheduleInboxRefresh();notifyNewMessage(payload.new);})
    .on('postgres_changes',{event:'INSERT',schema:'public',table:'message_reads'},()=>scheduleInboxRefresh())
    .subscribe();
}
function getSavedTheme(){try{return localStorage.getItem('ndifly_theme');}catch(_){return null;}}
function saveTheme(theme){try{localStorage.setItem('ndifly_theme',theme);}catch(error){console.warn('[theme preference storage]',error);}}
function syncThemeChrome(light){
  const meta=document.querySelector('meta[name="theme-color"]');
  if(meta)meta.content=light?'#f4f6fb':'#0b1018';
  document.documentElement.style.colorScheme=light?'light':'dark';
}
$('theme-btn').addEventListener('click',()=>{
  document.documentElement.classList.toggle('light');document.documentElement.classList.toggle('dark');
  const light=document.documentElement.classList.contains('light');
  $('theme-btn').innerHTML=light?'<i class="fa-solid fa-moon"></i>':'<i class="fa-solid fa-sun"></i>';
  syncThemeChrome(light);
  saveTheme(light?'light':'dark');
});
if(getSavedTheme()==='light'){
  document.documentElement.classList.add('light');document.documentElement.classList.remove('dark');
  $('theme-btn').innerHTML='<i class="fa-solid fa-moon"></i>';
}
syncThemeChrome(document.documentElement.classList.contains('light'));


function openActionModal(options){
  const modal=$('logout-modal');
  if(!modal){toast('Muat ulang halaman lalu coba lagi.','error');return;}
  if(modalBusy)return;
  modalAction=options.onConfirm;
  modalActionType=options.type||'logout';
  $('logout-eyebrow').textContent=options.eyebrow||'SESI AKUN';
  $('logout-modal-icon').className=`fa-solid ${options.icon||'fa-arrow-right-from-bracket'}`;
  $('logout-modal-title').textContent=options.title||'Keluar dari ndiflyChat?';
  $('logout-modal-desc').textContent=options.description||'Kamu akan keluar dari sesi di perangkat ini.';
  $('logout-confirm-label').textContent=options.confirmLabel||'Keluar akun';
  $('logout-cancel-label').textContent=options.cancelLabel||'Tetap masuk';
  $('logout-account-row').classList.toggle('hidden',!options.showAccount);
  $('logout-safety-note').innerHTML=options.safety||'<i class="fa-solid fa-shield-halved"></i> Pastikan perangkat ini aman sebelum meninggalkannya.';
  $('logout-dialog').classList.toggle('is-delete',modalActionType==='delete');
  const btn=$('confirm-logout');
  btn.disabled=false;
  btn.innerHTML=`<i id="logout-confirm-icon" class="fa-solid ${options.confirmIcon|| (modalActionType==='delete'?'fa-trash-can':'fa-arrow-right-from-bracket')}"></i><span id="logout-confirm-label">${options.confirmLabel||'Keluar akun'}</span>`;
  modal.classList.remove('hidden');
  document.body.classList.add('logout-modal-open');
  $('cancel-logout')?.focus({preventScroll:true});
}
function openLogoutModal(){
  const username=profile?.username||session?.user?.user_metadata?.username||session?.user?.email?.split('@')[0]||'Pengguna';
  $('logout-account-name').textContent=username;
  renderProfileAvatar($('logout-account-avatar'),profile?.avatar_url,username);
  openActionModal({
    type:'logout',eyebrow:'SESI AKUN',icon:'fa-arrow-right-from-bracket',
    title:'Keluar dari ndiflyChat?',
    description:'Kamu akan keluar dari sesi pada perangkat ini. Percakapan yang sudah tersimpan tidak ikut dihapus.',
    confirmLabel:'Keluar akun',confirmIcon:'fa-arrow-right-from-bracket',cancelLabel:'Tetap masuk',showAccount:true,
    safety:'<i class="fa-solid fa-shield-halved"></i> Pastikan perangkat ini aman sebelum meninggalkannya.',
    onConfirm:async()=>{
      closeIncoming();clearInterval(presenceHeartbeatTimer);callListeners.forEach(e=>{try{if(e.channel)supabase.removeChannel(e.channel);}catch(_){}});callListeners.clear();try{sessionStorage.removeItem('ndifly_welcome_shown');}catch(_){}
      for(const channel of [messageChannel,roomChannel,readChannel,callChannel]){
        if(channel){try{await supabase.removeChannel(channel);}catch(err){console.warn('Channel cleanup:',err);}}
      }
      const {error}=await supabase.auth.signOut({scope:'local'});
      if(error)throw error;
      location.replace('login.html');
    }
  });
}
function closeLogoutModal(force=false){
  if(modalBusy&&!force)return;
  $('logout-modal')?.classList.add('hidden');
  document.body.classList.remove('logout-modal-open');
  modalAction=null;
  if(modalActionType==='logout')$('logout-btn')?.focus({preventScroll:true});
}
$('logout-btn')?.addEventListener('click',openLogoutModal);
$('cancel-logout')?.addEventListener('click',()=>closeLogoutModal());
$('logout-modal-close')?.addEventListener('click',()=>closeLogoutModal());
$('logout-modal')?.querySelectorAll('[data-close-logout]').forEach(el=>el.addEventListener('click',()=>closeLogoutModal()));
document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  if(!$('logout-modal')?.classList.contains('hidden'))closeLogoutModal();
  if(!$('readers-modal')?.classList.contains('hidden'))$('readers-modal').classList.add('hidden');
  if($('welcome-toast')&&!$('welcome-toast').classList.contains('hidden'))hideWelcomePopup();
  if(!$('search-strip')?.classList.contains('hidden')){$('message-search').value='';$('search-strip').classList.add('hidden');renderMessages(messagesCache,false);}
  $('emoji-menu')?.classList.add('hidden');
});
$('confirm-logout')?.addEventListener('click',async()=>{
  const btn=$('confirm-logout');
  if(btn.disabled||modalBusy||typeof modalAction!=='function')return;
  const action=modalAction;
  const type=modalActionType;
  modalBusy=true;btn.disabled=true;
  btn.innerHTML='<i class="fa-solid fa-spinner fa-spin"></i><span>Memproses...</span>';
  try{
    await action();
    closeLogoutModal(true);
  }catch(error){
    console.error(type==='delete'?'DELETE_MESSAGE_ERROR':'LOGOUT_ERROR',error);
    toast(error?.message||(type==='delete'?'Pesan gagal dihapus.':'Belum berhasil keluar. Periksa koneksi lalu coba lagi.'),'error');
  }finally{
    modalBusy=false;btn.disabled=false;
    const mode=modalActionType;
    btn.innerHTML=mode==='delete'
      ?'<i class="fa-solid fa-trash-can"></i><span id="logout-confirm-label">Hapus pesan</span>'
      :'<i class="fa-solid fa-arrow-right-from-bracket"></i><span id="logout-confirm-label">Keluar akun</span>';
  }
});

$('info-btn').title='Informasi ruang';
(async()=>{
 try {
   const {data:{session:existing},error}=await supabase.auth.getSession();
   if(error) {
     console.error('[auth session]', error);
     // Only redirect for a genuinely missing/invalid auth session; avoid redirect loops on transient failures.
     if(/refresh token|invalid token|jwt expired|session.*not found/i.test(error.message||'')) {
       await supabase.auth.signOut({scope:'local'}).catch(()=>{});
       location.replace('login.html?reason=session');
       return;
     }
     toast('Gagal memeriksa sesi. Periksa koneksi lalu muat ulang.','error');
     return;
   }
   if(!existing) {
     location.replace('login.html?reason=missing-session');
     return;
   }
   session=existing;
   try {
     try{await enterApp();}finally{window.__ndiflyReady=true;document.dispatchEvent(new Event('ndifly:ready'));}
} catch(e) {
     console.error('[chat startup]',e);
     const msg=String(e?.message||'');
     if(/refresh token|invalid token|jwt expired|session.*not found|not authenticated/i.test(msg)) {
       await supabase.auth.signOut({scope:'local'}).catch(()=>{});
       location.replace('login.html?reason=session');
       return;
     }
     // A profile/table/RLS/network error is not proof that the auth session is invalid.
     toast('Data chat belum termuat'+(msg?': '+msg.slice(0,90):'')+'. Muat ulang halaman untuk melanjutkan.','error');
   }
 } catch(e) {
   console.error('[chat startup unexpected]',e);
   toast('ndiflyChat gagal memulai. Periksa koneksi internet lalu muat ulang.','error');
 }
})();



let presenceHeartbeatTimer=null;
function startPresenceHeartbeat(){
  if(!session?.user?.id)return;
  const touch=()=>{
    if(document.visibilityState!=='visible'||!session?.user?.id)return;
    supabase.from('profiles').update({last_seen:new Date().toISOString()}).eq('id',session.user.id)
      .then(({error})=>{if(error){console.debug('[presence]',error.message);if(/last_seen|column|schema cache/i.test(error.message))ndiflyDbNotice('kolom last_seen');}})
      .catch(error=>console.debug('[presence]',error?.message||error));
  };
  touch();
  if(presenceHeartbeatTimer)clearInterval(presenceHeartbeatTimer);
  presenceHeartbeatTimer=window.setInterval(touch,60000);
  if(!window.__ndiflyPresenceBound){window.__ndiflyPresenceBound=true;document.addEventListener('visibilitychange',touch);window.addEventListener('focus',touch);window.addEventListener('online',touch);let lastPointer=0;document.addEventListener('pointerdown',()=>{const now=Date.now();if(now-lastPointer>30000){lastPointer=now;touch();}},{passive:true});}
  window.addEventListener('pagehide',()=>{
    if(session?.user?.id)supabase.from('profiles').update({last_seen:new Date().toISOString()}).eq('id',session.user.id);
  },{once:true});
}
function relativeLastSeen(value){
  if(!value)return 'Belum diketahui';
  const timestamp=Date.parse(value);if(!Number.isFinite(timestamp))return 'Belum diketahui';
  const diff=Math.max(0,Date.now()-timestamp);
  if(diff<90000)return 'Baru saja';
  if(diff<3600000)return `${Math.floor(diff/60000)} menit lalu`;
  if(diff<86400000)return `${Math.floor(diff/3600000)} jam lalu`;
  return new Date(timestamp).toLocaleString('id-ID',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
}


function isOnlineAt(iso){const t=Date.parse(iso||'');const age=Date.now()-t;return Number.isFinite(t)&&age>=-60000&&age<150000;}
function formatLastSeen(iso){
  const t=Date.parse(iso||'');if(!Number.isFinite(t))return 'Belum pernah terlihat';
  const diff=Date.now()-t,d=new Date(t),now=new Date();if(diff<90000)return 'Baru saja';if(diff<3600000)return `${Math.floor(diff/60000)} menit lalu`;
  const clock=d.toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'}).replace(':','.'),y=new Date(now);y.setDate(now.getDate()-1);
  if(d.toDateString()===now.toDateString())return `Hari ini ${clock}`;if(d.toDateString()===y.toDateString())return `Kemarin ${clock}`;
  return `${d.toLocaleDateString('id-ID',{day:'numeric',month:'short'})} ${clock}`;
}
function paintPresence(lastSeen){
  const online=isOnlineAt(lastSeen),badge=$('user-profile-presence');if(!badge)return;
  badge.className='profile-presence-badge '+(online?'is-online':'is-offline');
  badge.innerHTML=online?'<i class="fa-solid fa-circle"></i> Online':'<i class="fa-regular fa-clock"></i> Offline';
  $('user-profile-status').textContent=online?'Online':'Offline';
  $('user-profile-last-seen').textContent=online?'Sedang aktif':formatLastSeen(lastSeen);
}
let profilePresenceTimer=0;
function startProfilePresenceRefresh(userId,request){
  clearInterval(profilePresenceTimer);
  profilePresenceTimer=setInterval(async()=>{
    const modal=$('user-profile-modal');if(!modal||modal.classList.contains('hidden')||request!==profileRequestSequence){clearInterval(profilePresenceTimer);return;}
    const {data}=await supabase.from('profiles').select('last_seen').eq('id',userId).maybeSingle();if(data&&request===profileRequestSequence)paintPresence(data.last_seen);
  },20000);
}
let profileRequestSequence=0;
async function showUserProfile(userId,username){
  if(!userId)return;const modal=$('user-profile-modal');if(!modal)return;const request=++profileRequestSequence;modal.classList.remove('hidden');$('user-profile-title').textContent=username||'Memuat profil…';$('user-profile-handle').textContent='@'+(username||'pengguna');$('user-profile-bio').textContent='Memuat bio…';$('user-profile-presence').textContent='Memuat status';$('user-profile-status').textContent='Memeriksa…';$('user-profile-last-seen').textContent='Memuat…';
  try{const {data,error}=await supabase.from('profiles').select('id,username,display_name,avatar_url,bio,last_seen').eq('id',userId).maybeSingle();if(request!==profileRequestSequence)return;if(error)throw error;if(!data)throw Error('Profil tidak ditemukan.');const name=data.display_name||data.username||'Pengguna';$('user-profile-title').textContent=name;$('user-profile-handle').innerHTML='@'+safe(data.username||'pengguna')+verifiedBadge(data.username);$('user-profile-bio').textContent=(data.bio||'').trim()||'Belum menambahkan bio.';const avatar=$('user-profile-avatar');avatar.replaceChildren();if(data.avatar_url){const img=document.createElement('img');img.src=data.avatar_url;img.alt='Foto profil';avatar.appendChild(img);}else avatar.textContent=name.charAt(0).toUpperCase();paintPresence(data.last_seen);startProfilePresenceRefresh(data.id,request);$('user-profile-message').disabled=String(data.id)===String(session?.user?.id);$('user-profile-message').onclick=()=>{modal.classList.add('hidden');startDirectChat(data.id,data.username);};}
  catch(error){if(request!==profileRequestSequence)return;console.warn('[profile sheet]',error);$('user-profile-bio').textContent='Informasi profil belum tersedia. Periksa kolom bio/last_seen dan izin Supabase.';$('user-profile-status').textContent='Tidak tersedia';$('user-profile-last-seen').textContent='—';}
}
async function openActivePeerProfile(){const room=roomsCache.find(r=>String(r.id)===String(activeRoom.id));if(!room||room.is_public||String(activeRoom.id)===GLOBAL_ROOM_ID){toast('Profil akun tersedia di percakapan pribadi.','info');return;}const match=String(room.name||'').match(/^DM\s*-\s*@([^/]+)\s*\/\s*@(.+)$/i);if(!match){toast('Tidak dapat mengenali akun percakapan ini.','error');return;}const me=String(profile?.username||'').toLowerCase();const peer=[match[1].trim(),match[2].trim()].find(x=>x.toLowerCase()!==me);if(!peer)return;const {data,error}=await supabase.from('profiles').select('id,username').eq('username',peer.toLowerCase()).maybeSingle();if(error||!data){toast('Profil pengguna tidak ditemukan.','error');return;}showUserProfile(data.id,data.username);}
document.addEventListener('click',e=>{const close=e.target.closest('[data-close-profile]');if(close){profileRequestSequence++;$('user-profile-modal')?.classList.add('hidden');}});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!$('user-profile-modal')?.classList.contains('hidden')){profileRequestSequence++;$('user-profile-modal')?.classList.add('hidden');}});
$('header-room-name')?.addEventListener('click',openActivePeerProfile);document.querySelector('.header-avatar')?.addEventListener('click',()=>{const a=document.querySelector('.header-avatar');if(a?.dataset.peerId)showUserProfile(a.dataset.peerId,a.dataset.peerName);else openActivePeerProfile();});$('my-avatar')?.addEventListener('click',()=>showUserProfile(session?.user?.id,profile?.username));

// iOS-style dock navigation
(function initDock(){
 const items=[...document.querySelectorAll('.ios-dock-item')];
 function activate(id){items.forEach(x=>x.classList.toggle('active',x.id===id));}
 document.getElementById('dock-chat')?.addEventListener('click',()=>{
   activate('dock-chat');
   const sidebar=document.getElementById('sidebar');
   document.getElementById('app-screen')?.classList.remove('chat-open');
   sidebar?.classList.remove('mobile-hidden');
   document.getElementById('info-panel')?.classList.add('hidden');
   document.getElementById('room-search')?.focus({preventScroll:true});
 });
 document.getElementById('dock-status')?.addEventListener('click',()=>{location.href='status.html';});
 document.getElementById('dock-calls')?.addEventListener('click',()=>{location.href='calls.html';});
 document.getElementById('dock-info')?.addEventListener('click',()=>{
   // Product information has its own page; keep the in-room info panel on the header button.
   location.href='informasi.html';
 });
 document.getElementById('dock-settings')?.addEventListener('click',()=>{
   location.href='settings.html';
 });
})();
})();
