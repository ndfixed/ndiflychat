/* ndiflyChat — halaman telepon (call.html).
   Suara & video antar pengguna lewat WebRTC (mesh), sinyal lewat Supabase Realtime (channel privat
   `call:<room id>`), daftar peserta lewat Presence. Dipakai untuk chat pribadi (1:1) dan Global (grup). */
(() => {
  'use strict';
  const GLOBAL_ROOM_ID = '00000000-0000-4000-8000-000000000001';
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  const MAX_PEOPLE = 8, RING_TIMEOUT = 45000, RING_EVERY = 3500, UI_IDLE_MS = 4500;
  // Presence bisa sekejap hilang saat diperbarui / koneksi realtime berkedip. Peserta baru dianggap keluar bila hilang selama masa ini
  // (atau langsung bila ia mengirim sinyal 'bye' saat menekan Akhiri).
  const PRESENCE_GRACE = 12000;
  const $ = id => document.getElementById(id);
  const safe = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const qs = new URLSearchParams(location.search);
  const roomId = qs.get('room') || '';
  let callMode = qs.get('mode') === 'video' ? 'video' : 'audio';
  const act = qs.get('act') === 'start' ? 'start' : 'join';
  let callId = qs.get('callId') || '';
  const sb = window.ndiflySupabase;
  // Dibuka di dalam halaman chat (iframe) → chat tetap hidup di belakang & bisa diperkecil.
  const embedded = qs.get('embed') === '1' && window.parent !== window;
  const toParent = (type, extra) => { if (embedded) { try { window.parent.postMessage({ ndifly: 'call', type, ...(extra || {}) }, location.origin); } catch (_) {} } };
  const tones = window.NdiflyTones || { ringbackStart() {}, stop() {}, connected() {}, ended() {}, chime() {} };
  const note = hint => console.warn('[ndiflyChat · catatan untuk andif_dev]', hint);

  /* Jalur koneksi: STUN saja hanya cukup di jaringan "ramah". Banyak jaringan seluler/kantor memblokir koneksi langsung,
     sehingga perlu server TURN (relay). Urutan sumber TURN: js/config.js → /api/turn (aman, kredensial sementara) → relay publik (cadangan). */
  const DEFAULT_STUN = [
    { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
    { urls: 'stun:global.stun.twilio.com:3478' },
  ];
  const PUBLIC_RELAY = [{ urls: ['turn:openrelay.metered.ca:80', 'turn:openrelay.metered.ca:443', 'turns:openrelay.metered.ca:443?transport=tcp'], username: 'openrelayproject', credential: 'openrelayproject' }];
  let ICE = [...DEFAULT_STUN], iceSource = 'stun-saja', hasRelay = false, iceReady = Promise.resolve();
  async function loadIce(token) {
    const cfg = window.NDIFLY_CONFIG || {};
    let extra = [], source = 'stun-saja';
    if (Array.isArray(cfg.iceServers) && cfg.iceServers.length) { extra = cfg.iceServers; source = 'config'; }
    if (!extra.length && cfg.turnEndpoint !== false) {
      try {
        const cached = JSON.parse(sessionStorage.getItem('ndifly_ice') || 'null');
        if (cached && Date.now() - cached.t < 10 * 60 * 1000 && cached.servers?.length) { extra = cached.servers; source = 'api/turn'; }
      } catch (_) {}
      if (!extra.length && token) {
        try {
          const ctrl = new AbortController(); const to = setTimeout(() => ctrl.abort(), 3500);
          const r = await fetch(cfg.turnEndpoint || '/api/turn', { headers: { Authorization: 'Bearer ' + token }, signal: ctrl.signal, cache: 'no-store' });
          clearTimeout(to);
          if (r.ok) {
            const j = await r.json();
            if (Array.isArray(j.iceServers) && j.iceServers.length) { extra = j.iceServers; source = 'api/turn'; try { sessionStorage.setItem('ndifly_ice', JSON.stringify({ t: Date.now(), servers: extra })); } catch (_) {} }
          }
        } catch (_) {}
      }
    }
    if (!extra.length && cfg.publicRelay !== false) { extra = PUBLIC_RELAY; source = 'relay-publik'; }
    ICE = [...DEFAULT_STUN, ...extra]; iceSource = source;
    hasRelay = extra.some(s => [].concat(s.urls || []).some(u => /^turns?:/i.test(u)));
  }

  let me = null, room = null, channel = null, localStream = null;
  let ended = false, everConnected = false, startedAt = 0, logged = false;
  const dialStartedAt = Date.now();
  let timerInt = null, ringInt = null, ringTimeout = null, levelInt = null, idleTimer = null, joinGuard = null, connectGuard = null;
  let stageTick = null, presenceKeepAlive = null, wakeLock = null, audioCtx = null, camOn = false, micOn = true, facing = 'user', camBusy = false, backArmed = 0;
  const peers = new Map();            // uid -> peer
  const meta = new Map();             // uid -> presence meta
  const analysers = new Map();        // uid -> {an,data,el}
  const pendingPlay = new Set();

  /* ------------------------------------------------------------------ UI helpers */
  const PALETTE = [['#6f8bff', '#3552e0'], ['#a78bfa', '#7c5cf0'], ['#34d399', '#0f9d6b'], ['#f59e0b', '#d97706'], ['#fb7185', '#e11d48'], ['#22d3ee', '#0e8fb0']];
  const colorsFor = name => { let h = 0; for (const ch of String(name)) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return PALETTE[h % PALETTE.length]; };
  function paintAvatar(el, name, url, size) {
    if (!el) return;
    const [c1, c2] = colorsFor(name);
    el.style.setProperty('--c1', c1); el.style.setProperty('--c2', c2);
    if (size) el.style.setProperty('--s', size);
    el.innerHTML = url ? `<img src="${safe(url)}" alt="">` : safe((String(name || '?').trim().charAt(0) || '?').toUpperCase());
  }
  const setState = s => { document.body.dataset.state = s; };
  const setStatus = t => { const el = $('call-status'); if (el && el.textContent !== t) el.textContent = t; };
  let toastTimer = null;
  function toast(msg, type = '') {
    const el = $('call-toast'); if (!el) return;
    el.textContent = msg; el.className = 'call-toast show ' + type;
    clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 3600);
  }
  function fatal(text, title, detail) {
    ended = true; tones.stop(); cleanupMedia();
    if (detail) { $('call-error-pre').textContent = detail; $('call-error-detail').hidden = false; }
    $('call-error-title').textContent = title || 'Panggilan belum bisa dimulai';
    $('call-error-text').textContent = text;
    $('call-error').classList.add('show');
    setState('ended');
  }
  const goBack = () => { if (embedded) toParent('ended'); else location.replace('chat.html'); };
  const fmt = s => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;

  function mediaErrorText(err) {
    switch (err && err.name) {
      case 'NotAllowedError': case 'SecurityError': return 'Izin mikrofon ditolak. Izinkan mikrofon (dan kamera) di pengaturan browser untuk situs ini, lalu coba lagi.';
      case 'NotFoundError': case 'OverconstrainedError': return 'Mikrofon tidak ditemukan di perangkat ini.';
      case 'NotReadableError': case 'AbortError': return 'Mikrofon sedang dipakai aplikasi lain. Tutup aplikasi itu lalu coba lagi.';
      default: return 'Mikrofon belum bisa dipakai. Periksa izin dan perangkatmu, lalu coba lagi.';
    }
  }

  /* ------------------------------------------------------------------ init */
  async function init() {
    if (!sb) { fatal('Koneksi belum siap. Periksa internetmu lalu muat ulang halaman.'); return; }
    if (!UUID_RE.test(roomId)) { fatal('Tautan panggilan tidak valid.'); return; }
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      fatal('Browser ini belum bisa memakai mikrofon/kamera di sini. Buka ndiflyChat lewat https:// dan gunakan browser terbaru.'); return;
    }
    try {
      const { data: { session } } = await sb.auth.getSession();
      if (!session?.user) { location.replace('login.html?reason=missing-session'); return; }
      me = { id: session.user.id, name: 'Pengguna', avatar: null };
      iceReady = loadIce(session.access_token).catch(() => {});
      const [pr, rr] = await Promise.all([
        (async () => await sb.from('profiles').select('id,username,display_name,avatar_url').eq('id', me.id).maybeSingle())(),
        (async () => await sb.from('rooms').select('id,name,is_public').eq('id', roomId).maybeSingle())(),
      ]);
      if (pr.data) { me.name = pr.data.username || pr.data.display_name || me.name; me.avatar = pr.data.avatar_url || null; }
      if (!rr.data) { fatal('Ruang ini tidak ditemukan, atau kamu bukan anggotanya.'); return; }
      room = { id: rr.data.id, name: rr.data.name, isGlobal: rr.data.id === GLOBAL_ROOM_ID, peer: null };
      if (!room.isGlobal) await resolvePeer(rr.data.name);
    } catch (err) {
      console.error('[call init]', err); fatal('Data panggilan belum bisa dimuat. Periksa internetmu lalu coba lagi.'); return;
    }
    renderHeader();
    if (!callId) callId = (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random().toString(16).slice(2));
    document.body.dataset.mode = callMode;
    setStatus('Meminta izin mikrofon…');
    try { await openMedia(); } catch (err) { console.warn('[call media]', err); fatal(mediaErrorText(err), 'Izin diperlukan'); return; }
    setStatus('Menyambung…');
    await iceReady;
    try { await connect(); await channel.track(myMeta()); }
    catch (err) {
      console.error('[call channel]', err);
      note('Channel panggilan gagal. Jalankan calls-setup.sql di Supabase SQL Editor (izin Realtime untuk topik call:<room id>) dan pastikan Realtime aktif.');
      fatal('Panggilan belum bisa tersambung saat ini. Coba lagi nanti atau kabari andif_dev.', undefined,
        'Channel realtime gagal dibuka.\nAlasan: ' + ((err && err.message) || 'tidak diketahui') + '\nTopik: call:' + roomId +
        '\n\nPerbaikan: jalankan calls-setup.sql di Supabase SQL Editor, lalu pastikan Realtime aktif untuk project ini.'); return;
    }
    lockScreen();
    afterConnect();
  }

  async function resolvePeer(roomName) {
    const m = String(roomName || '').match(/^DM\s*-\s*@([^/]+?)\s*\/\s*@(.+)$/i);
    let peerName = 'Teman';
    if (m) { const a = m[1].trim(), b = m[2].trim(); peerName = a.toLowerCase() === me.name.toLowerCase() ? b : a; }
    room.peer = { id: null, name: peerName, avatar: null };
    try {
      const { data } = await sb.from('profiles').select('id,username,avatar_url').eq('username', peerName.toLowerCase()).maybeSingle();
      if (data) room.peer = { id: data.id, name: data.username || peerName, avatar: data.avatar_url || null };
    } catch (_) {}
  }

  function renderHeader() {
    const title = room.isGlobal ? 'Global Community' : room.peer.name;
    $('call-room').textContent = title; $('call-name').textContent = title;
    document.title = `Panggilan · ${title} — ndiflyChat`;
    $('call-sub').textContent = room.isGlobal ? 'Panggilan grup · terenkripsi' : 'Panggilan terenkripsi';
    paintAvatar($('call-avatar'), title, room.isGlobal ? null : room.peer.avatar);
    $('call-hint').textContent = room.isGlobal ? 'Peserta lain akan melihat tombol Bergabung di chat Global.' : '';
    $('call-people').hidden = !room.isGlobal; $('call-spacer').hidden = room.isGlobal;
    setState(act === 'start' && !room.isGlobal ? 'calling' : 'connecting');
  }

  /* ------------------------------------------------------------------ media */
  const VIDEO_CONSTRAINTS = () => ({ facingMode: facing, width: { ideal: 640 }, height: { ideal: 480 }, frameRate: { ideal: 24, max: 30 } });
  const AUDIO_CONSTRAINTS = { echoCancellation: true, noiseSuppression: true, autoGainControl: true };
  async function openMedia() {
    const wantVideo = callMode === 'video';
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: wantVideo ? VIDEO_CONSTRAINTS() : false });
    } catch (err) {
      if (!wantVideo) throw err;
      localStream = await navigator.mediaDevices.getUserMedia({ audio: AUDIO_CONSTRAINTS, video: false });
      callMode = 'audio'; document.body.dataset.mode = 'audio';
      toast('Kamera tidak tersedia. Panggilan dilanjutkan sebagai suara.', 'error');
    }
    camOn = localStream.getVideoTracks().length > 0; micOn = true;
    showLocalVideo(); syncButtons(); detectCameras();
  }
  function showLocalVideo() {
    const v = $('local-video'), pip = $('local-pip');
    if (camOn) { v.srcObject = localStream; pip.classList.add('on'); pip.classList.toggle('back', facing !== 'user'); safePlay(v); }
    else { pip.classList.remove('on'); }
  }
  async function detectCameras() {
    try { const d = await navigator.mediaDevices.enumerateDevices(); $('btn-flip').hidden = !(camOn && d.filter(x => x.kind === 'videoinput').length > 1); } catch (_) {}
  }
  function cleanupMedia() {
    try { localStream && localStream.getTracks().forEach(t => t.stop()); } catch (_) {}
    try { wakeLock && wakeLock.release(); } catch (_) {}
  }
  async function lockScreen() { try { if (navigator.wakeLock && !ended) wakeLock = await navigator.wakeLock.request('screen'); } catch (_) {} }
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && !ended) lockScreen(); });

  function safePlay(el) {
    const p = el.play && el.play();
    if (p && p.catch) p.catch(() => { pendingPlay.add(el); $('call-unlock').hidden = false; });
  }
  $('call-unlock').addEventListener('click', () => {
    pendingPlay.forEach(el => { const p = el.play(); p && p.catch(() => {}); });
    pendingPlay.clear(); $('call-unlock').hidden = true;
    try { audioCtx && audioCtx.resume(); } catch (_) {}
  });

  /* ------------------------------------------------------------------ channel & presence */
  function myMeta() {
    return { uid: me.id, name: me.name, avatar: me.avatar, mode: callMode, callId, video: camOn, muted: !micOn, since: startedAt || Date.now() };
  }
  async function updatePresence() { try { await channel.track(myMeta()); } catch (_) {} }

  async function connect() {
    const bind = ch => ch
      .on('broadcast', { event: 'signal' }, ({ payload }) => onSignal(payload))
      .on('broadcast', { event: 'decline' }, ({ payload }) => onDecline(payload))
      .on('broadcast', { event: 'bye' }, ({ payload }) => onBye(payload))
      .on('presence', { event: 'sync' }, onPresenceSync);
    const r = await window.NdiflyCallChannel.open(sb, 'call:' + roomId, { presenceKey: me.id, bind });
    if (!r.channel) throw new Error(r.error || 'channel gagal');
    channel = r.channel;
    // Pastikan kehadiran kita tetap tercatat meski koneksi realtime sempat putus & tersambung lagi.
    presenceKeepAlive = setInterval(() => {
      if (ended || !channel) return;
      try { if (!channel.presenceState()[me.id]) updatePresence(); } catch (_) {}
    }, 10000);
  }

  function afterConnect() {
    if (act === 'start' && !room.isGlobal) {
      // Telepon pribadi: beri tahu lawan bicara (ring) berulang sampai dijawab / habis waktu.
      tones.ringbackStart();
      sendRing(); ringInt = setInterval(sendRing, RING_EVERY);
      ringTimeout = setTimeout(() => { if (!everConnected && !ended) { setStatus('Tidak dijawab'); endCall('noanswer'); } }, RING_TIMEOUT);
      setState('calling'); setStatus('Memanggil…');
    } else if (act === 'join' && !room.isGlobal) {
      // Bila lawan bicara sudah menutup sebelum kita masuk, jangan menggantung.
      joinGuard = setTimeout(() => { if (!peers.size && !ended) { setStatus('Panggilan sudah berakhir'); endCall('failed'); } }, 9000);
    }
    refreshUI();
  }
  function sendRing() {
    if (!channel || ended || everConnected) return;
    channel.send({ type: 'broadcast', event: 'ring', payload: { callId, mode: callMode, fromId: me.id, fromName: me.name, fromAvatar: me.avatar, roomId, sentAt: Date.now() } }).catch(() => {});
  }
  function onDecline(p) {
    if (ended || room.isGlobal || everConnected) return;
    if (p && p.callId && p.callId !== callId) return;
    setStatus('Panggilan ditolak'); endCall('declined');
  }

  function onPresenceSync() {
    if (ended) return;
    const state = channel.presenceState(); const next = new Map();
    Object.values(state).forEach(arr => { const m = arr[arr.length - 1]; if (m && m.uid && m.uid !== me.id) next.set(m.uid, m); });
    peers.forEach((p, uid) => {
      if (next.has(uid)) { p.missingSince = 0; return; }
      if (!p.missingSince) { p.missingSince = Date.now(); setTimeout(() => checkGone(uid), PRESENCE_GRACE + 300); }
    });
    next.forEach((m, uid) => {
      meta.set(uid, m);
      if (!peers.has(uid)) { if (peers.size < MAX_PEOPLE - 1) createPeer(uid, m); }
      else updateTile(uid);
    });
    [...meta.keys()].forEach(uid => { if (!next.has(uid) && !peers.has(uid)) meta.delete(uid); });
    if (next.size) { clearTimeout(joinGuard); }
    refreshUI();
  }

  /* ------------------------------------------------------------------ WebRTC (perfect negotiation) */
  const sendSignal = (to, body) => channel && channel.send({ type: 'broadcast', event: 'signal', payload: { from: me.id, to, ...body } }).catch(() => {});

  function createPeer(uid, m) {
    const pc = new RTCPeerConnection({ iceServers: ICE, bundlePolicy: 'max-bundle', iceCandidatePoolSize: 2 });
    const peer = { uid, pc, polite: String(me.id) > String(uid), makingOffer: false, ignoreOffer: false, pendingIce: [], chain: Promise.resolve(), connected: false, videoSender: null, tile: null, stream: null, restartTimer: null, failSince: 0,
      created: Date.now(), iceBatch: [], iceTimer: null, d: { descSent: 0, descRecv: 0, iceSent: 0, iceRecv: 0, cand: {}, selected: '' } };
    peers.set(uid, peer);
    peer.tile = buildTile(uid, m);
    armConnectGuard();
    if (!stageTick) stageTick = setInterval(() => { if (ended || everConnected) { clearInterval(stageTick); stageTick = null; return; } refreshUI(); renderDiag(); }, 1500);

    localStream.getTracks().forEach(t => { const s = pc.addTrack(t, localStream); if (t.kind === 'video') peer.videoSender = s; });

    // Kandidat ICE dikirim berkelompok (±150 ms) supaya pesan sinyal jauh lebih sedikit dan tidak ada yang terbuang.
    pc.onicecandidate = ({ candidate }) => {
      if (candidate) {
        const t = candidate.type || (/ typ (\w+)/.exec(candidate.candidate || '') || [])[1] || '?';
        peer.d.cand[t] = (peer.d.cand[t] || 0) + 1;
        peer.iceBatch.push(candidate.toJSON ? candidate.toJSON() : candidate);
        if (!peer.iceTimer) peer.iceTimer = setTimeout(() => flushIce(peer), 150);
      } else flushIce(peer);
    };
    pc.oniceconnectionstatechange = () => { refreshUI(); };
    pc.onnegotiationneeded = async () => {
      try {
        peer.makingOffer = true;
        await pc.setLocalDescription(await pc.createOffer());
        sendSignal(uid, { kind: 'desc', description: pc.localDescription }); peer.d.descSent++;
      } catch (err) { console.warn('[negotiation]', err); } finally { peer.makingOffer = false; }
    };
    pc.ontrack = ({ track, streams }) => {
      peer.stream = streams[0] || peer.stream || new MediaStream();
      if (!streams[0]) peer.stream.addTrack(track);
      const v = peer.tile.querySelector('video');
      if (v.srcObject !== peer.stream) v.srcObject = peer.stream;
      safePlay(v);
      if (track.kind === 'audio') watchLevel(uid, peer.stream, () => peer.tile);
      track.onunmute = () => updateTile(uid);
      updateTile(uid);
    };
    pc.onconnectionstatechange = () => {
      const st = pc.connectionState;
      if (st === 'connected') { clearTimeout(peer.restartTimer); clearTimeout(peer.failTimer); peer.failTimer = null; peer.failSince = 0; peer.connected = true; noteSelectedPair(peer); onFirstConnect(); }
      else if (st === 'disconnected') {
        setStatus('Koneksi tidak stabil…'); clearTimeout(peer.restartTimer);
        peer.restartTimer = setTimeout(() => { if (pc.connectionState !== 'connected') restartIce(peer); }, 3500);
      } else if (st === 'failed') {
        restartIce(peer);
        // Sudah pernah tersambung tetapi jalur media mati >20 dtk (mis. lawan bicara keluar paksa): anggap pergi; bila ia kembali, presence akan membuatnya tersambung ulang.
        if (peer.connected && !peer.failTimer) peer.failTimer = setTimeout(() => { if (peers.get(uid) === peer && peer.pc.connectionState !== 'connected') removePeer(uid); }, 20000);
      }
      refreshUI();
    };
    return peer;
  }

  /* Ada peserta di daftar tetapi koneksi tak kunjung terbentuk (mis. lawan bicara sudah menutup paksa) → jangan menggantung. */
  function armConnectGuard() {
    if (connectGuard || everConnected) return;
    connectGuard = setTimeout(() => {
      connectGuard = null;
      if (ended || everConnected || ![...peers.values()].length) return;
      console.warn('[ndiflyChat · catatan untuk andif_dev] Panggilan tidak tersambung dalam 25 dtk.\n' + diagText());
      toast('Belum bisa tersambung. Periksa internetmu atau coba ganti jaringan.', 'error');
      if (!room.isGlobal) { setStatus('Tidak bisa tersambung'); endCall('failed'); }
    }, 25000);
  }

  function flushIce(peer) {
    clearTimeout(peer.iceTimer); peer.iceTimer = null;
    if (!peer.iceBatch.length) return;
    const list = peer.iceBatch.splice(0); peer.d.iceSent += list.length;
    sendSignal(peer.uid, { kind: 'ice', candidates: list });
  }
  async function noteSelectedPair(peer) {
    try {
      const stats = await peer.pc.getStats(); let pair = null;
      stats.forEach(s => { if (s.type === 'candidate-pair' && (s.selected || (s.nominated && s.state === 'succeeded'))) pair = s; });
      if (!pair) return;
      const l = stats.get(pair.localCandidateId), r = stats.get(pair.remoteCandidateId);
      peer.d.selected = `${(l && l.candidateType) || '?'} ↔ ${(r && r.candidateType) || '?'}`;
      console.info('[ndiflyChat] jalur koneksi terpilih:', peer.d.selected, '| sumber ICE:', iceSource);
    } catch (_) {}
  }
  function stageText() {
    const p = [...peers.values()][0]; if (!p) return 'Menghubungkan…';
    const age = Date.now() - p.created, slow = age > 10000;
    if (!p.d.descRecv && age > 4000) return 'Menunggu lawan bicara merespons…';
    if (slow) return 'Koneksi lambat… jaringan mungkin membatasi panggilan';
    return p.pc.iceConnectionState === 'checking' ? 'Mencari jalur koneksi…' : 'Menghubungkan…';
  }
  function diagText() {
    const lines = [`Sumber ICE: ${iceSource}`, `Server relay (TURN): ${hasRelay ? 'ada' : 'TIDAK ADA'}`];
    peers.forEach(p => {
      const c = p.d.cand, cs = Object.keys(c).map(k => `${k} ${c[k]}`).join(', ') || 'belum ada';
      lines.push(`— ${(meta.get(p.uid) || {}).name || 'peserta'}`,
        `  sinyal: kirim ${p.d.descSent} desc/${p.d.iceSent} ice · terima ${p.d.descRecv} desc/${p.d.iceRecv} ice`,
        `  kandidat lokal: ${cs}`,
        `  ICE: ${p.pc.iceConnectionState} · koneksi: ${p.pc.connectionState} · signaling: ${p.pc.signalingState}`,
        p.d.selected ? `  jalur terpilih: ${p.d.selected}` : '');
    });
    if (!hasRelay) lines.push('', 'Tanpa server TURN, koneksi gagal di jaringan seluler/NAT ketat. Lihat TURN-SETUP.md.');
    return lines.filter(Boolean).join('\n');
  }
  function renderDiag() {
    const box = $('call-diag'); if (!box) return;
    const oldest = [...peers.values()].reduce((m, p) => Math.min(m, p.created), Date.now());
    box.hidden = everConnected || !peers.size || Date.now() - oldest < 6000;
    if (!box.hidden) $('call-diag-pre').textContent = diagText();
  }

  function restartIce(peer) {
    if (ended || !peers.has(peer.uid)) return;
    if (!peer.failSince) peer.failSince = Date.now();
    if (Date.now() - peer.failSince > 20000) { toast('Jaringan ini kurang mendukung panggilan. Coba ganti jaringan (Wi-Fi/data seluler).', 'error'); peer.failSince = Date.now(); }
    try { peer.pc.restartIce(); } catch (_) {}
  }

  function onSignal(p) {
    if (ended || !p || p.to !== me.id || !p.from) return;
    let peer = peers.get(p.from);
    if (!peer) { if (peers.size >= MAX_PEOPLE - 1) return; peer = createPeer(p.from, meta.get(p.from) || { uid: p.from, name: 'Peserta' }); }
    peer.chain = peer.chain.then(() => processSignal(peer, p)).catch(err => console.warn('[signal]', err));
  }
  async function processSignal(peer, p) {
    const { pc } = peer;
    if (p.kind === 'desc') {
      const d = p.description; peer.d.descRecv++;
      const collision = d.type === 'offer' && (peer.makingOffer || pc.signalingState !== 'stable');
      peer.ignoreOffer = !peer.polite && collision;
      if (peer.ignoreOffer) return;
      await pc.setRemoteDescription(d);
      for (const c of peer.pendingIce.splice(0)) { try { await pc.addIceCandidate(c); } catch (e) { if (!peer.ignoreOffer) console.warn(e); } }
      if (d.type === 'offer') {
        await pc.setLocalDescription(await pc.createAnswer());
        sendSignal(peer.uid, { kind: 'desc', description: pc.localDescription }); peer.d.descSent++;
      }
    } else if (p.kind === 'ice') {
      const list = p.candidates || (p.candidate ? [p.candidate] : []);
      peer.d.iceRecv += list.length;
      for (const c of list) {
        if (!pc.remoteDescription) { peer.pendingIce.push(c); continue; }
        try { await pc.addIceCandidate(c); } catch (e) { if (!peer.ignoreOffer) console.warn('[ice]', e); }
      }
    }
  }

  function checkGone(uid) {
    const p = peers.get(uid);
    if (!p || ended || !p.missingSince) return;
    if (Date.now() - p.missingSince >= PRESENCE_GRACE) removePeer(uid);
  }
  function onBye(p) { if (!ended && p && p.from && peers.has(p.from)) removePeer(p.from); }

  function removePeer(uid) {
    const peer = peers.get(uid); if (!peer) return;
    clearTimeout(peer.restartTimer); clearTimeout(peer.failTimer);
    try { peer.pc.ontrack = peer.pc.onicecandidate = peer.pc.onnegotiationneeded = peer.pc.onconnectionstatechange = null; peer.pc.close(); } catch (_) {}
    peer.tile && peer.tile.remove(); analysers.delete(uid); peers.delete(uid);
    if (everConnected && !ended) {
      if (!room.isGlobal && !peers.size) { setStatus('Panggilan berakhir'); endCall('remote'); }
      else if (room.isGlobal) toast(`${(meta.get(uid)?.name) || 'Seseorang'} keluar dari panggilan`);
    }
    else if (!ended && !everConnected && !room.isGlobal && !peers.size && act === 'join') { setStatus('Panggilan sudah berakhir'); endCall('failed'); }
    refreshUI();
  }

  /* ------------------------------------------------------------------ tiles */
  function buildTile(uid, m) {
    const tile = document.createElement('div'); tile.className = 'tile is-off'; tile.dataset.uid = uid;
    tile.innerHTML = '<video playsinline autoplay></video><div class="tile-avatar"><div class="cl-avatar" style="--s:min(26vw,120px)"></div></div><div class="tile-name"><span></span><i class="fa-solid fa-microphone-slash"></i></div>';
    $('remote-grid').appendChild(tile);
    paintAvatar(tile.querySelector('.cl-avatar'), m.name || 'Peserta', m.avatar);
    tile.querySelector('.tile-name span').textContent = m.name || 'Peserta';
    return tile;
  }
  function updateTile(uid) {
    const peer = peers.get(uid); if (!peer) return;
    const m = meta.get(uid) || {};
    const hasVideoTrack = !!(peer.stream && peer.stream.getVideoTracks().some(t => t.readyState === 'live'));
    peer.tile.classList.toggle('has-video', !!m.video && hasVideoTrack);
    peer.tile.classList.toggle('is-muted', !!m.muted);
    peer.tile.querySelector('.tile-name span').textContent = m.name || 'Peserta';
    if (m.name) paintAvatar(peer.tile.querySelector('.cl-avatar'), m.name, m.avatar);
    updateUiIdle();
  }

  function watchLevel(uid, stream, getEl) {
    if (analysers.has(uid) || !stream.getAudioTracks().length) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext; audioCtx = audioCtx || new AC();
      const src = audioCtx.createMediaStreamSource(stream); const an = audioCtx.createAnalyser(); an.fftSize = 256; src.connect(an);
      analysers.set(uid, { an, data: new Uint8Array(an.frequencyBinCount), getEl });
      if (!levelInt) levelInt = setInterval(() => {
        analysers.forEach(a => { a.an.getByteFrequencyData(a.data); let s = 0; for (let i = 0; i < a.data.length; i++) s += a.data[i]; const el = a.getEl(); el && el.classList.toggle('speaking', s / a.data.length > 16); });
      }, 160);
    } catch (_) {}
  }

  /* ------------------------------------------------------------------ status / UI */
  function onFirstConnect() {
    if (everConnected) return;
    everConnected = true; startedAt = Date.now();
    tones.stop(); tones.connected(); clearInterval(ringInt); clearTimeout(ringTimeout); clearTimeout(joinGuard); clearTimeout(connectGuard); connectGuard = null;
    timerInt = setInterval(() => { const t = fmt(Math.floor((Date.now() - startedAt) / 1000)); $('call-timer').textContent = t; $('call-sub').textContent = t; pushState(); }, 1000);
    updatePresence();
  }
  function refreshUI() {
    if (ended) return;
    const connected = [...peers.values()].filter(p => p.connected);
    peers.forEach(p => p.tile.classList.toggle('is-off', !p.connected));
    const grid = $('remote-grid');
    grid.dataset.count = String(connected.length); grid.classList.toggle('has-tiles', connected.length > 0);
    $('call-center').classList.toggle('is-gone', connected.length > 0);
    $('call-people-n').textContent = String(connected.length + 1);
    if (connected.length) { setState('connected'); setStatus('Terhubung'); }
    else if (peers.size) { setState('connecting'); setStatus(stageText()); }
    else if (act === 'start' && !room.isGlobal && !everConnected) { setState('calling'); setStatus('Memanggil…'); }
    else if (room.isGlobal) { setState('waiting'); setStatus(everConnected ? 'Peserta lain sudah keluar' : 'Menunggu peserta lain…'); }
    else { setState('connecting'); setStatus('Menghubungkan…'); }
    updateUiIdle(); pushState();
  }

  /* kontrol menghilang saat video aktif & tidak disentuh */
  function anyVideo() { return camOn || [...peers.values()].some(p => p.tile.classList.contains('has-video')); }
  function updateUiIdle() { if (!anyVideo()) { document.body.classList.remove('ui-idle'); clearTimeout(idleTimer); } else bumpUI(); }
  function bumpUI() {
    document.body.classList.remove('ui-idle'); clearTimeout(idleTimer);
    if (anyVideo() && !ended) idleTimer = setTimeout(() => document.body.classList.add('ui-idle'), UI_IDLE_MS);
  }
  ['pointerdown', 'pointermove', 'keydown'].forEach(ev => document.addEventListener(ev, bumpUI, { passive: true }));

  /* ------------------------------------------------------------------ tombol */
  function syncButtons() {
    const mic = $('btn-mic'), cam = $('btn-cam');
    mic.setAttribute('aria-pressed', String(!micOn));
    mic.querySelector('i').className = micOn ? 'fa-solid fa-microphone' : 'fa-solid fa-microphone-slash';
    mic.querySelector('small').textContent = micOn ? 'Mikrofon' : 'Dibisukan';
    mic.setAttribute('aria-label', micOn ? 'Matikan mikrofon' : 'Nyalakan mikrofon');
    cam.setAttribute('aria-pressed', String(camOn));
    cam.querySelector('i').className = camOn ? 'fa-solid fa-video' : 'fa-solid fa-video-slash';
    cam.querySelector('small').textContent = camOn ? 'Video aktif' : 'Video';
    cam.setAttribute('aria-label', camOn ? 'Matikan kamera' : 'Nyalakan kamera');
  }
  function toggleMic() {
    if (!localStream) return;
    micOn = !micOn; localStream.getAudioTracks().forEach(t => { t.enabled = micOn; });
    syncButtons(); updatePresence(); pushState();
  }
  $('btn-mic').addEventListener('click', toggleMic);

  async function toggleCam() {
    if (camBusy || !localStream) return; camBusy = true;
    try {
      if (!camOn) {
        const s = await navigator.mediaDevices.getUserMedia({ video: VIDEO_CONSTRAINTS() });
        const track = s.getVideoTracks()[0];
        localStream.getVideoTracks().forEach(t => localStream.removeTrack(t));
        localStream.addTrack(track);
        peers.forEach(p => { if (p.videoSender) p.videoSender.replaceTrack(track).catch(() => {}); else p.videoSender = p.pc.addTrack(track, localStream); });
        camOn = true; callMode = 'video'; document.body.dataset.mode = 'video';
      } else {
        const old = localStream.getVideoTracks()[0];
        peers.forEach(p => { p.videoSender && p.videoSender.replaceTrack(null).catch(() => {}); });
        if (old) { old.stop(); localStream.removeTrack(old); }
        camOn = false;
      }
      showLocalVideo(); syncButtons(); detectCameras(); updatePresence(); updateUiIdle();
    } catch (err) {
      console.warn('[camera]', err);
      toast(err && err.name === 'NotAllowedError' ? 'Izin kamera ditolak. Izinkan kamera di pengaturan browser.' : 'Kamera belum bisa dinyalakan.', 'error');
    } finally { camBusy = false; }
  }
  $('btn-cam').addEventListener('click', toggleCam);

  $('btn-flip').addEventListener('click', async () => {
    if (camBusy || !camOn) return; camBusy = true;
    try {
      facing = facing === 'user' ? 'environment' : 'user';
      const s = await navigator.mediaDevices.getUserMedia({ video: VIDEO_CONSTRAINTS() });
      const track = s.getVideoTracks()[0]; const old = localStream.getVideoTracks()[0];
      peers.forEach(p => { p.videoSender && p.videoSender.replaceTrack(track).catch(() => {}); });
      if (old) { old.stop(); localStream.removeTrack(old); }
      localStream.addTrack(track); showLocalVideo();
    } catch (err) { facing = facing === 'user' ? 'environment' : 'user'; toast('Kamera belum bisa dibalik.', 'error'); }
    finally { camBusy = false; }
  });

  $('btn-end').addEventListener('click', () => endCall('local'));
  $('call-back').addEventListener('click', () => {
    if (embedded) { toParent('minimize'); return; }
    if (!everConnected || Date.now() - backArmed < 2500) { endCall('local'); return; }
    backArmed = Date.now(); toast('Ketuk sekali lagi untuk mengakhiri panggilan.');
  });
  $('call-error-back').addEventListener('click', goBack);
  $('call-people').addEventListener('click', () => {
    const names = [me.name + ' (kamu)', ...[...peers.values()].filter(p => p.connected).map(p => (meta.get(p.uid) || {}).name || 'Peserta')];
    toast('Dalam panggilan: ' + names.join(', '));
  });

  /* ------------------------------------------------------------------ akhiri */

  /* Log panggilan: hanya penelepon yang mencatat (satu kali per panggilan). */
  const fmtDur = sec => { sec = Math.max(0, Math.round(sec)); const m = Math.floor(sec / 60), s = sec % 60; return m ? `${m} mnt ${s} dtk` : `${s} dtk`; };
  async function logCall(reason) {
    if (logged || act !== 'start' || !room || room.isGlobal || !room.peer || !room.peer.id || !me) return;
    logged = true;
    const duration = everConnected ? Math.max(1, Math.round((Date.now() - startedAt) / 1000)) : 0;
    const status = everConnected ? 'completed' : reason === 'declined' ? 'declined' : reason === 'noanswer' ? 'missed' : reason === 'failed' ? 'failed' : 'canceled';
    const mode = callMode === 'video' ? 'video' : 'audio';
    const startedIso = new Date(everConnected ? startedAt : dialStartedAt).toISOString(), endedIso = new Date().toISOString();
    try {
      const ins = await sb.from('call_logs').insert({ room_id: roomId, caller_id: me.id, callee_id: room.peer.id, mode, status, started_at: new Date(dialStartedAt).toISOString(), answered_at: everConnected ? startedIso : null, ended_at: endedIso, duration_seconds: duration }).select('id').maybeSingle();
      if (ins.error) throw ins.error;
      const labels = { completed: fmtDur(duration), missed: 'tidak dijawab', declined: 'ditolak', canceled: 'dibatalkan', failed: 'gagal tersambung' };
      const content = `${mode === 'video' ? 'Panggilan video' : 'Panggilan suara'} · ${labels[status]}`;
      const msg = await sb.from('chat_messages').insert({ room_id: roomId, sender_id: me.id, content, kind: 'call', meta: { call_id: ins.data && ins.data.id, mode, status, duration, started_at: startedIso, caller_id: me.id } });
      if (msg.error) console.warn('[call log message]', msg.error.message);
    } catch (err) { console.warn('[call log]', err && err.message || err); }
  }
  async function endCall(reason) {
    if (ended) return; ended = true;
    const logP = logCall(reason);
    tones.stop(); clearInterval(ringInt); clearTimeout(ringTimeout); clearTimeout(joinGuard); clearTimeout(connectGuard); clearInterval(presenceKeepAlive); clearInterval(stageTick); clearInterval(timerInt); clearInterval(levelInt); clearTimeout(idleTimer);
    try {
      if (!everConnected && act === 'start' && !room.isGlobal && channel) await channel.send({ type: 'broadcast', event: 'cancel', payload: { callId, fromId: me.id } });
    } catch (_) {}
    try { channel && await channel.send({ type: 'broadcast', event: 'bye', payload: { from: me.id } }); } catch (_) {}
    try { channel && await channel.untrack(); } catch (_) {}
    peers.forEach(p => { try { p.pc.close(); } catch (_) {} });
    cleanupMedia();
    try { channel && sb.removeChannel(channel); } catch (_) {}
    setState('ended'); document.body.classList.remove('ui-idle');
    if (reason === 'local') { await Promise.race([logP, new Promise(r => setTimeout(r, 2500))]); goBack(); return; }
    if (reason === 'declined' || reason === 'noanswer' || reason === 'remote' || reason === 'failed') tones.ended();
    $('call-center').classList.remove('is-gone'); $('remote-grid').classList.remove('has-tiles');
    $('btn-end').disabled = true;
    if (reason === 'remote') setStatus('Panggilan berakhir');
    setTimeout(goBack, 1700);
  }
  ['pointerdown', 'keydown', 'touchstart'].forEach(ev => document.addEventListener(ev, () => { try { audioCtx && audioCtx.state === 'suspended' && audioCtx.resume(); } catch (_) {} }, { passive: true }));
  // Tombol maju/mundur browser bisa memulihkan halaman lama (bfcache) dengan mikrofon yang sudah mati: mulai bersih.
  window.addEventListener('pageshow', e => { if (e.persisted) goBack(); });
  window.addEventListener('pagehide', () => {
    if (ended) return;
    try { channel && channel.untrack(); } catch (_) {}
    cleanupMedia(); tones.stop();
  });

  /* ------------------------------------------------------------------ jembatan ke halaman chat (mode embed) */
  function pushState() {
    if (!embedded) return;
    toParent('state', { state: document.body.dataset.state, name: $('call-room').textContent, timer: everConnected ? $('call-timer').textContent : '', muted: !micOn, mode: callMode, count: [...peers.values()].filter(p => p.connected).length + 1, status: $('call-status').textContent });
  }
  window.addEventListener('message', e => {
    if (e.origin !== location.origin || !e.data || e.data.ndifly !== 'call') return;
    if (e.data.type === 'end') endCall('local');
    else if (e.data.type === 'toggle-mic') toggleMic();
  });
  if (embedded) { document.body.classList.add('is-embedded'); $('call-back').setAttribute('aria-label', 'Perkecil panggilan'); $('call-back').title = 'Perkecil (panggilan tetap berjalan)'; }

  /* ------------------------------------------------------------------ mulai */
  init().catch(err => { console.error('[call]', err); fatal('Terjadi kesalahan saat memulai panggilan. Coba lagi.'); });
})();
